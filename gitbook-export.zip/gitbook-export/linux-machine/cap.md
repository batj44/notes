# Cap - IDOR (Insecure Direct Object Reference)

/data/2 url-ийн тоог хэрэв өөрчилвөл өөр өөр датаг агуулж байгаа тул 0 url-руу шууд хандах боломжтой байна.

[image]

/data/0 болгож өөрчлөөд Wireshark pcapng файлыг татаж авна.

[image]

Credentials

[image]
