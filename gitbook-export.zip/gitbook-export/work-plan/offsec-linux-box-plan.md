# Offsec LINUX BOX PLAN

| # | Box | Exploit / CVE | Status | Difficulty |
|---|-----|---------------|--------|------------|
| 1 | Twiggy | CVE-2020-16846-Saltstack-Salt-API | Done | |
| 2 | Exfiltrated | SubrionCMS 4.2.1 - File Upload Bypass | Done | |
| 3 | Pelican | Exhibitor Web UI - CVE-2019-5029 | Done | |
| 4 | Astronaut | GravCMS 1.10.7 - Arbitrary | Done | |
| 5 | Blackgate | Redis 4.x / 5.x - Unauthenticated Code Execution | Done | |
| 6 | Boolean | Mass assignment / LFI | Done | hard |
| 7 | Clue | Cassandra - File read / FreeSWITCH 1.10.1 - Command Execution | Done | hard |
| 8 | Cockpit | SQL union injection | Done | |
| 9 | Codo | CodoForum RCE - CVE-2022-31854 | Done | |
| 10 | Crane | CVE-2022-23940 - SuiteCRM RCE | Done | |
| 11 | Levram | CVE-2021-43857 - Gerapy RCE | Done | |
| 12 | Extplorer | | Done | |
| 13 | Hub | | Done | |
| 14 | Image | ImageMagick - CVE-2023-34152 RCE | Done | |
| 15 | law | htmlLawed 1.2.5 - CVE-2022-35914 | Done | |
| 16 | Lavita | Laravel <= v8.4.2 debug mode | Done | |
| 17 | PC | rpc.py - CVE-2022-35411 | Done | hard |
| 18 | Fired | Openfire - CVE-2023-32315 | Done | |
| 19 | Press | Flatpress 1.2.1 - File upload bypass to RCE | Done | |
| 20 | Scrutiny | TeamCity - CVE-2024-27198-RCE | Done | hard |
| 21 | RubyDome | pdfkit - CVE-2022-25765 | Done | |
| 22 | Zipper | | | |
| 23 | Flu | Atlassian Confluence - CVE-2022-26134 | Done | |
| 24 | Workaholic | WP-Advanced-Search - CVE-2024-9796 | Done | |
| 25 | PyLoader | PyLoader - CVE-2023-0297 | Done | |
| 26 | Plum | pluxml RCE - CVE-2022-25018 | Done | |
| 27 | SPX | CVE-2024-42007 - php-spx Path Traversal Exploit | Done | |
| 28 | Jordak | CVE-2023-26469 - Jorani 1.0.0 Exploit | Done | |
| 29 | BitForge | CVE-2024-27115-Exploit - SoPlanning | Done | hard |
| 30 | Vmdak | Prison Management System - CVE-2024-48594 | Done | |
| 31 | Ochima | Maltrail-0.52-Exploit-RCE | Done | |
| 32 | Nibbles | PostgreSQL Reverse shell | Done | |
| 33 | CVE-2023-6019 | Ray OS v2.6.3 - Command Injection RCE(Unauthorized) | Done | |
| 34 | Sea | | Done | |
| 35 | Payday | CS-cart LFI | Done | |
| 36 | Snookums | SimplePHPGal-RCE.py - Remote File Inclusion | Done | |
