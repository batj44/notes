# Incident Investigation

FortiSIEM helps the IT team manage network incidents efficiently by using over 600 built-in rules to automatically trigger alerts based on specific criteria.

The Incident interface has 3 sections:

1. **Overview** - Provides a Red Amber Green (RAG) view of incidents by Type, Devices with incidents, and Hosts by Risk/Impact
2. **List View** - View all incidents and perform investigations
3. **Risk** - Creates a timeline view of devices and users by risk

## Sub-topics
- Incident Risk View
- Investigate Incident
