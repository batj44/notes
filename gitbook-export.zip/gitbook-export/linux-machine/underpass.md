# Underpass - SNMP 161 Port / Mosh PE

## SNMP Pentest

"UnderPass.htb is the only **daloradius** server in the basin!" -ийн утга нь daloradius server хамгийн чухал хэсэг нь л гэж байна.

```bash
snmpwalk -c public v1 <IP address>
```

[image]

Lets see!

[image]

## Directory Bruteforce

[image]

/app/operators/login.php

[image]

Daloradius default credentials:

```bash
username: administrator
password: radius
```

[image]

## User Credentials

```bash
username: svcMosh
password: underwaterfriends
```

[image]

## Privilege Escalation

**sudo командаар mosh-server ажиллуулах боломжтой байна.**

[image]

Харин mosh-server-рүү холбогдохдоо гар утасны shell ашиглан mosh командаар connection үүсгэнэ. Өөрөөр хэлбэл root эрхээр ажиллаж байгаа mosh-server рүү холбогдохын тулд mosh командаар Localhost холболт хийнэ.

**Mosh-server starting**

[image]

**Mosh command connection to root permission Mosh-server**

[image]

**Root!!!**

[image]
