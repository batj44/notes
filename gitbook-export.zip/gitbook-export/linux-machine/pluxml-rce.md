# PluXml RCE - CVE-2022-25018

PluXml Remote Code Execution via [CVE-2022-25018](https://nvd.nist.gov/vuln/detail/CVE-2022-25018).
