# Jerry - Apache Tomcat

An alternative way to do the above manual exploitation can be by downloading the **cmd.jsp** file and creating a **webshell.war** file using **zip**.

The webshell jsp file can be downloaded from here:

https://github.com/tennc/webshell/tree/master/fuzzdb-webshell/jsp

Next, after the **cmd.jsp** file is downloaded, a **revshell.war** file can be created using the following command:

```bash
zip -r revshell.war cmd.jsp
```

After uploading the **revshell.war** file in the deploy functionality, the web shell is obtained after accessing the file at: `http://192.168.1.5:8080/revshell/cmd.jsp`

## Exploited!

[image]
