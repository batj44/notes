# Openfire - CVE-2023-32315

**Authentication bypass:**

https://github.com/K3ysTr0K3R/CVE-2023-32315-EXPLOIT

**Remote code execution:**

https://github.com/tangxiaofeng7/CVE-2023-32315-Openfire-Bypass
