# PluXml

| File Name | Description |
|-----------|-------------|
| `parametres.xml` | The primary config file (site title, description, time zone, etc.). |
| `users.xml` | Contains user accounts, passwords (hashed), and permission levels. |
| `statiques.xml` | Configuration and list of your static pages. |
| `categories.xml` | Defines the article categories for your site. |
| `plugins.xml` | Lists active plugins and their basic settings. |
| `tags.xml` | Stores the tags used across your articles. |

**Important Note on Security**: PluXml protects the `/data/` folder using a `.htaccess` file by default to prevent web browsers from accessing the XML files directly.
