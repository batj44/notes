# Photobomb - Command Injection / Path Hijacking

Хэрэв download photo to print гэж дараад хүсэлтийг нь барьж авбал Сервер нь зураг бүрийг өөр өөр хэмжээтэйгээр хөрвүүлж гаргаж байгаа нь цаана нь **(convert / imagemagick)** гэх мэт хэрэгсэл ажиллаж байх магадлал өндөр.

[image]

## Shell as Wizard

**Иймэрхүү байдлаар илгээгдэж байгаа хүсэлтийг command injection болгож буй байдал.**

`convert [photo] -resize [dimensions] new.[filetype]`

`convert original.jpg -resize 1000x1000 new.png`

[image]

## Privilege Escalation

**Sudo: SETENV** Root хэрэглэгч болохдоо sudo SETENV path hijacking аргыг ашигласан.

[image]
