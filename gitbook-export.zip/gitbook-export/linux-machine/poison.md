# Poison - Port Forwarding / Vncviewer

## SSH Port-forwarding / Local File Inclusion

2 порт онгорхой байна. Би үүнээс хамгийн сайн шалгах ёстой сервис нь HTTP гэж шууд бодсон.

[image]

http серверийн Scriptname хэсэг дээр жагсаалтаар харуулсан php файлуудыг харах боломжтой.

[image]

Жишээ нь listfiles.php файлыг ажиллуулахад ийм бүтэцтэй харагдаж байгаа боловч хамгийн сонирхолтой нь pwdbackup.txt юм.

[image]

pwdbackup.txt-ийн агуулга нь нийт 13 удаа encode хийсэн base64 байгаа бөгөөд үүнийг decode хийж дараах нууц үгийг гаргаж авлаа.

[image]

# Одоо бидэнд username хэрэгтэй биш гэж үү?

Нэвтрэх нэрийг олохдоо LFI халдлагаар олж авсан байгаа.

Username: charix

[image]

SSH-ээр орсны дараа secret.zip гэсэн файл байсан бөгөөд задлахын тулд нууц үг шаардлагатай болохоор эхлээд өөрийн machine руу дамжуулсан.

Victim machine:

[image]

Attacker machine:

[image]

zip2john-оор crack хийх гэж үзсэн боловч энэ нь charix user-ийн нууц үгээр задалж болсон.

i dont know what is that.

[image]

```bash
#command-аар нийт
sockstat -4 -l
```

[image]

5901 порт дээр **vncviewer** ажилладаг бөгөөд зорилтот машин дээр vncviewer суулгагдаагүй байгаа болохоор SSH Port Forwarding хийж тухайн порт дээр ажиллаж буй сервисийг өөрийн машин руу дамжуулах юм.

## Port forwarding

```
5901 портыг өөрийн машины localhost руу дамжуулж байна.
```

[image]

```
secret файл нь obfuscation хийгдсэн болохоор unreadable байгаа юм.
Үүнийг decrypt хийхдээ дараах түүлийг ашиглаж болох юм.
```

[image]

[image]

10.10.10.84
