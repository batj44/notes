# Shoppy - NoSQL Injection

[nosqli releases](https://github.com/Charlie-belmer/nosqli/releases)

NoSQL injection нь MongoDB, CouchDB, Firebase датабаз руу чиглэдэг. Эдгээр мэдээллийн сангууд маань тухайн датагаа JSON хэлбэрээр датабаз дээрээ хадгалдаг.

## NoSQL Injection жишээ

MongoDB ашигладаг web application-ийн Login form хэсэг

```bash
db.users.find({ "username": username, "password": password });
```

Хэрэв аппликешн нь баталгаажуулалтгүйгээр энэ query-д хэрэглэгчийн оруулсан мэдээллийг шууд оруулбал халдагч дараах зүйлийг оруулж болно:

- **Username:** `admin`
- **Password:** `{"$ne": ""}`

Query ийм болж байна.

```bash
db.users.find({ "username": "admin", "password": { "$ne": "" } });
```

`admin` Энэ query нь нэвтрэлт танилтыг алгасаж, нууц үг хоосон биш л бол хэрэглэгчийг буцаана.

# Shoppy HTB

Login form.

[image]

Хэрэв Web directory дээр өөр зам бичвэл Cannot GET /asdasd гэж гарч ирнэ. Тэгэхээр NodeJS байх бүрэн боломжтой байна.

[image]

Нэвтрэх хэсгийн хүсэлтийг Burp suite ашиглан барьж авсан.

[image]

## NoSQL Failures

Энэ серверийг гацааж байгаа нэг зүйл нь `'` тэмдэг бөгөөд NoSQL гэдгийг баталж байна.

[image]

```bash
username[$ne]=test'&password[$ne]=test
```

[image]

Мөн л ажиллахгүй байна.

## Content-Type to JSON

Өөр нэгэн арга нь Content-Type-ийг JSON болгон өөрчилж, JSON хүсэлт илгээх юм. Ингэснээр ямар path дээр web-app ажиллаж байгаа харж болж байгаа юм.

> **/home/jaeger/ShoppyApp**

```bash
{"username":"admin","password":{"$ne":"admin"}}
```

[image]

## NoSQL Injection Success

Дараах хавсралт линкийг ашигласан: https://portswigger.net/web-security/nosql-injection

password талбар нь ашиглагдахаасаа өмнө хэш болно гэж найдаж байгаа тул би username талбарт ийм ачааллыг туршсан. Энэ ачаалал руу буцах (болон `Content-Type` буцаж харах `application/x-www-form-urlencoded`):

```bash
username=admin' || 'a'=='a&password=admin
username=admin' || '1'=='1&password=admin
```

## Үр дүн нь:

[image]

## Privilege Escalation

password-manager нь deploy user-ийн нууц үгийг гаргаж өгдөг.

[image]

/home/deploy/password-manager-ийг ghidra ашиглан задласан. Нууц үг нь **Sample**

[image]

id командаар docker group-т байгааг харж болно.

[image]

```bash
docker run -v /:/mnt --rm -it alpine chroot /mnt sh
```

[image]
