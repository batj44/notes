# CryptoJS decrypt

**Client side code:**

Тухайн вэб сайтын JavaScript файл дотор байсан `"SecretPassphraseMomentum"` гэдэг нууц үгийг олсон.

```javascript
function viewDetails(str) {
  window.location.href = "opus-details.php?id="+str;
}

/*
var CryptoJS = require("crypto-js");
var decrypted = CryptoJS.AES.decrypt(encrypted, "SecretPassphraseMomentum");
console.log(decrypted.toString(CryptoJS.enc.Utf8));
*/
```

**Decrypt.js**

`decrypt.js` гэдэг файл үүсгээд, web дээрх cookie-г Kali Linux-ийнхоо терминал дээр ажиллуулахад:

```javascript
// decrypt.js
var CryptoJS = require("crypto-js");
var args = process.argv.slice(2);
var encrypted = args[0];
var secret = "SecretPassphraseMomentum";

if (encrypted) {
    var decrypted = CryptoJS.AES.decrypt(encrypted, secret);
    console.log("Decrypted text: " + decrypted.toString(CryptoJS.enc.Utf8));
} else {
    console.log("Usage: node decrypt.js <encrypted_string>");
}
```

[image]
