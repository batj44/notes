# Git / Github

## Git Commands for Repository Investigation

**Find sensitive data from .git**

```bash
for repo in /srv/git/freelancers/*.git; do
    echo "--- Searching $repo ---";
    git -C "$repo" rev-list --all | xargs -I {} git -C "$repo" grep -Ei 'BEGIN|password' {} 2>/dev/null;
done
```

```bash
git@onlyrands:~/freelancers$ git -C /srv/git/freelancers/marcot.git show 39b533acb7e4523f2ab67ee9d625a2581350f329:id_rsa
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAACmFlczI1Ni1jdHIAAAAGYmNyeXB0...
```

## Check Information

```bash
# Basic information
git show
git show <branch-name>
git show <commit-id>
git show <tag-name>
git --git-dir /path/to/.git show

# Configuration
git config --list

# Commit history
git log
git log --stat
git --git-dir /path/to/.git log --stat

# Compare the two commits
git diff
git diff --staged
git diff --cached

# Working tree status
git status
```

## Back to the Previous Commits

```bash
# We can get the "commit-id" by 'git log'
git checkout <commit-id>
git --git-dir /path/to/.git checkout <commit-id>

# Return the recent commit
git checkout master
git checkout main
```

## Search the Other Branches

```bash
git branch -a
```
