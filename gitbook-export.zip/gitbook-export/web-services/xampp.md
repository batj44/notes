# XAMPP

| Component | File Name | Full Windows Path |
|-----------|-----------|-------------------|
| Apache | `httpd.conf` | `C:\xampp\apache\conf\httpd.conf` |
| PHP | `php.ini` | `C:\xampp\php\php.ini` |
| MySQL | `my.ini` | `C:\xampp\mysql\bin\my.ini` |
| Virtual Hosts | `httpd-vhosts.conf` | `C:\xampp\apache\conf\extra\httpd-vhosts.conf` |
| phpMyAdmin | `config.inc.php` | `C:\xampp\phpMyAdmin\config.inc.php` |
| Passwords | | `C:\xampp\passwords.txt` |
| Properties | | `C:\xampp\properties.ini` |
