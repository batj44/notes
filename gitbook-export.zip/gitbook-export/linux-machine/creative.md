# Creative - URL Fetcher / SSRF

## Enumeration

```bash
nmap -A -T4 creative.thm -v -p-
```

[image]

## Sub domain

`/beta`

[image]

**beta.creative.thm** вебийн бүтэц. Ажиллагааны хувьд вебсайтын Alive or Dead-ийг шалгаж өгдөг.

[image]

Бидний хувьд 80 порт дээр ямар веб ажиллаж байгааг мэдэж байгаа тул дараах аргаар тест хийж үзэх юм.

[image]

URL Fetcher хийж localhost дээр ажиллаж байгаа вебийг харж чадаж байна.

[image]

## Lets Exploit!

Бидний хувьд SSRF хийж дотоод сервист ажиллаж байгаа өөр ямар порт байгааг мэдэх боломжтой. Дараах аргыг ашиглая!

```bash
ffuf -request testforshit -request-proto http -w <(seq 1 65535) -fs 13
```

[image]

1337 порт дээр сервис ажиллаж байгаа олж чадлаа!!! Тэгвэл доорх аргаар test хийгээд үзэе!

`http://localhost:1337`

[image]

`python3 -m http.server` ажиллаж байгаа гэж миний хувьд бодож байна.

[image]

Гэвч /etc -рүү хандах үед дараах асуудалтай нүүр тулж байна.

[image]

## Tech issue

1. `http://localhost:1337/etc/passwd`

[image]

`/etc/passwd`-ийг амжилттай харлаа. Үүнээс `/home/saad` хэрэглэгч байгааг мэдсэн тул id_rsa байгаа эсэхийг шалгая!

[image]

2. `http://localhost:1337/home/saad/id_rsa`

[image]

## Exploited!

`/home/saad/.ssh/id_rsa`

[image]

## Privilege Escalation

`.bash_history`-оос saad хэрэглэгчийн creds-ийг олж авсан бөгөөд sudo -l буюу shell escape-ийг ашиглан ямар sudo эрхтэй байгаагаа шалгасан.

### saad: MyStrongestPasswordYet$4291

1. ping командыг root эрхээр ажиллуулах боломжтой.
2. Мөн sudo version нь 1.8.31 байна.
3. LD_PRELOAD env буруу тохируулагдсанг тус тус харж байна.

[image]

### sudo LD_PRELOAD attack

1. **preload.c доорх аргаар бэлдэх**

[image]

2. **gcc compiling**

[image]

3. Дараах аргаар root болж байна.

[image]
