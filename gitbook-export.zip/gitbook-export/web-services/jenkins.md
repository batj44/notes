# Jenkins

## CVE-2024-23897: Jenkins Arbitrary File Read

- `/proc/self/environ` - Environmental variables including `JENKINS_HOME`
- `/proc/self/cmdline` - Command-line arguments
- `/etc/hosts` - Linux local-DNS resolution
- `/etc/passwd` - Linux user accounts
- `/var/jenkins_home/users/users.xml` - User account storage locations
- `/var/jenkins_home/users/<user_directory>/config.xml` - User BCrypt password hash
- `/var/jenkins_home/secrets/master.key` - Encryption secret key
