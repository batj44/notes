# Web Services

Exploitation techniques for various web applications and CMS platforms.

## Topics

- [Atlassian Confluence](atlassian-confluence.md)
- [Backdrop CMS](backdrop-cms.md)
- [Cassandra](cassandra.md)
- [CS-Cart](cs-cart.md)
- [DNN](dnn.md)
- [eXtplorer](extplorer.md)
- [FileZilla](filezilla.md)
- [Flask](flask.md)
- [FlatPress](flatpress.md)
- [FreeSwitch](freeswitch.md)
- [FuguHub](fuguhub.md)
- [Ghost CMS](ghost-cms.md)
- [Gitea](gitea.md)
- [Git/GitHub](git-github.md)
- [Grav CMS](grav-cms.md)
- [Jenkins](jenkins.md)
- [Openfire](openfire.md)
- [PluXml](pluxml.md)
- [Prison Management System](prison-management-system.md)
- [SeaCMS](seacms.md)
- [SOPlanning](soplanning.md)
- [TeamCity](teamcity.md)
- [Tomcat](tomcat.md)
- [XAMPP](xampp.md)
- [XAMPP MySQL User IBD](xampp-mysql-user-ibd.md)
