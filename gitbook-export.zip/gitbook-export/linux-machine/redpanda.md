# RedPanda - Spring Boot SSTI

Java Spring Boot SSTI аргын дагуу reverse shell авсан.

## Shell as woodenk

[image]
