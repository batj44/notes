# CPTS Exam Report

## DMZ01

### Find subdomain using main trilocor.local

```bash
ffuf -u http://trilocor.local/ -H "Host: FUZZ.trilocor.local" -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt -fw 105040
```

### Remote Code Execution - OpenNMS Horizon 30.0.5-SNAPSHOT

Enumeration step by step, found RCE vulnerability on nms.tricolor.local running OpenNMS Horizon 30.0.5-SNAPSHOT.
