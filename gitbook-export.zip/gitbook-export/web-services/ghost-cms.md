# Ghost CMS

**Default credentials**

```bash
./ghost/core/test/regression/api/admin/authentication.test.js

config.production.js
config.production.json
```
