# ImageMagick - RCE CVE-2023-34152

ImageMagick RCE exploit via CVE-2023-34152.
