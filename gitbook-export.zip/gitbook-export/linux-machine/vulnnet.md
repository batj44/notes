# VulnNet - TeamCity Web

TeamCity dir-ийг / path-аас олж харах болно. Үүний дагуу тухайн веб нь 8111 порт дээр ажилдагыг мэдэж авсан.

[image]

default 8111 port

[image]

ss -lnpt командаар 8111 порт дээр сервис ажиллаж байгааг мэдэж авсан тул SSH порт дамжуулах аргачлалыг хийх юм.

[image]

## Port Forwarding

[image]

## Lets Exploit!

**as a Super user** дээр дараад ssh эрхээр /TeamCity/logs-оос authentication token-ийг хайх юм.

[image]

Энэ үед ийм лог бүртгэгдсэн бөгөөд тухайн token-ийг ашиглая!

[image]

**Project үүсгэж байна.**

[image]

**Build үүсгэж байна.**

[image]

Дараах байдлаар SUID тохируулаад **Save** дарж, **Run** хийж командыг гүйцэтгэх юм.

[image]

Тухайн команд нь амжилттай ажиллажээ.

[image]

## Root!

[image]
