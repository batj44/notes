# Hub - FuguHub 8.4 CVE-2024-27697

Create account then RCE!

https://github.com/SanjinDedic/FuguHub-8.4-Authenticated-RCE-CVE-2024-27697/blob/main/exploit.py
