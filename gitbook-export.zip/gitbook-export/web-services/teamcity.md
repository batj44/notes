# TeamCity

## Common Directories

```
/admin
/admin/admin.html
```

## Interesting Files in Systems

```
TeamCity/conf/teamcity-startup.properties
.BuildServer/system
```

## Find Super User Authentication Tokens

```bash
grep -rni 'authentication token' TeamCity/logs
grep -rni 'Super user authentication token' TeamCity/logs
grep -rni 'token' TeamCity/logs
```

## Find id_rsa from TeamCity

Web access: `TeamCity → Project → Freelancers → Marco Tillman → Build → Pending Changes → Oops → Read the id_rsa`
