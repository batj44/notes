# DNN - File Upload to RCE

1. Эхлээд ASPX, ASP төрлийг allow хийж өгнө: `Settings -> Security -> More -> More Security Settings`

[image]

2. Дараах замын дагуу ороод aspx webshell байршуулна: `Manage -> Global Assets`

URL: `http://192.168.120.248/Host/Global-Assets/portalid/0`

**RCE path:** `http://192.168.120.248/Portals/0/aspx_cmd.aspx`

[image]
