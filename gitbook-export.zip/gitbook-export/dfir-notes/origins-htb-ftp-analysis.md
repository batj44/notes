# Origins HTB - FTP Analysis

1. **What is the attacker's IP address?**

   15.206.185.207

2. **It's critical to get more knowledge about the attackers, even if it's low fidelity. Using the geolocation data of the IP address used by the attackers, what city do they belong to?**

   [image]

3. **Which FTP application was used by the backup server? Enter the full name and version. (Format: Name Version)**

   [image]

4. **The attacker has started a brute force attack on the server. When did this attack start?**

   [image]

5. **What are the correct credentials that gave the attacker access? (Format username:password)**

   [image]

6. **Attackers were able to compromise the credentials of a backup SSH server. What is the password for this SSH server?**

   **B@ckup2024!**

   [image]

7. **What is the s3 bucket URL for the data archive from 2023?**

   [image]

8. **The scope of the incident is huge as Forela's s3 buckets were also compromised and several GB of data were stolen and leaked. It was also discovered that the attackers used social engineering to gain access to sensitive data and extort it. What is the internal email address used by the attacker in the phishing email to gain access to sensitive data stored on s3 buckets?**

   [image]
