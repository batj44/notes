# /etc/apt/source.list

Add source.list Bcoz its near the region country like yarmag.

```bash
deb http://kali.cs.nycu.edu.tw/kali kali-rolling main contrib non-free non-free-firmware
```

apt-get update while error lets run this command

```bash
curl -fsSL https://archive.kali.org/archive-key.asc | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/kali-archive.gpg
```
