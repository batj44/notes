# Armaxis - (Markdown image RCE)

Login хийж бүртгүүлэх хэсэг болон э-мэйл хүлээн авах хэсэг байна.

[http://83.136.252.66:56754/](http://83.136.252.66:56754/)

[image]

[http://83.136.252.66:48820/](http://83.136.252.66:48820/)

[image]

Миний ойлгосноор хэрэв би шинээр test@email.htb хэрэглэгч үүсгээд үүний дараа нууц үгээ өөрчлөх оролдлого хийвэл шинэ токен ирэхийг анзаарсан.

test@email.htb нэртэй шинэ хэрэглэгч үүсгэсэн.

[image]

Өмнө хэлсэнчлэн нууц үгээ өөрчилж байна.

[image]

Энэ үед шинэ токен ирж байгааг харж болно.

[image]

Бидний хувьд хэдий test@email.htb хэрэглэгч үүсгэсэн ч admin эрхээр орж чадахгүй байгаа юм. Гэхдээ хэсэг хугацааны дараа admin@armaxis.htb хэрэглэгч database-д байгааг олсон ба тухайн хэрэглэгчийн э-мэйлээр admin эрхээр орох боломжтой байгаа гэж үзсэн.

[image]

/reset-password-ийн хүсэлтийг барьж email хэсэгт admin@armaxis.htb болгон өөрчлөлт оруулж хүсэлтээ илгээх үед Password reset successful буюу амжилттай нууц үгийг сольж чадлаа.

user: admin@armaxis.htb
pass: 123

[image]

## Markdown.js файлын агуулга:

execSync үйлдлээр curl командыг ажиллуулж байгаа нь command injection халдлагад өртөмтгий болгож байгаа юм.

[image]

Энэ халдлагыг гүйцэтгэхийн тулд Markdown image-ийг үүсгэхэд л хангалттай байна.

```
![hackerjagaa](http:localhost)    //normal markdown
![hackerjagaa](http:localhost;ls) //our payload to execute (ls)
```

## Lets Exploit!

payload -оо дараах байдлаар нэмж өгөх бөгөөд үр дүн нь дээрх зурган дээр дурдсанчлан `<img src={base64}>` датагаар ирэх юм.

[image]

Embedded image-ийг Inspect хийгээд img src-д байгаа base64-ийг decode хийнэ.

[image]

## Exploited!

[image]
