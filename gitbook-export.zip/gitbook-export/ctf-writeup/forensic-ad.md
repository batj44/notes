# Active Directory Forensic

## Group Policy Preferences

Group Policies for account management are stored on the Domain Controller in "Groups.xml" files buried in the SYSVOL folder.

**Groups.xml** can stored local admin's password

[image]

**cpassword** is admin pass. Encrypted like AES key MSDN

[image]

We can decrypt using tool **gpp-decrypt.**

```
gpp-decrypt LjFWQMzS3GWDeav7+0Q0oSoOM43VwD30YZDVaItj8e0
```

[image]
