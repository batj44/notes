# Analytics

FortiSIEM's advanced analytics capabilities, including detailed searches through Event Keywords and Event Attributes, empower the team to perform precise and efficient queries.

## Sub-topics
- Event Keywords Search / Administrator Login Check
- Data Aggregation
