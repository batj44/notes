# Cassandra

Potential password location file:

```
/proc/self/cmdline
```
