# Openfire

The file `/var/lib/openfire/embedded-db/openfire.script` belongs to the HSQLDB (HyperSQL Database) engine.

Key files:
- `/var/lib/openfire/embedded-db/openfire.properties`
- `/var/lib/openfire/embedded-db/openfire.script`
- `/var/lib/openfire/embedded-db/openfire.log`

| File Name | Description |
|-----------|-------------|
| `openfire.script` | **The most important file.** Contains SQL commands to recreate the database structure and actual data (INSERT statements) for all tables. |
| `openfire.properties` | Contains settings for the HSQLDB engine itself (e.g., versioning, cache settings). |
| `openfire.log` | A record of recent transactions that haven't been fully committed to the script file yet. |
| `openfire.data` | Contains the binary data for the tables. |
