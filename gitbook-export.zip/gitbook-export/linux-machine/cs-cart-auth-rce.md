# CS-Cart 1.3.3 - Authenticated RCE

1. Visit "cs-cart" `/admin.php` and login (Remember: You need to login on **ADMIN** section not on the regular **USER** section).
2. Under **Look and Feel** section click on "**template editor**".
3. And under that section, upload your malicious `.php` file, make sure you rename it to `.phtml` before you upload.
4. If successful, you should be able to get a **RCE**.

Now, visit `http://[victim]/skins/whoami.phtml`
