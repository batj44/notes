# Pwned Machine List

```
Cap - easy (IDOR + Capabilities python3)

Broker - easy (ActiveMQ + Nginx SUDO)
    -https://github.com/SaumyajeetDas/CVE-2023-46604-RCE-Reverse-Shell-Apache-ActiveMQ

UnderPass - easy (Daloradius + Mosh-server SUDO)

BoardLight - easy (Dolibarr ERP + Enlightenment_sys SUID)

Headless - easy (XSS steal cookie +  syscheck sudo Path injection)

Devvortex - easy (Joomla 4.2.6 + apport-cli SUDO)

Blocky - easy ()

Beep - easy (elastix 2.2.0 + chmod SUDO)

lookup - easy (elFinder + /usr/sbin/pwm)

nocturnal - easy (zip $password command injection + ipsconfig cve)

Code - easy (python compiler - backy.sh 1.2)

Codify - easy (vm2 + bash comparison / pspy32)

Greenhorn - easy (pluck cms v4.7.18 - depix images restore and to root access)

All in One - easy (mail-masta plugin LFI - sudo /usr/bin/socat)
```
