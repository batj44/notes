# Builder - Jenkins CVE-2024-23897 / Jenkins Instance SSH Creds

## CVE-2024-23897: Jenkins Arbitrary File Read

- `/proc/self/environ` Environmental variables including `JENKINS_HOME`
- `/proc/self/cmdline` Command-line arguments
- `/etc/hosts` Linux local-DNS resolution
- `/etc/passwd` Linux user accounts
- `/var/jenkins_home/users/users.xml` User account storage locations
- `/var/jenkins_home/users/<user_directory>/config.xml` User BCrypt password hash
- `/var/jenkins_home/secrets/master.key` Encryption secret key

```bash
/proc/self/environ
```

[image]

### Found user_directory from users.xml

```bash
/var/jenkins_home/users/users.xml
```

[image]

### Found jennifer user's Jenkins password hash

```bash
/var/jenkins_home/users/jennifer_12108429903186576833/config.xml
```

[image]

## Accessing and dumping Jenkins credentials

https://www.codurance.com/publications/2019/05/30/accessing-and-dumping-jenkins-credentials

**ssh keys encrypted like hudson**

[image]

**Dashboard > Nodes > Built-In Node > Script Console**

```groovy
println hudson.util.Secret.decrypt("{AQAAABAAAAowLrfCrZx9baWlXXXXXXXXXX}")
```

[image]

## Shell as Root

[image]

[image]
