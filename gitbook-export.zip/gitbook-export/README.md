# Pentest Notes

Security research & penetration testing notes. HTB/Offsec machine writeups, web application testing techniques, service exploitation, Active Directory attacks, and more.

## Categories

- [Web Pentest](web-pentest/) - Web application attack techniques (XSS, SQLi, SSTI, SSRF, etc.)
- [Linux Machine](linux-machine/) - Linux machine writeups (HTB, Offsec, THM)
- [Windows Machine](windows-machine/) - Windows machine writeups (HTB, Offsec)
- [Services Pentest](services-pentest/) - Service-specific exploitation by port
- [Pentest Knowledge](pentest-knowledge/) - General pentest techniques and troubleshooting
- [Web Services](web-services/) - CMS & web service exploitation guides
- [Android Pentest](android-pentest/) - Mobile application security testing
- [CTF Writeup](ctf-writeup/) - CTF challenge solutions
- [DFIR Notes](dfir-notes/) - Digital forensics & incident response
- [FortiSIEM](fortisiem/) - FortiSIEM SIEM notes
- [Exam Reports](exam-reports/) - CPTS & OSCP exam reports
- [Work Plan](work-plan/) - Quarterly plans and certification prep
- [Grab](grab/) - Useful scripts and exploit references
- [Misc](misc/) - Miscellaneous notes and configurations
