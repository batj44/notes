# CozyHosting - Whitelabel Springboot

22, 80 портууд нээлттэй.

[image]

Мөн admin url маань 401 буюу unauthorized статустай байгаа тул хандах боломжгүй. Зөвхөн зөвшөөрөгдсөн хэрэглэгчид л хандах ёстой юм.

`/admin`

[image]

Хэрэв url path дээр өөр зам бичиж өгвөл дараах байдлаар **Whitelabel Error Page** зааж байна.

[image]

Энэхүү вэб нь **Spring boot** ашиглаж байгаа гэсэн үг юм.

[image]

## spring-boot.txt-ийг ашиглан directory bruteforce хийсэн

```bash
ffuf -u http://cozyhosting.htb/FUZZ -w /usr/share/seclists/Discovery/Web-Content/spring-boot.txt
```

[image]

Хэрэв actuator/sessions API-ийг curl-аар харвал дараах үр дүн гарч ирнэ:

[image]

## Lets Exploit!

Admin url-ийн веб хүсэлтийг Intercept хийж аваад actuator/sessions API-т байсан **Cookie: JSESSIONID**=`07A51D4A463120B74DC40DE26046858D`-ийг сольж хийгээд Forward хийх юм.

[image]
