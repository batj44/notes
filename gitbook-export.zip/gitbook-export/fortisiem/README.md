# FortiSIEM

FortiSIEM security information and event management notes.

## Topics

- [Analytics](analytics.md)
- [Automated Case Management](automated-case-management.md)
- [CMDB Overview](cmdb-overview.md)
- [Incident Investigation](incident-investigation.md)
- [Resources](resources.md)
