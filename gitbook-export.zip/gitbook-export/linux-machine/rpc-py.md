# rpc.py - CVE-2022-35411

### Identifying rpc.py!

**Port:** `127.0.0.1:65432`

```bash
ss -lnpt
```

[image]

### Catch root!

[image]
