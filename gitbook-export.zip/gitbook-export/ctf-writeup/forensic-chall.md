# Forensic Challenges

CTF forensic challenge writeups organized by category.

## Categories

- [Misc](forensic-misc.md) - Steganography, file analysis, wireshark, crypto misc
- [Openssl](forensic-openssl.md) - OpenSSL encryption/decryption challenges
- [Windows Forensic](forensic-windows.md) - LDAP, NTDS, SAM file analysis
- [Active Directory Forensic](forensic-ad.md) - Group Policy Preferences, AD attacks
- [Docker Forensic](forensic-docker.md) - Docker overlay analysis
