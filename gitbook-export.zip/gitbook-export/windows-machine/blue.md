# Blue - EternalBlue / MS17-010

**Reference:** https://0xdf.gitlab.io/2021/05/11/htb-blue.html
