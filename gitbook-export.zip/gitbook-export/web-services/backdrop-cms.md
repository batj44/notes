# Backdrop CMS

## Configuration file

```bash
settings.php
```

[image]

Example: `http://dog.htb/?q=accounts/tiffany`
