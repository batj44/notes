# Docker Forensic

## Docker Overlays

I lost the password I used to encrypt my secret flag file. Could you help me to recover it ?

pass.txt -ийг ашиглаж flag.enc

```
container-diff analyze -t history ch29.tar
```

[image]

[image]

using **flag.enc**, **pass.txt** decrypt **AES-256-CBC.**

```
openssl enc -aes-256-cbc -iter 10 -d -in flag.enc -out flag.txt
```

[image]

[image]
