# SoPlanning

Key files:
- `includes/database.inc.php`
- `includes/config.inc.php`

**Pro-Tip for your Search:**

```bash
# To find where the database is called:
grep -rn "mysqli_connect" .

# To find where the admin password or hash is referenced:
grep -rn "password" includes/
```
