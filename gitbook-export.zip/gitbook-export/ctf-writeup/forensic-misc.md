# Misc Forensics

## f5-steganography - Refreshed picture

LSB хамгийн бага чухал битүүд дээр файл нуух аргачлал бөгөөд үүнийг хэрэв бусад түүл extract хийж чадахгүй байвал f5-steganography-г ашиглана.

---

## vmdk file

mianju.jpg файлд binwalk түүлээр задласан байдал

Дотроос нь flag.vmdk гэсэн файл гарч ирсэн.

[image]

```javascript
key_part_one
key_part_two энэ хоёр дотор flag маань байгаа
```

[image]

---

## conf.bin RouterPassView

conf.bin өргөтгөлтэй файл нь Router-ийн config файл нь юм байна

[image]

Ийм файл байна

[image]

Тус файлыг задалж харахдаа ROUTERPASSVIEW гэх програм ашиглах юм байна.

RouterPassView бол ISP нууц үг/түлхүүрээ алдсан тохиолдолд чиглүүлэгчийн файлаас алдсан нууц үгээ хурдан сэргээхэд туслах үнэгүй програм юм.

[image]

---

## find hacker's webshell backdoor

Олон файл дотроос webshell backdoor хайх ёстой даалгавар байсан.

Гэх мэт худлаа зүйл хийж үзсээн. Мэдээж маш олон файл байгаа учир олдоход их хэцүү.

[image]

Гэхдээ үүнийг хялбархан хийх арга нь Antivirus програмаар scan хийх юм байна.

ЖИШЭЭ БАЙДЛААР ТУС ФАЙЛАА VIRUS TOTAL ДЭЭР ШАЛГАЖ ҮЗЭХЭД webshell гэдгийг нь таньж байгаа боловч аль файл нь вэ? гэдгийг мэдэх боломжгүй байна. Eset, Kaspersky эдрийг л ашиглавал яг гаргаж ирнэ бат шүү...

[image]

---

## Two gif, which one gif corrupted

2 gif файл байгаагын нэг нь гэмтсэн бөгөөд header хэсгийн bytes-ийг тулгаж харсан бөлгөө.

[image]

Мааш сайн анзаарвал доорх эвдэрсэн gif файлны hex хэсгийн эхний 4 bytes 47 49 46 38 байх ёстой харагдаж байна.

[image]

4 bytes-ийг нэмэхдээ **Edit -> Insert/Overwrite -> Insert Bytes** үед зураг засагдаж байна.

[image]

Nice challenge!

[image]

---

## gnuplot tool with coordinates

Зурган файл байсан бөгөөд үүнийг binwalk, steghide, stegseek, foremost гэх мэтчилэн түүлээр туршиж үзсэн байгаа.

[image]

Гэхдээ 010editor програм ашиглан доторх hex утгыг харвал зурган файлны bytes-ууд дуусаад араас нь өөр утгууд орсон байгааг харж байна.

[image]

Дараах утгуудыг хуулж cyberchef сайтад оруулсан. Тус output нь coordinates утгатай ижил байгаа тул **gnuplot** түүлээр зурах боломжтой.

[image]

ТҮҮЛ USAGE

[image]

SCAN AND GET FLAG!

[image]

---

## outguess usage

[image]

---

## Slack Space

Disk slack space гэдэг нь Disk-ний NTFS cluster дахь 4Kbs size-ний илүү үлдсэн зайг хэлнэ.

```
Жишээлбэл тухайн файл нь 6000bytes бөгөөд 2 sector эзлэнэ гэж үзвэл 8192 болно.
Тэгвэл 8192 - 6000  гэхээр 2192 нь Slack Space болж байна гэсэн үг юм.
Slack Space = 8192 - 6000 = 2192 bytes
```

Sub-pages: in windows, in linux

---

## Find flag from dump

```python
alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+- =\\\\{\\\\}[]"
strings = open('flag.txt').read()

result = {}
for i in alphabet:
	counts = strings.count(i)
	i = '{0}'.format(i)
	result[i] = counts

res = sorted(result.items(),key=lambda item:item[1],reverse=True)
for data in res:
	print(data)

for i in res:
	flag = str(i[0])
	print(flag[0],end="")
```

flag хаана ч байгаа юм.

[image]

flag!!!

[image]

---

## SSTV - moon

How images from the moon landing were transmitted back to earth.

---

## Png

Sub-pages:
- Png - LSB
- Png - MSB
- png height width FIX
- So many PNG - tricks
- invalid chunk length (too large)
- Deblurring Images
- Powershell Steganography

---

## Zip

Sub-pages:
- Pseudo encypted file in ZIP

---

## CRYPTO - MISC

Sub-pages:
- Snake - Serpent - Symmetric Ciphers Online
- base64 steganography
- Braille 8 dots decode
- stego100.wav - Morse Code
- Keyboard hidden secret
- Musical notes decoder
- uudecode
- JS aaencode - DECODER
- Time Based Side-Channel Attacks

---

## img srch_strings

[image]

---

## wireshark - misc

### Pcredz

[Pcredz](https://github.com/lgandx/PCredz) is a tool that can be used to extract credentials from live traffic or network packet captures. Specifically, it supports extracting the following information:

- Credit card numbers
- POP credentials
- SMTP credentials
- IMAP credentials
- SNMP community strings
- FTP credentials
- Credentials from HTTP NTLM/Basic headers, as well as HTTP Forms
- NTLMv1/v2 hashes from various traffic including DCE-RPC, SMBv1/2, LDAP, MSSQL, and HTTP
- Kerberos (AS-REQ Pre-Auth etype 23) hashes

In order to run `Pcredz`, one may either clone the repository and install all dependencies, or use the provided Docker container detailed in the [Install](https://github.com/lgandx/PCredz?tab=readme-ov-file#install) portion of the README file.

The following command can be used to run `Pcredz` against a packet capture file:

Credential Hunting in Network Traffic

```
Okazakiii@htb[/htb]$ ./Pcredz -f demo.pcapng -t -vPcredz 2.0.2
Author: Laurent Gaffie
Please send bugs/comments/pcaps to: laurent.gaffie@gmail.com
This script will extract NTLM (HTTP,LDAP,SMB,MSSQL,RPC, etc), Kerberos,
FTP, HTTP Basic and credit card data from a given pcap file or from a live interface.

CC number scanning activated

Unknown format, trying TCPDump format

[1746131482.601354] protocol: udp 192.168.31.211:59022 > 192.168.31.238:161
Found SNMPv2 Community string: s3cr...SNIP...

[1746131482.601640] protocol: udp 192.168.31.211:59022 > 192.168.31.238:161
Found SNMPv2 Community string: s3cr...SNIP...

<SNIP>

[1746131482.658938] protocol: tcp 192.168.31.243:55707 > 192.168.31.211:21
FTP User: le...SNIP...
FTP Pass: qw...SNIP...

demo.pcapng parsed in: 1.82 seconds (File size 15.5 Mo).
```

Sub-pages:
- openssl pcapng
- Dns - base64 pcapng
- TLS stream decrypt with key
- Archer a7/c7 traffic injection

---

## mqtt - mosquitto_sub

**Бүх Public topic-ийг харж байгаа тул base64 encoded-ийг тайлж уншиж байна.**

[image]

**Base64 decode хийсэн байдал. Үүнд pub болон sub topic мэдээлэл болон HELP, CMD, SYS командын мэдээлэл байгааг харж байна.**

[image]

### Lets Exploit!

1. Sub-руу нь HELP командыг publish хийнэ.

[image]

2. Тухайн мөчид Pub topic-ийг mosquitto\_sub командаар ямар дата дамжиж байгааг харах болно.

[image]

3. \{"id": "\<backdoor id>", "cmd": "\<command>", "arg": "\<argument>"\}

[image]

4. Дээрх өгөгдсөн аргументыг дараах байдлаар өөрчлөөд base64 болгож, Sub-руу publish хийнэ.

[image]

5. **Response data** eyJpZCI6ICI8YmFja2Rvb3IgaWQ+IiwgImNtZCI6ICJDTUQiLCAiYXJnIjogImxzIn0=

```
mosquitto_pub -h 10.10.167.245 -t "XD2rfR9Bez/GqMpRSEobh/TvLQehMg0E/sub" -m 'eyJpZCI6ICI8YmFja2Rvb3IgaWQ+IiwgImNtZCI6ICJDTUQiLCAiYXJnIjogImxzIn0='
```

[image]

6. **Response data** eyJpZCI6ImNkZDFiMWMwLTFjNDAtNGIwZi04ZTIyLTYxYjM1NzU0OGI3ZCIsInJlc3BvbnNlIjoiZmxhZy50eHRcbiJ9

```
mosquitto_sub -h 10.10.167.245 -p 1883 -t U4vyqNlQtf/0vozmaZyLT/15H9TF6CHg/pub
```

[image]

7. **Response data**
   eyJpZCI6ImNkZDFiMWMwLTFjNDAtNGIwZi04ZTIyLTYxYjM1NzU0OGI3ZCIsInJlc3BvbnNlIjoiZmxhZy50eHRcbiJ9

[image]
