# Road (THM)

1. Register as our new user
2. Change password section can take over `admin@sky.thm`
3. `view-source:http://10.81.186.223/v2/profile.php` — we can see that `/v2/profileimages` and profile image upload then web shell.
4. `ss -lnpt` output gives us MongoDB working in background

```javascript
> db.user.find()
{ "_id" : ObjectId("60ae2661203d21857b184a76"), "Month" : "Feb", "Profit" : "25000" }
{ "_id" : ObjectId("60ae2677203d21857b184a77"), "Month" : "March", "Profit" : "5000" }
{ "_id" : ObjectId("60ae2690203d21857b184a78"), "Name" : "webdeveloper", "Pass" : "BahamasChapp123!@#" }
```
