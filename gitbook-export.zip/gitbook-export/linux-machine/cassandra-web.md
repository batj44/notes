# Cassandra Web 0.5.0 - Read File

Эхлээд `/proc/self/cmdline` уншаарай.

[Cassandra Web 0.5.0 - Remote File Read](https://www.exploit-db.com/exploits/49362)
