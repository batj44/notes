# tomiyo

2 toog huwiar bodoh

[image]

another calculations

[image]

```javascript
ren utilman.exe utilman1.exe
ren cmd.exe utilman.exe
```

## WEEK TO DATE

[image]
