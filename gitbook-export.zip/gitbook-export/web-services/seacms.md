# SeaCMS

**Database Connection Settings:** `/data/common.inc.php`

**General Site Configuration:** `/data/config.cache.inc.php`

**Backups:** Always copy the file to `common.inc.php.bak`
