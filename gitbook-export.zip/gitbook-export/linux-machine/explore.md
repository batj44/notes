# Explore - ES File Explorer / ADB Shell to Root

Open ports: 59777, 35957, 2222

[image]

59777 порт дээр эмзэг байдал өмнө үүсч байсан байна. Тухайн File explorer-ийг ашиглан RCE хийх боломжтой.

Exploit хийхдээ:

**[ES File Explorer Open Port Vulnerability - CVE-2019-6447](https://github.com/fs0c131y/ESFileExplorerOpenPortVuln)**

Хэрэгтэй хавсралт:
https://safe.security/wp-content/uploads/android-vulnerability-in-es-file-explorer.pdf

Github дээр python script байсан ч миний хувьд metasploit-ийг ашигласан байгаа.

[image]

Бүх зурган файлыг list хийсэн бөгөөд creds.jpg нь маш сонирхолтой.

[image]

Татаж авахдаа дараах байдлаар

[image]

Зурган файлыг нээх үед…

```
User: kristi
Pass: Kr1sT!5h@Rp3xPl0r3!
```

[image]

Тухайн машины localhost дээр ажиллаж байгаа service-үүдийн портыг харж байна.

```bash
ss -lnpt
```

[image]

5555 порт дээр ажилладаг сервис нь Android-ийг debug хийх зориулалттай бөгөөд халдагчид тухайн портыг On үед RCE хийх боломжтой болдог байна.

[image]

## Port Forwarding

Дараах байдлаар target машины 5555 портыг өөрийн attack машин руу дамжуулж байна.

[image]

болсон эсэхийг шалгахдаа

[image]

ADB-ийг ашиглаж байна.

[image]

Root!!!

[image]
