# Automated Case Management

FortiSIEM 7.2 introduces automated case creation and assignment, allowing the SOC team to consolidate related incidents into cohesive cases.

## Steps
1. Review SOC Analyst groups
2. Edit a SOC Analysts user
3. Create a case management policy
4. Create an automation policy that includes the case management policy
5. Enable the automation policy

## Sub-topics
- SOC Analyst Groups / Users
- Case Management Policy
- Automation Policies
- Test
