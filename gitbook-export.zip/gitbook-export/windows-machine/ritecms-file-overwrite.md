# RiteCMS 3.1.0 - Arbitrary File Overwrite (Authenticated)

Reference: https://www.exploit-db.com/exploits/50614
