# Offsec WINDOWS BOX PLAN

| # | Box | Exploit / CVE | Status | Difficulty |
|---|-----|---------------|--------|------------|
| 1 | Algernon | CVE-2019-7214 - SmarterMail | Done | |
| 2 | Authby | | Done | hard |
| 3 | Craft | | Done | |
| 4 | Hutch | | Done | hard |
| 5 | Internal | | Done | |
| 6 | Jacko | | | hard |
| 7 | Kevin | | Done | |
| 8 | Resourced | | Done | |
| 9 | Squid | Squid proxy - 3128 port | Done | |
| 10 | DVR4 | DVR 4.0.0.0 - Directory Traversal | Done | |
| 11 | Hepet | LibreOffice malicious macro | Done | hard |
| 12 | Shenzi | shenzi wordpress | Done | |
| 13 | Nickel | 8089 port --> 33333 port DevOps Dashboard | Done | |
| 14 | Slort | Apache Log Poisoning | Done | |
| 15 | MedJed | | Done | hard |
| 16 | Monster | Monstra-3.0.4-RCE | Done | |
| 17 | Mice | RemoteMouse-3.008-Exploit - RCE | Done | |
