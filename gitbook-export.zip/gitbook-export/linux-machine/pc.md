# PC - gRPCui 50051 Port / Pyload PE CVE-2023-0297

```bash
nmap -A -T4 10.10.11.214 -v -p-
```

[image]

## Connect with grpcui - 50051 port

```bash
go install github.com/fullstorydev/grpcui/cmd/grpcui@latest
```

**Then we can interact with gRPC.**

```bash
grpcui -plaintext example.com:9019
```

## SQL Injection

**Request - getInfo**

[image]

**Response - getInfo**

[image]

[image]

## Privilege Escalation

```bash
ss -lnpt
```

[image]

**Pyload service running on 8000 port. We can port forward to our localhost and possible to use this Proof of concept.**

https://www.exploit-db.com/exploits/51532

[image]
