# Clue - FreeSWITCH

## Password config file

```xml
cat /etc/freeswitch/autoload_configs/event_socket.conf.xml

<configuration name="event_socket.conf" description="Socket Client">
  <settings>
    <param name="nat-map" value="false"/>
    <param name="listen-ip" value="0.0.0.0"/>
    <param name="listen-port" value="8021"/>
    <param name="password" value="StrongClueConEight021"/>
  </settings>
</configuration>
```

## Core Configuration Files

| File Name | Purpose |
|-----------|---------|
| `freeswitch.xml` | The **master file**. Tells FreeSWITCH which other directories and files to load |
| `vars.xml` | Stores **global variables** like `$${default_password}`, `$${domain}`, and codec preferences |

## Key Directories & Sub-files

### `autoload_configs/` (Module Settings)

- `modules.conf.xml`: Determines **which modules load** when FreeSWITCH starts
- `event_socket.conf.xml`: Port `8021` settings and the ESL password
- `sofia.conf.xml`: Settings for the SIP stack (mod_sofia)
- `switch.conf.xml`: Core switch settings (max sessions, log levels)
- `conference.conf.xml`: Settings for conference rooms

### `directory/` (Users & Extensions)

- `directory/default.xml`: The main entry for the default domain
- `directory/default/*.xml`: Individual files for each extension (e.g., `1000.xml`)

### `dialplan/` (Call Routing)

- `dialplan/default.xml`: Handles calls from **authenticated** users (internal)
- `dialplan/public.xml`: Handles calls from **unauthenticated** sources (inbound from carriers)
- `dialplan/features.xml`: Special features like call park or intercept

### `sip_profiles/` (SIP Gateway & Port Bindings)

- `sip_profiles/internal.xml`: Usually port `5060` (for phones to register)
- `sip_profiles/external.xml`: Usually port `5080` (for connecting to SIP Trunks/Carriers)

### Pro Tip

FreeSWITCH compiles all these files into one giant XML file in memory. Check the final combined config:
`/var/log/freeswitch/freeswitch.xml.fsxml`
