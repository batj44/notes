# Misc

Miscellaneous notes and references.

## Topics

- [Kali APT Source List](apt-source-list.md)
- [MABx Lab Environment](mabx-lab-environment.md)
- [Pwned Machine List](pwned-machine-list.md)
