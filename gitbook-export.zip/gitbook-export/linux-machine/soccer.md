# Soccer - WebSocket SQL Injection

**NodeJS WebSocket SQLi vulnerable WebApp**

[embedded content]

**Exploit**

Reference: Web socket SQL injection technique
