# DFIR Notes

- [Origins HTB - FTP Analysis](origins-htb-ftp-analysis.md)
- [SmartyPants HTB](smartypants-htb.md)
