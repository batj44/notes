# Exam Reports

CPTS and OSCP certification exam reports.

## Reports

- [CPTS Exam Report](cpts-exam-report.md)
- [OSCP AD Set](oscp-ad-set.md)
- [OSCP Standalone - 1](oscp-standalone-1.md)
- [OSCP Standalone - 2](oscp-standalone-2.md)
- [OSCP Standalone - 3](oscp-standalone-3.md)
