# Horizontall - Strapi CMS / Laravel RCE

## Find domain information from static web's source code

[image]

## There is running Strapi CMS and we need to find admin panel

```bash
ffuf -u http://api-prod.horizontall.htb/FUZZ -w /usr/share/seclists/Discovery/Web-Content/api/actions.txt
```

[image]

http://api-prod.horizontall.htb/admin/auth/login

[image]

## Shell as Strapi

### Strapi 3.0.0-beta.17.7 vuln for RCE CVE-2019-19609

https://www.exploit-db.com/exploits/50238

[image]

## Privilege Escalation

```bash
ss -lnpt
```

[image]

## Port Forwarding

```bash
chisel_1.10.1_linux_amd64 client --fingerprint LgF+Qe6EjgVz1uLcmq2ehYOVOYj7l1MTQZPr3Me3UGc= 10.10.16.3:3333 R:8000:127.0.0.1:8000
```

**There is running Laravel v8 (PHP v7.4.18)**

[image]

## Shell as Root!

### Laravel v8 (PHP v7.4.18) vuln for RCE CVE-2021-3129

https://github.com/joshuavanderpoll/CVE-2021-3129

[image]
