# Atlassian Confluence

## The Master Config: `confluence.cfg.xml`

Most critical file. Contains database connection strings, license information, and setup paths.

- **Linux Default:** `/var/atlassian/application-data/confluence/confluence.cfg.xml`
- **Windows Default:** `C:\Program Files\Atlassian\Application Data\Confluence\confluence.cfg.xml`

## Database Connection (Alternative): `server.xml`

If Confluence uses a Datasource (managed by Tomcat) rather than a direct JDBC connection:

- **Path:** `confluence_install/conf/server.xml`

**Search for passwords in config files:**

```bash
grep -iE "password|user|jdbc" /var/atlassian/application-data/confluence/confluence.cfg.xml
```
