# CS-Cart

## Main Configuration Files

Located in the root directory of your CS-Cart installation:

- **`config.local.php` (Primary File):** Contains database credentials (host, name, user, password), and site's HTTP and HTTPS hosts/paths.
- **`config.php` (Core Settings):** Defines system-wide constants, file permissions, and directory paths. Don't edit directly; use `config.local.php` for overrides.

| Variable | Purpose |
|----------|---------|
| `$config['db_host']` | Database server (usually `localhost`) |
| `$config['db_name']` | The name of your MySQL database |
| `$config['db_user']` | Database username |
| `$config['db_password']` | Database password |
| `$config['http_host']` | Your domain name (e.g., `www.example.com`) |
| `$config['http_path']` | The subdirectory (if any) where CS-Cart is installed |
