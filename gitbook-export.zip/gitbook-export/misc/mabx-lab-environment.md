# Mabx Lab Environment

## PyEXP Python Command Injection

```bash
cat /opt/exp.py
uinput = raw_input('how are you?')
exec(uinput)
```

## Required IP Bypass

flag.php

```php
<?php
require("ip.php");
echo 'this is your flag';
?>
```

ip.php

```php
<?php

if (empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
 $x_header = "";
} else {
 $x_header = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
if (strpos($x_header, "10.10.10.") === false) {
 print("Your IP is not allowed to use this webservice. Only 10.10.10.x is allowed");
 die();
}
?>
```
