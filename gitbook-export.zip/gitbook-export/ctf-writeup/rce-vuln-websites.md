# RCE - Some vuln Websites

## Sub-pages

- [Armaxis - Markdown image RCE](rce-armaxis.md)
- [Void Whispers - sendmail RCE](rce-void-whispers.md)
- [Pentest notes - H2 sqli to RCE](rce-h2-sqli.md)
