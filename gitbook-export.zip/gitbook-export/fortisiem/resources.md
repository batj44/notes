# Resources

AcmeCorp utilizes FortiSIEM to unify its security management, enhancing threat detection and streamlining incident response. The Resource tab plays a vital role by centralizing access to essential tools such as security rules, watchlists, lookup tables, and threat intelligence feeds.

## Sub-topics
- Reports - Failed Login Attempts
- Sigma Rules
- Threat Intelligence - 3rd Party IOC
