# Extplorer

Config file location:

```
/var/www/html/filemanager/config/.htusers.php
```
