# Help - GraphQL / HelpDeskZ / Linux Kernel 4.4.0-116-generic

## Port 3000 - GraphQL

**Introspection query илгээх**

http://help.htb:3000/graphql?query=

[image]

**Эндээс username,password-ийг олсон байгаа**

[image]

[image]

## Port 80 - HelpDeskZ - SQL injection

Заавал hdz_ ээр эхэлсэн файл үүсгээд upload хийж sql injection нь ажиллна.

**hdz_zetr0.txt файлаа upload хийе**

[image]

**Sqlmap injecting SQL**

```bash
sqlmap -r testforshit --level=5 --risk=3 -D support -T staff --dump
```

[image]

[image]

## Shell as Help

```bash
id
```

[image]

## Shell as Root

Энэ linux kernel нь дараах эмзэг байдалд өртөмтгий байна.

https://www.exploit-db.com/raw/45010

[image]

[image]
