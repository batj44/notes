# Windows Forensic

## Windows - LDAP User KerbeRoastable

### During your investigations, you found a backup of the company's KDAP made with [ldap2json](https://github.com/p0dalirius/ldap2json). Use the information in this dump to find the Kerberoastable user.

The flag is the email address of the Kerberoastable user.

LDAP -аас json болгосн файл байна.

[image]

analysis.py tool-ийг ашиглснаар ийм байдлаар аль хэрэглэгч Kerborastable вэ гэдгийг мэдэх боломжтой болсон.

[image]

Alexandria хэрэглэгч.

**alexandria.newton@rootme.local**

[image]

---

## Windows - LDAP User ASRepRoastable

### During your investigations, you found a backup of the company's LDAP made with [ldap2json](https://github.com/p0dalirius/ldap2json). Use the information in this file to find the ASRepRoastable user.

The flag is the email address of the ASRepRoastable user.

**Ашигласан tool. LDAP**

[image]

analysis.py tool-ийг ашиглснаар ийм байдлаар аль хэрэглэгч ASRepRoastable вэ гэдгийг мэдэх боломжтой болсон.

[image]

Fitzgerald хэрэглэгч.

**fitzgerald.landry@rootme.local**

[image]

---

## Windows - NTDS Secret extraction

### You have a backup of the registry and NTDS of a Windows server hosting an Active Directory. Can you extract its secrets from these files?

### The flag is the key **aes256-cts-hmac-sha1-96** of the **krbtgt** account.

```
impacket-secretsdump -ntds ntds.dit -system SYSTEM -hashes lmhash:nthash LOCAL -outputfile ntlm-extract
```

[image]

If needed Crack

```
hashcat -m 1000 -w 3 -a 0 -p: --session=all --username -o cracked.out --outfile-format=3 ntlm-extract.ntds /usr/share/wordlists/rockyou.txt
```

---

## Secret SeSAMe recipe

Файл нь pcapng байна.

[image]

Тухайн wireshark файлыг оруулсан байдал.

[image]

Ер нь дотроо маш олон файлын түүхүүд хадгалагдаж байсан бөгөөд үүнийг wireshark-аас бүх файлаар нь export хийж гаргаж авсан.

[image]

Эндээс хамгийн чухал нь sam болон system гэсэн 2 файл байна. Өөрөөр хэлбэл дотор нь Administrator хэрэглэгчийн password гэх мэт чухал мэдээлэл байх боломжтой гэсэн үг.

[image]

Харин password-ийг олохдоо энэ аргыг ашигласан

[https://medium.com/@aayushtiruwa120/crack-windows-sam-file-0dc558f856fa](https://medium.com/@aayushtiruwa120/crack-windows-sam-file-0dc558f856fa)

```bash
impacket-secretsdump -sam sam -system system LOCAL
```

[image]

[image]

mazala\{!!3@T\^m3!!\}
