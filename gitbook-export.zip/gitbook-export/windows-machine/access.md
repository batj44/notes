# Access - runas lnk file Privilege

Found a .lnk file in `C:\Users\Public\Desktop` which reveals credentials:

[image]

[image]
