# CMDB Overview

## Sub-topics
- Navigate CMDB Devices and Applications
- CMDB Configuration Difference
- CMDB Server Inventory Report
