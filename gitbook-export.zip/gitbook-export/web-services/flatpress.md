# Flatpress

Key files:
- `fp-content/config/users.php`
- `fp-content/config/settings.php`

| File Name | Purpose |
|-----------|---------|
| `settings.php` | Contains general blog information (Blog Title, Subtitle, URL, and Author). |
| `config.php` | Stores core system settings, including language, character set, and time zone. |
| `users.php` | Contains encrypted user credentials and permission levels. |
| `plugins.php` | Manages which plugins are currently active or inactive. |
