# Openssl

## Certification - openssl

```bash
openssl s_client -connect www.capitronbank.mn:443 -showcerts
```

1. Tus certification file-iin butets

[image]

2. File-iin orgotgol ni PEM

[image]

```
openssl req -in hash -noout -text
```

[image]

FLAG IS **HZU18\{C3r7if1ed\_h4ck3r\}**

---

## Key + IV + salt = decrypt ENC!!!

Frankenstein.txt.enc -ийг decrypt хийх бүтэц

```
openssl enc -d -aes-256-cbc -in frankenstein.txt.enc -out flag.txt -K 58593a7522257f2a95cce9a68886ff78546784ad7db4473dbd91aecd9eefd508 -iv 7a12fd4dc1898efcd997a1b9496e7591 -nosalt
```

---

## flag.enc salt - Openssl

encoded section:
`openssl aes256 -salt -in flag.txt -out flag.txt.enc -k unbreakablepassword1234567`

decoded section:

[image]

---

## aes-256-cbc - iter 10

using **flag.enc**, **pass.txt** decrypt **AES-256-CBC.**

```
openssl enc -aes-256-cbc -iter 10 -d -in flag.enc -out flag.txt
```

[image]

[image]
