# FileZilla

## FileZilla Credentials

If FileZilla is installed on the target computer, you can steal credentials for other servers:

- `%APPDATA%\FileZilla\sitemanager.xml` — All saved server information
- `%APPDATA%\FileZilla\recentservers.xml` — Recently connected servers
- `%APPDATA%\FileZilla\filezilla.xml` — General settings (sometimes paths are visible)

Full path: `C:\Users\user_name\AppData\Roaming\FileZilla\sitemanager.xml`
