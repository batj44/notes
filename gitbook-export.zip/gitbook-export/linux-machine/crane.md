# Crane - SuiteCRM CVE-2022-23940

SuiteCRM CVE-2022-23940 exploit.
