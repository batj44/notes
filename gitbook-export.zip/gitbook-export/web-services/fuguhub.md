# FuguHub

FuguHub uses `.dat` and `.conf` files to store everything from user hashes to SMTP settings.

| File Name | Importance |
|-----------|------------|
| `user.dat` | **Critical.** Contains encrypted usernames and password hashes. If you can download this, you can attempt to crack the admin password. |
| `bd.conf` | General server configuration. Look here for custom port settings or security constraints that might be misconfigured. |
| `dbcfg.dat` | Often contains SMTP credentials or database connection strings. Can lead to "password reuse" wins on other services. |
| `emails.dat` | A list of all user email addresses — useful for tailoring brute-force attacks or identifying admin accounts. |
| `roles.dat` | Defines user permissions. Useful for understanding which account to target for "Superuser" status. |
