# Sightless - Froxlor XSS / RCE

https://github.com/froxlor/Froxlor/security/advisories/GHSA-x525-54hf-xr53

### XSS хийж create new admin as abcd:Abcd@@1234

Login request дээр XSS payload-оо нэмээд Sent!

[image]

Login as `abcd:Abcd@@1234`

[image]

## Shell as Root!

https://github.com/sarperavci/Froxlor-Authenticated-root-RCE-Exploit

Steps-1: Upload revshell.sh to `/tmp` directory.

[image]

Steps-2: Go to `PHP` -> `PHP-FPM versions` and set a custom PHP-FPM restart command as shown in the image below.

[image]

### Root!

[image]
