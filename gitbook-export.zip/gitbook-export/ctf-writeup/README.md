# CTF Writeup

CTF challenge writeups - forensics, web exploitation, crypto, and more.

## Challenges

- [CryptoJS decrypt](cryptojs-decrypt.md)
- [Dynamic PDF - (XSS /etc/passwd)](dynamic-pdf-xss.md)
- [Active Directory Forensic](forensic-ad.md)
- [Forensic Challenges](forensic-chall.md)
- [Docker Forensic](forensic-docker.md)
- [Misc Forensics](forensic-misc.md)
- [Openssl](forensic-openssl.md)
- [Windows Forensic](forensic-windows.md)
- [Gunship - Ast injection + Prototype Pollution](gunship-ast-injection.md)
- [Hash Length Extension Attack](hash-length-extension.md)
- [Invite code /verify endpoint leads RCE](invite-code-rce.md)
- [Lodash - Prototype Pollution](lodash-prototype-pollution.md)
- [Pickle loads - Insecure Deserialization](pickle-loads.md)
- [Armaxis - (Markdown image RCE)](rce-armaxis.md)
- [Pentest notes - H2 sqli to RCE](rce-h2-sqli.md)
- [Void Whispers - (sendmail RCE)](rce-void-whispers.md)
- [RCE - Some vuln Websites](rce-vuln-websites.md)
- [Regex based firewall](regex-firewall.md)
- [Trinity's Hidden Door - Command injection in Hidden parameter](trinitys-hidden-door.md)
- [Web Challenges](web-chall.md)
- [Web socket - SQL](web-socket-sql.md)
